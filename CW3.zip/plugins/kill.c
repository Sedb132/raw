/*
 * kill.o - terminate a process by PID.
 */
#include <windows.h>
#include "../bof.h"

void go(char *args, int length) {
    char *s = (char *)b_malloc(length + 1);
    if (!s) { b_send(POUT_ERR, "oom", 3); return; }
    memcpy(s, args, length);
    s[length] = 0;

    DWORD pid = (DWORD)atoi(s);
    HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, pid);
    char m[256];
    int l;
    if (h) {
        TerminateProcess(h, 0);
        CloseHandle(h);
        l = wsprintfA(m, "[+] Killed PID %lu\r\n", pid);
    } else {
        l = wsprintfA(m, "[-] Failed to kill PID %lu (err=%lu)\r\n", pid, GetLastError());
    }
    b_send(POUT_INFO, m, l);
    b_send(POUT_DONE, "", 0);
}
