/*
 * crash.o - deliberately faulting plugin. Used to prove sandbox isolation:
 * a crash must kill only this plugin thread, never the agent or the other
 * running plugins.
 */
#include <windows.h>
#include "../bof.h"

void go(char *args, int length) {
    (void)args; (void)length;
    b_send(POUT_INFO, "crash.o: about to dereference NULL...", 39);
    *(volatile int *)0 = 0xDEADBEEF;   /* access violation */
    b_send(POUT_INFO, "crash.o: unreachable", 20);
}
