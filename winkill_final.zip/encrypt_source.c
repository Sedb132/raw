#include <windows.h>
#include <stdio.h>

// Same key as agent
static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: encrypt.exe <file>\n");
        return 1;
    }

    HANDLE h = CreateFileA(argv[1], GENERIC_READ, 0, NULL,
                           OPEN_EXISTING, 0, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        printf("Cannot open: %s\n", argv[1]);
        return 1;
    }

    DWORD sz = GetFileSize(h, NULL);
    BYTE *buf = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    DWORD r;
    ReadFile(h, buf, sz, &r, NULL);
    CloseHandle(h);

    // XOR encrypt
    for (DWORD i = 0; i < sz; i++)
        buf[i] ^= g_key[i % 16];

    // Write .enc file
    char out[MAX_PATH];
    wsprintfA(out, "%s.enc", argv[1]);
    h = CreateFileA(out, GENERIC_WRITE, 0, NULL,
                    CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    WriteFile(h, buf, sz, &r, NULL);
    CloseHandle(h);
    HeapFree(GetProcessHeap(), 0, buf);

    printf("Encrypted: %s (%lu bytes) -> %s\n", argv[1], sz, out);
    return 0;
}
